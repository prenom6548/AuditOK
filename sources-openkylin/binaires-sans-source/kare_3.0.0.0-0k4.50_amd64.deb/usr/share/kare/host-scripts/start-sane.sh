#!/bin/bash
containerNameValue="v10sp1Driver"
if ps -ef | grep -v grep | grep -q "/usr/sbin/saned -l";then
    echo "saned is running" | tee -a $logFile
else
    if grep -q "^localhost$" /etc/sane.d/net.conf 2>/dev/null; then
        echo "localhost already exists in /etc/sane.d/net.conf" | tee -a $logFile
    else
        echo localhost >> /etc/sane.d/net.conf| tee -a $logFile
    fi
    /usr/bin/kare run $containerNameValue /usr/sbin/saned -l -d 128 | tee -a $logFile
fi