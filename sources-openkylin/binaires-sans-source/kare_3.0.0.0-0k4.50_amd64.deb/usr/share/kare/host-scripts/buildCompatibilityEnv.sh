#!/bin/bash

sudo /usr/bin/build-upgrade