#!/usr/bin/python3
# -- coding: UTF-8 --

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import GLib, Gtk, Gio
from pydbus import SessionBus
import subprocess

loop = GLib.MainLoop()

class KARE():
    """
    <node>
        <interface name='com.kylin.kare.Sessionhost'>
            <method name='call' >
                <arg type='s' direction='out' name='ret'/>
                <arg type='s' direction='in' name='ret'/>
            </method>
        </interface>
    </node>
    """

    def call(self, cmd) -> str:
        ret = subprocess.getoutput(cmd)
        return ret

bus = SessionBus()
bus.publish("com.kylin.kare.Sessionhost", KARE())
loop.run()
