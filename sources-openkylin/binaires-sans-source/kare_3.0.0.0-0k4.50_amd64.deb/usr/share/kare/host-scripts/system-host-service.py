#!/usr/bin/python3
# -- coding: UTF-8 --

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import GLib, Gtk, Gio
from pydbus import SystemBus
import subprocess
import shlex

loop = GLib.MainLoop()

class KARE():
    """
    <node>
        <interface name='com.kylin.kare.host'>
            <method name='command' >
                <arg type='s' direction='out' name='ret'/>
                <arg type='s' direction='in' name='ret'/>
            </method>
        </interface>
    </node>
    """

    def command(self, cmd) -> str:
        ret = subprocess.getoutput("command -v {}".format(shlex.quote(cmd)))
        return ret   

bus = SystemBus()
bus.publish("com.kylin.kare.host", KARE())
loop.run()
