#!/bin/bash

# 清理目录下的死链接和空目录
cleanup_dest_dir() {
	local dir="$1"
	if [ ! -d "$dir" ]; then
		return
	fi

	# 删除死链接
	find "$dir" -type l ! -exec test -e {} \; -delete 2>/dev/null || true

	# 删除空目录
	find "$dir" -type d -empty -delete 2>/dev/null || true
}

# 执行 cups 相关配置
setup_cups() {
	KARE_CUPS_LIB_STRING="ServerBin /opt/system/lib/cups"
	cups_file_conf="/etc/cups/cups-files.conf"

	cups_lib_src_dir="/usr/lib/cups"
	cups_lib_dest_dir="/opt/system/lib/cups"

	mkdir -p "$cups_lib_dest_dir"
	# 先清理 dest_dir 下的死链接和空目录
	cleanup_dest_dir "$cups_lib_dest_dir"

	mkdir -p "$cups_lib_dest_dir/filter"
	mkdir -p "$cups_lib_dest_dir/backend"
	mkdir -p "$cups_lib_dest_dir/driver"
	
	shopt -s nullglob

	for item in "$cups_lib_src_dir"/*; do
		name=$(basename "$item")
		if [[ $name != "filter"  &&  $name != "backend" && $name != "driver" ]]; then
			ln -sfn "$item" "$cups_lib_dest_dir/$name"
		fi
	done

	for item in "$cups_lib_src_dir/filter"/*; do
		name=$(basename "$item")
		ln -sfn "$item" "$cups_lib_dest_dir/filter/$name"
	done

	for item in "$cups_lib_src_dir/backend"/*; do
		name=$(basename "$item")
		ln -sfn "$item" "$cups_lib_dest_dir/backend/$name"
	done

	for item in "$cups_lib_src_dir/driver"/*; do
		name=$(basename "$item")
		ln -sfn "$item" "$cups_lib_dest_dir/driver/$name"
	done

	KARE_CUPS_SHARE_STRING="DataDir /opt/system/resource/cups"

	cups_share_src_dir="/usr/share/cups"
	cups_share_dest_dir="/opt/system/resource/cups"

	mkdir -p "$cups_share_dest_dir"
	# 先清理 dest_dir 下的死链接和空目录
	cleanup_dest_dir "$cups_share_dest_dir"

	mkdir -p "$cups_share_dest_dir/model"
	mkdir -p "$cups_share_dest_dir/mime"
	mkdir -p "$cups_share_dest_dir/drv"
	mkdir -p "$cups_share_dest_dir/ppd-updaters"

	for item in "$cups_share_src_dir"/*; do
		name=$(basename "$item")
		if [[ $name != "model"  &&  $name != "mime" && $name != "drv" && $name != "ppd-updaters" ]]; then
			ln -sfn "$item" "$cups_share_dest_dir/$name"
		fi
	done

	for item in "$cups_share_src_dir/model"/*; do
		name=$(basename "$item")
		ln -sfn "$item" "$cups_share_dest_dir/model/$name"
	done

	for item in "$cups_share_src_dir/mime"/*; do
		name=$(basename "$item")
		ln -sfn "$item" "$cups_share_dest_dir/mime/$name"
	done

	for item in "$cups_share_src_dir/drv"/*; do
		name=$(basename "$item")
		ln -sfn "$item" "$cups_share_dest_dir/drv/$name"
	done

	for item in "$cups_share_src_dir/ppd-updaters"/*; do
		name=$(basename "$item")
		ln -sfn "$item" "$cups_share_dest_dir/ppd-updaters/$name"
	done

	shopt -u nullglob

	if grep -q "$KARE_CUPS_LIB_STRING" "$cups_file_conf"; then
		return 0
	fi

	echo "$KARE_CUPS_LIB_STRING" >> "$cups_file_conf"
	echo "$KARE_CUPS_SHARE_STRING" >> "$cups_file_conf"
}

copy_list=("passwd" "shadow" "group" "gshadow" "subgid" "subuid" "passwd-" "shadow-" "group-" "gshadow-" "subgid-" "subuid-" "uid_list" "timezone" "localtime" "locale.gen")
base_env_path="/opt/kare-applications/base/kare-v10sp1"

if [ -d "$base_env_path" ]; then
    for file in  "${copy_list[@]}"; do
        if [ -f "/etc/$file" ]; then
            cp -a "/etc/$file" "$base_env_path/etc/$file"
        fi
    done
    cp /usr/share/kare/container-scripts/* "$base_env_path/usr/bin"
	cp /usr/share/kare/container-scripts/dpkg-wrapper.sh "$base_env_path/usr/bin/dpkg"
	cp /usr/share/kare/plugins/tini/tini "$base_env_path/usr/bin/tini"

	if [ -f "/usr/share/kare/plugins/ksvb/ksvb-app" ]; then
		cp  "/usr/share/kare/plugins/ksvb/ksvb-app" "$base_env_path/usr/bin/ksvb-app"
	fi
	if [ -f "/usr/share/kare/plugins/ksvb/libsane-ksvb.so.1.0.0" ]; then
		arch_name=$(uname -m)
		cp  "/usr/share/kare/plugins/ksvb/libsane-ksvb.so.1.0.0" "$base_env_path/usr/lib/$arch_name-linux-gnu/sane/libsane-ksvb.so.1.0.0"
	fi

fi
if [ -f "/usr/share/kare/plugins/host-agent/hostAgent" ]; then
	cp  "/usr/share/kare/plugins/host-agent/hostAgent" "$base_env_path/usr/bin/"
fi



# 删除并重建/opt/kare-applications/host目录
host_lower_dir="/opt/kare-applications/host"
if [ -d "$host_lower_dir" ]; then
    rm -rf "$host_lower_dir"
fi
mkdir -p "$host_lower_dir"
dirs=("usr" "var" "etc" "opt" "root")
for dir in "${dirs[@]}"; do
    mkdir -p "$host_lower_dir/$dir"
done

# 卸载 kare-applications 目录下的挂载点，确保迁移操作可以正常进行
for mount_point in $(cat /proc/mounts | grep -E "/opt/kare-applications/v10sp1|/opt/kare-applications/shadow" | awk '{print $2}' | sort -r); do
    umount "$mount_point" 2>/dev/null || true
done

migrate_script='
import os
import shutil

def migrate_overlay_to_symlink(package_path, link_dirs=None):
    """
    迁移 overlay 目录结构，将真实目录改为符号链接以保持兼容性

    @param package_path: overlay 根路径（包含 lower/upper/work/merge 目录）
    @param link_dirs: 需要迁移的目录列表，默认为 ["bin", "lib", "sbin", "lib64"]
    """
    # 判断 package_path 是否存在
    if not os.path.exists(package_path):
        return

    if link_dirs is None:
        link_dirs = ["bin", "lib", "sbin", "lib64"]

    for path in link_dirs:
        merge_link_dir = os.path.join(package_path, "merge", path)
        upper_dir = os.path.join(package_path, "upper", path)
        upper_usr_dir = os.path.join(package_path, "upper", "usr", path)

        # 如果已经存在符号链接，跳过
        if os.path.islink(merge_link_dir):
            continue

        # 如果是真实目录（旧代码创建），需要迁移 upper 层的修改
        if os.path.isdir(merge_link_dir):
            if os.path.exists(upper_dir) and os.path.exists(upper_usr_dir):
                # 将 upper/{path} 的内容迁移到 upper/usr/{path}
                for root, dirs, files in os.walk(upper_dir):
                    for f in files:
                        src = os.path.join(root, f)
                        rel_path = os.path.relpath(src, upper_dir)
                        dst = os.path.join(upper_usr_dir, rel_path)
                        # 如果 dest 存在则跳过，否则复制（保留符号链接）
                        if os.path.exists(dst):
                            continue
                        os.makedirs(os.path.dirname(dst), exist_ok=True)
                        shutil.copy2(src, dst, follow_symlinks=False)

            # 删除旧的 merge 目录和 upper 目录
            shutil.rmtree(merge_link_dir)
            if os.path.exists(upper_dir):
                shutil.rmtree(upper_dir)

        # 创建符号链接
        os.symlink(os.path.join("usr", path), merge_link_dir)

# 对两个 package_path 执行迁移
for pkg_path in ["/opt/kare-applications/v10sp1", "/opt/kare-applications/shadow"]:
    migrate_overlay_to_symlink(pkg_path)
'
python3 -c "$migrate_script"

# 执行 cups 配置
setup_cups

exit 0
