#!/bin/bash
REAL_DPKG="/usr/bin/dpkg.real"
LOG_DIR="/var/log/kare"
LOG_FILE="$LOG_DIR/kare-dpkg-wrapper.log"
echo "+++++++++++++++++++++++++++++" >> "$LOG_FILE"

# 确保日志目录存在
mkdir -p "$LOG_DIR"

# 设置日志文件权限
chmod 644 "$LOG_FILE" 2>/dev/null || true

# 记录函数
log_action() {
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    local action="$1"
    local package="$2"
    local status="$3"
    local message="$4"
    
    echo "$timestamp | $action | $package | $status | $message" >> "$LOG_FILE"
     
}
# 解析安装和卸载参数
parse_install_remove_args() {
    local action=""
    local target=""
    
    # 遍历所有参数
    local i=1
    local skip_next=false
    
    while [ $i -le $# ]; do
        local arg="${!i}"
        
        # 如果设置了跳过标志，处理下一个参数
        if [ "$skip_next" = true ]; then
            skip_next=false
            i=$((i + 1))
            continue
        fi
        
        case "$arg" in
            # 安装操作
            -i|--install)
                action="install"
                # 标记下一个参数可能是包名，但不是立即获取
                local next_index=$((i + 1))
                if [ $next_index -le $# ]; then
                    local next_arg="${!next_index}"
                    # 检查下一个参数是否是选项（以-开头）或包文件
                    if [[ ! "$next_arg" =~ ^- ]] && [[ "$next_arg" == *.deb || $action == "remove" || $action == "purge" ]]; then
                        target="$next_arg"
                        skip_next=true
                    fi
                fi
                ;;
            
            # 卸载操作
            -r|--remove)
                action="remove"
                local next_index=$((i + 1))
                if [ $next_index -le $# ]; then
                    local next_arg="${!next_index}"
                    # 对于remove/purge，下一个参数应该是包名（不是以-开头）
                    if [[ ! "$next_arg" =~ ^- ]]; then
                        target="$next_arg"
                        skip_next=true
                    fi
                fi
                ;;
            
            # 彻底清除操作
            -P|--purge)
                action="purge"
                local next_index=$((i + 1))
                if [ $next_index -le $# ]; then
                    local next_arg="${!next_index}"
                    if [[ ! "$next_arg" =~ ^- ]]; then
                        target="$next_arg"
                        skip_next=true
                    fi
                fi
                ;;
            
            # 处理复合选项
            --install=*|--remove=*|--purge=*)
                # 处理 --install=package.deb 这种形式
                local opt="${arg%%=*}"
                local pkg="${arg#*=}"
                
                case "$opt" in
                    --install) action="install" ;;
                    --remove) action="remove" ;;
                    --purge) action="purge" ;;
                esac
                
                target="$pkg"
                ;;
            
            # 包文件（.deb）可能是通过其他方式指定的
            *.deb)
                # 如果我们在一个动作中，并且还没有目标包，这可能是包文件
                if [ -n "$action" ] && [ "$action" = "install" ] && [ -z "$target" ]; then
                    # 检查这个.deb文件是否紧跟在-i/--install后面
                    local found_action=false
                    for ((j=1; j<i; j++)); do
                        case "${!j}" in
                            -i|--install)
                                # 检查-i和当前.deb文件之间是否有其他非选项参数
                                local valid=true
                                for ((k=j+1; k<i; k++)); do
                                    local between_arg="${!k}"
                                    if [[ ! "$between_arg" =~ ^- ]] && [[ "$between_arg" != "$arg" ]]; then
                                        valid=false
                                        break
                                    fi
                                done
                                if [ "$valid" = true ]; then
                                    target="$arg"
                                    found_action=true
                                fi
                                ;;
                        esac
                        if [ "$found_action" = true ]; then
                            break
                        fi
                    done
                fi
                ;;
        esac
        
        i=$((i + 1))
    done
    
    # 如果还没找到包名，尝试从最后的位置找
    if [ -z "$target" ] && [ -n "$action" ]; then
        # 查找最后一个.deb文件（对于install）或最后一个非选项参数（对于remove/purge）
        for ((j=$#; j>=1; j--)); do
            local arg="${!j}"
            
            if [ "$action" = "install" ]; then
                if [[ "$arg" == *.deb ]]; then
                    # 检查这个.deb文件是否在某个-i/--install之后
                    for ((k=1; k<j; k++)); do
                        case "${!k}" in
                            -i|--install)
                                target="$arg"
                                break 2
                                ;;
                        esac
                    done
                fi
            elif [[ "$action" == "remove" || "$action" == "purge" ]]; then
                if [[ ! "$arg" =~ ^- ]] && [[ "$arg" != *.deb || $action != "install" ]]; then
                    # 检查这个包名是否在对应的动作选项之后
                    for ((k=1; k<j; k++)); do
                        case "${!k}" in
                            -r|--remove)
                                if [ "$action" = "remove" ]; then
                                    target="$arg"
                                    break 2
                                fi
                                ;;
                            -P|--purge)
                                if [ "$action" = "purge" ]; then
                                    target="$arg"
                                    break 2
                                fi
                                ;;
                        esac
                    done
                fi
            fi
        done
    fi
    
    # 特殊处理：如果action是install但target不是.deb文件，清空target
    if [ "$action" = "install" ] && [ -n "$target" ] && [[ ! "$target" == *.deb ]]; then
        target=""
    fi
    
    if [ -n "$target" ] && [ "$action" = "install" ] && [[ "$target" == *.deb ]]; then
        # 检查是否是相对路径（不以/开头，并且包含目录分隔符或者有./或../）
        if [[ "$target" != /* ]] && [[ "$target" == */* || "$target" == ./* || "$target" == ../* ]]; then
            # 将相对路径转换为绝对路径
            local abs_target
            if [ -f "$target" ]; then
                # 如果文件存在，使用realpath或readlink获取绝对路径
                if command -v realpath >/dev/null 2>&1; then
                    abs_target=$(realpath "$target" 2>/dev/null || echo "$target")
                fi
                target="$abs_target"
            fi
        fi
    fi
    echo "$action:$target"
}

execute_dpkg() {
    # kare -P的流程包括DPKG_REMOVE_KARE环境变量，这种情况下直接执行dpkg-real卸载应用就好了
    echo $DPKG_REMOVE_KARE  >> "$LOG_FILE"
    if [[ "$DPKG_REMOVE_KARE"  == "true" ]];then
        echo "通过kare进行卸载"  >> "$LOG_FILE"
        "$REAL_DPKG" "$@"
        return $?
    fi
    action_target=$(parse_install_remove_args "$@")
    local action="${action_target%%:*}"
    local package="${action_target##*:}"
    
    # 如果不是安装/卸载操作，直接执行原始dpkg
    if [ -z "$action" ] || [ "$action" = "unknown" ]; then
        "$REAL_DPKG" "$@"
        return $?
    fi
    # 应用自更新
    # KARE_APP 变量主要是为了将kare的安装和应用的自更新区分开
    # DISPLAY 变量主要是为将在容器内使用sudo dpkg -i 安装应用和应用自更新区分开，应用通过提权的方式自更新的时候没有display环境变量
    if [[ "$action" == "install"  && -z "$KARE_APP" && -z "$DISPLAY" ]]; then
        if [ -d "/opt/kare-applications/" ];then
            base="shadow"
        else
            base="v10sp1"
        fi
        echo "==============容器内应用通过自更新安装kare 应用==============" >> "$LOG_FILE"
        echo "kare安装参数我：base=$base，package = $package" >> "$LOG_FILE"
        ret=$(dbus-send --system --type=method_call \
            --print-reply \
            --dest=org.kylin.kare \
            /org/kylin/kare \
            org.kylin.kare.install \
            string:"$base" \
            string:"$package")
        return_code=$(echo "$ret" | grep -oP 'int32\s+\K\d+')
        echo "调用kare的dbus安装接口返回值为：$return_code"  >> "$LOG_FILE"
        local temp_file="/tmp/kare_result.$$"
        echo "-1" > "$temp_file"
        if [ "$return_code" -eq 1 ];then
            dbus-monitor --system "type='signal',interface='org.kylin.kare',path='/org/kylin/kare'" | \
            while read -r line; do
                if [[ $line == *"member=installStatusChanged"* ]]; then                
                    read -r param1
                    read -r param2
                    read -r param3
                    read -r param4
                    arg1=$(echo "$param1" | sed 's/^[[:space:]]*string "//;s/"$//')
                    arg2=$(echo "$param2" | sed 's/^[[:space:]]*int32 //')
                    arg3=$(echo "$param3" | sed 's/^[[:space:]]*int32 //')
                    arg4=$(echo "$param4" | sed 's/^[[:space:]]*string "//;s/"$//')
                    
                    echo "参数1 (文件路径): $arg1"  >> "$LOG_FILE"
                    echo "参数2 (安装进度): $arg2"  >> "$LOG_FILE"
                    echo "参数3 (安装状态): $arg3"  >> "$LOG_FILE"
                    echo "参数4 (字符串): $arg4"  >> "$LOG_FILE"
                    if [ "$arg3" -ne 0 ] && [ "$arg3" -ne 1 ];then 
                        echo "=============通过kare自更新应用失败==============" >> "$LOG_FILE"
                        pkill -f "dbus-monitor.*org.kylin.kare"
                        echo "-1" > "$temp_file"
                        break
                    fi
                    if [ "$arg3" -eq 0 ] || [ "$arg2" -eq 100 ]; then
                        echo "=============通过kare自更新应用成功==============" >> "$LOG_FILE"
                        pkill -f "dbus-monitor.*org.kylin.kare"
                        echo "0" > "$temp_file"
                        break
                    fi
                fi
            done
            local kare_install_return_code
            kare_install_return_code=$(cat "$temp_file")
            rm -f "$temp_file" 2>/dev/null || true
            return $kare_install_return_code
        else
            exit $return_code
        fi
    fi
    # 执行真实的dpkg命令
    "$REAL_DPKG" "$@"
    dpkg_real_exit_code=$?
    if [ $dpkg_real_exit_code -eq 0 ]; then
        # 执行成功
        log_action "$action" "$package" "success" "dpkg命令执行成功"
        if [[ "$action" == "remove" || "$action" == "purge" ]]; then
            echo "==============卸载宿主机的kare应用==============" >> "$LOG_FILE"
            dbus-send --system --type=method_call \
		        --print-reply \
                --dest=org.kylin.kare \
                /org/kylin/kare \
                org.kylin.kare.remove \
                string:$package
        fi
        return 0
    else
        # 执行失败
        log_action "$action" "$package" "failed" "dpkg命令执行失败，退出码: $dpkg_real_exit_code"
        return $dpkg_real_exit_code
    fi
}

# 显示使用帮助
show_help() {
    echo "dpkg包装脚本 - kare中增强的dpkg命令"
    echo "用法: $0 [dpkg选项] [包名]"
    echo ""
    echo "功能:"
    echo "  - 执行原始dpkg命令"
    echo "  - 卸载宿主机上的kare包"
    echo ""
}

# 处理帮助选项
case "$1" in
    -h|--help|help)
        show_help
        exit 0
        ;;
    --version)
        echo "dpkg包装脚本 v1.0"
        "$REAL_DPKG" --version
        exit 0
        ;;
esac

# 主程序
if [ $# -eq 0 ]; then
    # 无参数时显示帮助
    show_help
    exit 1
fi

# 执行dpkg命令
execute_dpkg "$@"
exit $?
