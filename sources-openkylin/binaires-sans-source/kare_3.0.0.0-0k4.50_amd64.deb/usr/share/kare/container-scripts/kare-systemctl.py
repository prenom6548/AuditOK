#!/usr/bin/env python3
"""
systemctl 命令替代脚本
在容器环境中替换 systemctl，查询类参数调用systemctl.real，其他参数记录命令并返回0
"""

import os
import sys
import dbus
import subprocess 

# 日志文件路径
LOG_FILE = "/etc/kare/systemctl_commands.sh"

# 定义systemctl查询类参数列表（可按需扩展）
QUERY_ACTIONS = {"is-active", "is-enabled", "status", "show", "is-failed", "list-units", "list-unit-files"}

def get_user_by_login1():
    try:
        # 获取系统总线
        bus = dbus.SystemBus()

        # 获取 login1 管理接口
        login1_proxy = bus.get_object(
            "org.freedesktop.login1",
            "/org/freedesktop/login1"
        )
        manager_iface = dbus.Interface(
            login1_proxy,
            "org.freedesktop.login1.Manager"
        )

        # 调用 ListUsers 方法
        users = manager_iface.ListUsers()

        # 遍历用户
        for user in users:
            # user 结构为 (uid, username, object_path)
            user_path = user[2]
            user_proxy = bus.get_object("org.freedesktop.login1", user_path)

            # 获取用户属性接口
            user_iface = dbus.Interface(
                user_proxy,
                dbus_interface=dbus.PROPERTIES_IFACE
            )

            # 读取 State 属性
            state = user_iface.Get(
                "org.freedesktop.login1.User",
                "State"
            )

            if state == "active":
                return user[1]

        return "root"
    except dbus.exceptions.DBusException as e:
        return "root"
    except Exception as e:
        return "root"

def log_command():
    """记录执行的命令到日志文件"""
    
    # 获取执行的命令
    command_args = sys.argv[:]  # 获取除脚本名外的所有参数
    command = " ".join(command_args)
    if "--user" in command:
        user = get_user_by_login1()
        command = "su - {} --shell=/bin/bash -c 'export XDG_RUNTIME_DIR=/run/user/$(id -u); {}'".format(user, command)
    
    # 记录命令到文件
    try:
        with open(LOG_FILE, "a") as f:
            f.write(f"{command}\n")
    except PermissionError:
        # 忽略写入错误
        pass

def execute_real_systemctl():
    """执行真实的 systemctl.real 命令"""
    try:
        real_cmd = ["/usr/bin/systemctl.real"] + sys.argv[1:]
        env = os.environ.copy()
        env["SYSTEMD_IGNORE_CHROOT"] = "1"
        
        result = subprocess.run(
            real_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=env, 
            timeout=30  
        )
        # 原样输出结果
        if result.stdout:
            sys.stdout.write(result.stdout)
        if result.stderr:
            sys.stderr.write(result.stderr)
        # 退出并返回真实退出码
        sys.exit(result.returncode)
    except FileNotFoundError:
        # 若systemctl.real不存在，返回标准的"command not found"退出码
        sys.exit(127)
    except subprocess.TimeoutExpired:
        # 命令执行超时
        sys.exit(124)
    except Exception:
        # 其他未知异常
        sys.exit(1)

def get_action():
    """获取操作类型"""
    for arg in sys.argv[1:]:
        if not arg.startswith('-'):
            return arg
    return None

def main():
    """主函数"""
    action = get_action()
    # 判断是否为查询类参数，若是则调用systemctl.real执行
    if action in QUERY_ACTIONS:
        execute_real_systemctl()
    
    # 非查询类参数,记录执行的命令
    log_command()
    sys.exit(0)

if __name__ == "__main__":
    main()
