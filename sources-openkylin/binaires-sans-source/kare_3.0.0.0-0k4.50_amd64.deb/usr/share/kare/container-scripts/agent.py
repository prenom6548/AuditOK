import os
import shutil
import dbus 
import sys
import json
import re
import subprocess
import threading
import pty
from pathlib import Path
import apt
import apt.debfile


class ContainerMessage():

    @property
    def get_release(self):
        return subprocess.getoutput("cat /etc/lsb-release | grep DISTRIB_DESCRIPTION | awk -F '=' '{print $2}'").strip("\"")

    def get_config_json(self, key=None):
        try:
            with open("/etc/kare/whitelist/kare-apt", 'r') as file:
                data = json.load(file)
            if key is not None:
                return data.get(key, None)
            else:
                return data
        except json.decoder.JSONDecodeError:
            return None
        except FileNotFoundError:
            return None
        
    def set_config_json(self, data):
        if data == []:
            return
        with open("/etc/kare/error-message", "w") as file:
            json.dump(data, file, indent=4) 
    

class KareApt(ContainerMessage):

    def __init__(self, deb_file_path):
        self.package_depends_list = []
        self.apt_install_list = ''
        self.package_depends_dist = {}
        self.whitelist_package = self.get_config_json("whitelist")
        # TODO v10 v10-sp1 做区分
        self.RELEASE = self.get_release
        if self.RELEASE == "Kylin V10":
            self.blacklist = self.get_config_json("v10_blacklist")
        else:
            self.blacklist = self.get_config_json("blacklist")

        self.depends_version_dict = {}
        self.apt_list=[]
        self.v10_apt_list = self.get_config_json("v10_apt_list")
        self.sp1_apt_list = self.get_config_json("sp1_apt_list")
        self.v11_apt_list = self.get_config_json("v11_apt_list")
        self.deb = deb_file_path
        self.log = deb_file_path.rsplit("/")[-1] + "_log"
        try:
            self.package = apt.debfile.DebPackage(deb_file_path)
        except LookupError as e:
            self.package = None
        self.apt_path = "apt-get.orig" if os.path.exists("/usr/bin/apt-get.orig") else "apt-get"
    
    def _dbus_stream(self, fd, logger_func):
        """从文件描述符读取数据并记录"""
        try:
            error_message = []
            while True:
                data = os.read(fd, 1024)
                if not data:
                    break  # 子进程关闭时退出循环
                # 按行处理输出
                for line in data.decode(errors='replace').splitlines():
                    if "未安装软件包" in line:
                        error_message.append(line.split("未安装软件包")[-1].strip("。").strip())
                    elif "is not installed" in line:
                        error_message.append(line.split(" ")[-4].strip())
                    if line.strip():
                        logger_func(line.strip())
        except (OSError, ValueError) as e:
            # 文件描述符已关闭或无效时静默处理
            pass
        finally:
            self.set_config_json(error_message)
            # 确保关闭文件描述符（仅一次）
            if fd and fd >= 0:
                try:
                    os.close(fd)
                except OSError:
                    pass
    def stream_printer(self, pipe, fn):
        try:
            for line in iter(pipe.readline, b''):
                if line:
                    fn(f"{line.decode('utf-8', errors='ignore')}", end='', flush=True)
        except:
            pass
        finally:
            pipe.close()
 
    def run_command_realtime(self, command, log=None):
        """执行命令并实时捕获输出"""
        process = None
        try:
            process = subprocess.Popen(
                command,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                shell=True,
                close_fds=True
            )

            # 配置日志函数
            log_info = print
            if log and hasattr(log, 'info'):
                log_info = log.info

            # 启动日志线程
            log_thread = threading.Thread(
                target=self.stream_printer,
                args=(process.stdout, log_info)
            )
            log_thread.start()

            # 等待进程和线程结束
            process.wait()
            process.stdout.close()
            log_thread.join()

        finally:
            # 确保进程终止（防止僵尸进程）
            if process and process.poll() is None:
                process.terminate()
                process.wait()
        return process.returncode if process else -1
        
    def tail(self):
        os.system('touch /var/{}'.format(self.log))

    def get_simple_versions(self, package_name,  package_version, package_constraint):
        """
        获取包的简化版本列表
        """
        try:
            if package_name not in self.package._cache:
                return None
            
            package = self.package._cache[package_name]
            versions = [version.version for version in package.versions]
            self.package_depends_list.append(
                {
                    "package": package,
                    "package_name": package_name,
                    "version": versions,
                    "is_installed": package.is_installed,
                    "installed_version": package.installed,
                    "control_depend": None if package_constraint == "" else package_version,
                    "package_constraint": None if package_constraint == "" else package_constraint
                }
            )
            
        except Exception as e:
            print(f"错误: {e}")
            return None

    @property
    def deb_dependencies(self):
        deb_list = self.package.depends
        if deb_list:
            return deb_list
        return None
    
    def get_deb_depends_message_with_apt(self):
        """
        使用python-apt的debfile模块获取依赖, 处理"或"关系
        """
        try:
            # 获取各种依赖关系
            deb_list = self.deb_dependencies

            if deb_list:
                for deb_depend_info in deb_list:
                    if len(deb_depend_info) > 1:
                        for d in deb_depend_info:
                            self.parse_relationship_list(d)
                        continue
                    self.parse_relationship_list(deb_depend_info[0])
        except Exception as e:
            print(f"解析deb文件失败: {e}")
            return None

    def parse_relationship_list(self, deb_depend_info):
        package_name = deb_depend_info[0]
        if package_name in self.blacklist:
            return
        package_version = deb_depend_info[1]
        package_constraint = deb_depend_info[2]
        self.get_simple_versions(package_name, package_version, package_constraint)

    def _filter_nonexistent_packages(self):
        """过滤 apt_install_list 中在 apt 缓存里不存在的包，避免安装时报错"""
        if not self.apt_install_list.strip():
            return
        try:
            cache = apt.Cache()
            valid = []
            for item in self.apt_install_list.strip().split():
                pkg_name = item.split('=')[0]
                if pkg_name in cache:
                    valid.append(item)
                else:
                    print("包 '{}' 在 apt 缓存中不存在，跳过".format(pkg_name))
            self.apt_install_list = ' '.join(valid) + ' ' if valid else ''
        except Exception as e:
            print("校验安装列表时出错: {}".format(e))

    def get_depends_with_apt_cache(self):
        pkgname = self.package.pkgname
        for package_info in self.package_depends_list:
            if package_info.get("is_installed"):
                self.get_installed_package_version(package_info)
            else:
                self.get_not_installed_package_version(package_info)
                
        for key, value in self.package_depends_dist.items():
            if value is None:
                self.apt_install_list += "{} ".format(key)
            else:
                self.apt_install_list += "{}={} ".format(key, value)
        
        if self.whitelist_package.get(pkgname):
            self.apt_install_list += " ".join(self.whitelist_package.get(pkgname))
        self._filter_nonexistent_packages()
        if pkgname == "browser360-cn-stable" or pkgname == "suwellreaderpro.appstore":
            os.system("rm -rf /usr/share/applications/defaults.list")

    def get_version(self, apt_versions, depend_version, compare):
        ret = subprocess.getoutput("dpkg --compare-versions {} {} {} && echo True".format(apt_versions, compare, depend_version))
        if ret:
            return True

    def kare_install_package(self):
        pkgname = self.package.pkgname
        # 白名单下载
        if pkgname in self.v10_apt_list and self.RELEASE == "Kylin V10" or package in self.sp1_apt_list and self.RELEASE == "Kylin V10 SP1" or (self.RELEASE == "Kylin V11" or self.RELEASE.startswith("openKylin 2")):
            if self.RELEASE == "Kylin V11" or self.RELEASE.startswith("openKylin 2"):
                ret = self.run_command_realtime('SYSTEMCTL_FORCE_BUS=1 SYSTEMD_IGNORE_CHROOT=1 DEBIAN_FRONTEND=noninteractive {} -f install -y --allow-downgrades {} -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" '.format(self.apt_path, self.deb))
            else:
                ret = self.run_command_realtime('DEBIAN_FRONTEND=noninteractive {} -f install -y {} -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" '.format(self.apt_path, self.deb))
            return -1 if ret != 0 else 0
                
        # 依赖下载
        ret = self.run_command_realtime('DEBIAN_FRONTEND=noninteractive SYSTEMCTL_FORCE_BUS=1 SYSTEMD_IGNORE_CHROOT=1 {} -f install -y {} -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" | tee -a /var/{} '.format(self.apt_path, self.apt_install_list, self.log))
        if ret != 0:
            ret = self.run_command_realtime('SYSTEMCTL_FORCE_BUS=1 SYSTEMD_IGNORE_CHROOT=1 DEBIAN_FRONTEND=noninteractive {} -f install -y {} -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" '.format(self.apt_path, self.deb))
            return -1 if ret != 0 else 0

        os.system('{} install -f -y'.format(self.apt_path))
        ret = self.run_command_realtime('DEBIAN_FRONTEND=noninteractive dpkg --force-confdef --force-confold -i {} '.format(self.deb))
        return ret

    def kare_install_other_package(self, pkgname):
        if self.whitelist_package.get(pkgname):
            self.apt_install_list += " ".join(self.whitelist_package.get(pkgname))
        self._filter_nonexistent_packages()    
        self.run_command_realtime('DEBIAN_FRONTEND=noninteractive SYSTEMCTL_FORCE_BUS=1 SYSTEMD_IGNORE_CHROOT=1 {} -f install -y {} -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" | tee -a /var/{} '.format(self.apt_path, self.apt_install_list, self.log))
        ret = self.run_command_realtime('DEBIAN_FRONTEND=noninteractive {} -f install -y {} -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" '.format(self.apt_path, self.deb))
        return -1 if ret != 0 else 0

    def get_installed_package_version(self, package_info):
        # 无版本不更新
        if package_info.get("package_constraint") is None:
            return
        
        # 先判断已安装的包是否满足，不满足升级
        elif package_info.get("package_constraint") == ">":
            if self.get_version(package_info.get("installed_version").version, package_info.get("control_depend"), "gt"):
                return
            else:
                self.get_not_installed_package_version(package_info)

        elif package_info.get("package_constraint") == ">=":
            if self.get_version(package_info.get("installed_version").version, package_info.get("control_depend"), "ge"):
                return
            else:
                self.get_not_installed_package_version(package_info)

        #小于 小于等于排序
        elif package_info.get("package_constraint") == "<":
            if self.get_version(package_info.get("installed_version").version, package_info.get("control_depend"), "gt"):
                self.get_not_installed_package_version(package_info)

        else:
            if package_info.get("installed_version").version == package_info.get("control_depend") is False:
                self.get_not_installed_package_version(package_info)

    def get_not_installed_package_version(self, package_info):
        # 无版本要求拿最高版本
        if package_info.get("package_constraint") is None:
            self.package_depends_dist.setdefault(package_info.get("package_name"), None)
        
        # 大于，大于等于拿最高版本
        elif package_info.get("package_constraint") == ">":
            if self.get_version(package_info.get("version")[0], package_info.get("control_depend"), "gt"):
                self.package_depends_dist.setdefault(package_info.get("package_name"), None)

        elif package_info.get("package_constraint") == ">=":
            if self.get_version(package_info.get("version")[0], package_info.get("control_depend"), "ge"):
                self.package_depends_dist.setdefault(package_info.get("package_name"), None)

        #小于 小于等于排序
        elif package_info.get("package_constraint") == "<":
            for v in package_info.get("version"):
                if self.get_version(package_info.get("control_depend"), v, "gt"):
                    self.package_depends_dist[package_info.get("package_name")] = v
                    return

        else:
            if package_info.get("control_depend") in package_info.get("version"):
                self.package_depends_dist[package_info.get("package_name")] = package_info.get("control_depend")

    def remove_package(self, package_name):
        remove_cmd = f"dpkg -P {package_name}"
        remove_ret = subprocess.getstatusoutput(remove_cmd)
        if remove_ret[0] != 0:
            if os.path.exists("/var/lib/dpkg/info/{}.postrm".format(package_name)):
                os.remove("/var/lib/dpkg/info/{}.postrm".format(package_name))
            if os.path.exists("/var/lib/dpkg/info/{}.postinst".format(package_name)):
                os.remove("/var/lib/dpkg/info/{}.postinst".format(package_name))
            if os.path.exists("/var/lib/dpkg/info/{}.prerm".format(package_name)):
                os.remove("/var/lib/dpkg/info/{}.prerm".format(package_name))
            if os.path.exists("/var/lib/dpkg/info/{}.preinst".format(package_name)):
                os.remove("/var/lib/dpkg/info/{}.preinst".format(package_name))
            #删除/var/llib/dpkg/info/目录下的文件
        remove_ret = subprocess.getstatusoutput(remove_cmd)
        if remove_ret[0] != 0:
            print(f'安装{package_name}失败，之后进行卸载也失败')
            for root, dirs, files in os.walk(Path('/var/lib/dpkg/info/')):
                for file in files:
                    # 检查文件名（不含后缀）是否匹配
                    if os.path.splitext(file)[0] == package_name:
                        file_path = os.path.join(root, file)
                        os.remove(file_path)
                        print(f"Deleted: {file_path}")
            # 修改dpkg状态
            status_file = "/var/lib/dpkg/status"
            if os.path.exists(status_file):
                del_cmd=f'sed -i \'/{package_name}/,/^$/d\' {status_file}'
                ret = subprocess.getstatusoutput(del_cmd)
                if ret[0] != 0:
                    print(f"Failed to modify {status_file}")
        return True

class BrowserAgent():

    def __init__(self):

        self.brwoser_list = self.get_browser_list()

        self.xdg_list = [
            "/usr/bin/xdg-open",
            "/usr/bin/gvfs-open",
            "/usr/bin/gio",
        ]
        self.KAIMING_DESKTOP_TMPPATH = "/tmp/kaiming_desktops/"

    def get_browser_list(self):
        try:  
            with open("/etc/kare/host-browser-list", 'r') as file:
                data = json.load(file)
        except Exception:
            data = []
        if data:
            return data
        else:
            return []

    def update_browser(self):
        for browser in self.brwoser_list:
                #如果是开明包，browser 里面写的是其 desktop 文件的绝对路径,一定会包含 kaiming 和 desktop 字段
                dirname = os.path.dirname(browser)
                if not os.path.exists(dirname):
                    os.makedirs(dirname)

                if "kaiming" in browser and "desktop" in browser:
                    try:
                        filename = os.path.basename(browser)                    
                        shutil.copy(self.KAIMING_DESKTOP_TMPPATH + filename, dirname)
                    except Exception as e:
                        print("向容器内迁移开明desktop文件失败")
                else:
                    #如果不是开明的 desktop文件，那么browser内容就是 Exec 中的 cmdline,包括"/opt/kaiming-tools/bin"
                    if not os.path.exists(browser):
                        try:
                            os.system("ln -sf /usr/bin/hostAgent {}".format(browser))
                        except Exception as e:
                            print("容器内外 {} 调用代理创建有异常".format(browser))

    def update_xdg(self):
        for xdg in self.xdg_list:
            os.system("ln -sf /usr/bin/hostAgent {}".format(xdg))
        os.system("ln -sf /usr/bin/python2 /usr/bin/python")
        # os.system("chmod +x /usr/bin/kylin-installer")
        
    def update_dpkg(self):
        dpkg_path = "/usr/bin/dpkg"
        if not os.path.exists(dpkg_path):
            return False
        print("更新容器内 dpkg 可执行文件")
        try:
            with open(dpkg_path, 'r', encoding='utf-8', errors='ignore') as f:
                first_line = f.readline().strip()
                if not first_line.startswith('#!'):
                    try:
                        subprocess.run(['cp', '-f', "/usr/bin/dpkg", "/usr/bin/dpkg.real"], check=True)
                        subprocess.run(['cp', '-f', "/usr/bin/dpkg-wrapper.sh", "/usr/bin/dpkg"], check=True)
                        return True
                    except subprocess.CalledProcessError as e:
                        return False
        except Exception:
            pass
        return False
    
    def update_media(self):
        if not os.path.exists("/media") or not os.path.islink("/media"):
            os.system("ln -sf /run/media/ /media")


class HostAgent:

    def __init__(self):
        self.common_list = [
            "who",
            "users"
        ]
        self.TMP_FILE = "/tmp/containerInit.tmp"
        self.DBUS_SETTINGS = {
            "dest": "com.kylin.kare.Sessionhost",
            "path": "/com/kylin/kare/Sessionhost",
            "interface": "com.kylin.kare.Sessionhost",
            "method": "call"
        }
        self.uid = self.get_user_by_login1()
        if self.uid is None:
            self.uid = 1000
        self.bus_address = "unix:path=/run/user/{}/bus".format(self.uid)
    def get_user_by_login1(self):
        try:
            # 获取系统总线
            bus = dbus.SystemBus()
            
            # 获取 login1 管理接口
            login1_proxy = bus.get_object(
                "org.freedesktop.login1",
                "/org/freedesktop/login1"
            )
            manager_iface = dbus.Interface(
                login1_proxy,
                "org.freedesktop.login1.Manager"
            )
            
            # 调用 ListUsers 方法
            users = manager_iface.ListUsers()
            
            # 遍历用户
            for user in users:
                # user 结构为 (uid, username, object_path)
                user_path = user[2]
                user_proxy = bus.get_object("org.freedesktop.login1", user_path)
                
                # 获取用户属性接口
                user_iface = dbus.Interface(
                    user_proxy,
                    dbus_interface=dbus.PROPERTIES_IFACE
                )
                
                # 读取 State 属性
                state = user_iface.Get(
                    "org.freedesktop.login1.User",
                    "State"
                )
                
                if state == "active":
                    return user[0]
            
            return None
        except dbus.exceptions.DBusException as e:
            return None
        except Exception as e:
            return None
    

    def get_dbus_response(self, command):
        """通过DBus获取命令响应"""
        try:
            # 连接会话总线
            bus = dbus.SessionBus()
            proxy = bus.get_object(self.DBUS_SETTINGS["dest"], self.DBUS_SETTINGS["path"])
            interface = dbus.Interface(proxy, self.DBUS_SETTINGS["interface"])
            
            # 调用方法并获取响应
            response = interface.call(command)
            return str(response) if response else ""
        
        except dbus.exceptions.DBusException as e:
            print(f"DBus调用失败: {e}")
            return ""

    def create_executable_script(self, cmd):
        value = r"""
import dbus
import os

def main():
    try:
        os.seteuid({})
        bus_connect = dbus.bus.BusConnection("{}")
        proxy = bus_connect.get_object("com.kylin.kare.Sessionhost", "/com/kylin/kare/Sessionhost")
        interface = dbus.Interface(proxy, "com.kylin.kare.Sessionhost")
        response = interface.call("{}")
        print(response)
    
    except dbus.exceptions.DBusException as e:
        print("")

if __name__ == "__main__":
    main()
""".format(self.uid, self.bus_address, cmd)

        """创建带sudo权限的可执行脚本"""
        try:
            # 生成目标路径
            efile = f"/usr/bin/{cmd}-kare"
            
            # 通过sudo创建文件
            subprocess.run(
                ["sudo", "-S", "touch", efile],
                check=True
            )
            
            # 写入内容
            subprocess.run(
                ["sudo", "-S", "tee", efile],
                input=f"#!/usr/bin/python3\n\n{value}\n".encode(),
                check=True,
                stdout=subprocess.DEVNULL
            )
            
            # 设置可执行权限
            subprocess.run(
                ["sudo", "-S", "chmod", "a+x", efile],
                check=True
            )
            # 创建符号链接
            which_path = subprocess.check_output(["which", cmd], text=True).strip()
            subprocess.run(
                ["sudo", "-S", "ln", "-sf", efile, which_path],
                check=True
            )
            
        except subprocess.CalledProcessError as e:
            print(f"命令执行失败: {e}")
        except Exception as e:
            print(f"未知错误: {e}")


def create_service_wrapper():
    service_wrappers = {
        "/usr/sbin/service":"/usr/sbin/service.kare.real",
        "/usr/sbin/update-rc.d":"/usr/sbin/update-rc.d.kare.real",
        "/usr/sbin/invoke-rc.d":"/usr/sbin/invoke-rc.d.kare.real",
        "/usr/bin/systemctl":"/usr/bin/systemctl.kare.real"
    }
    for k,v in service_wrappers.items():
        if os.path.exists(v):
            continue
        os.system("mv {} {}".format(k, v))
        os.system("ln -sf /usr/bin/kare-systemctl.py {}".format(k))
        os.system("chmod +x {}".format(k))

    """
    检查dpkg包是否安装且状态为ii
    """
def check_package(package_name):
    try:
        # 运行dpkg查询命令
        result = subprocess.run(
            ['dpkg', '-l', package_name],
            capture_output=True,
            text=True,
            check=False  # 包不存在时dpkg会返回非0，不抛出异常
        )
        
        # 解析输出
        for line in result.stdout.split('\n'):
            # 查找以'ii'开头的行
            if line.startswith('ii'):
                # 提取包名
                parts = line.split()
                if len(parts) >= 2 and parts[1] == package_name:
                    return True
        print(f"包 '{package_name}' 未安装或状态不是 ii")
        return False
    except Exception as e:
        print(f"检查包时出错: {e}")
        return False

class ContainerOptPath():

    def __init__(self):
        self.path_list = ["/opt", "/opt/app", "/opt/apps"]
        self.preinst_opt_path = set()
        self.postinst_opt_path = set()
        self.ensure_mimeapps_list()

    def find_opt_path(self, path_list):
        for path in self.path_list:
            if os.path.exists(path=path) is False:
                continue
            for p in os.listdir(path):
                path_list.add(os.path.join(path, p))

    def ensure_mimeapps_list(self):
        mimeapp = "/usr/share/applications/mimeapps.list"
        if not os.path.exists(mimeapp):
            Path(mimeapp).touch()


"""
@brief 检查是否应该执行apt update，并在需要时实际执行
@return True表示已执行或应该执行apt update，False表示不需要执行
"""
def should_execute_apt_update():
    # 检查系统版本，只有在v10sp1环境下才执行apt update
    apt_path = "apt.orig" if os.path.exists("/usr/bin/apt.orig") else "apt"

    try:
        release = subprocess.getoutput("cat /etc/lsb-release | grep DISTRIB_DESCRIPTION | awk -F '=' '{print $2}'").strip("\"")
        if release != "Kylin V10 SP1":
            return False
    except Exception as e:
        print("无法确定系统版本，跳过apt update: {}".format(e))
        return False
        
    flag_file = "/tmp/kare_apt_update_done"
    # 检查标志文件是否存在
    if not os.path.exists(flag_file):
        # 标志文件不存在，应该执行apt update，并创建标志文件
        print("首次安装或标志文件不存在，将执行apt update")
        
        try:
            os.system('{} update'.format(apt_path))
            os.system("apt-file update")
            os.system("pam-auth-update --package --enable kim")
            # 只有执行成功才创建标志文件
            with open(flag_file, 'w') as f:
                f.write("apt update executed")
            print("已创建标志文件: {}".format(flag_file))
        except Exception as e:
            print("执行apt update失败: {}".format(e))
            # 执行失败不创建标志文件
            return False
        return True
    else:
        # 标志文件已存在，不执行apt update
        print("标志文件已存在，跳过apt update")
        return False


if __name__ == "__main__":
    package = sys.argv[1]
    host = HostAgent()
    package_name = subprocess.getoutput("dpkg -I {} | grep {}".format(package, "Package: ")).split("Package: ")[-1]
    os.environ["DBUS_SESSION_BUS_ADDRESS"] = host.bus_address
    for cmd in host.common_list:
        host.create_executable_script(cmd)
    is_over_install = check_package(package_name)

    create_service_wrapper()
    should_execute_apt_update()
    
    opt = ContainerOptPath()
    opt.find_opt_path(opt.preinst_opt_path)
    # 执行安装
    kare = KareApt(sys.argv[1])
    p1 = threading.Thread(target=kare.tail, args=()) 
    p1.daemon = True
    p1.start()
    if kare.package == None:
        ret = kare.kare_install_other_package(package_name)
    else:
        kare.get_deb_depends_message_with_apt()
        kare.get_depends_with_apt_cache()  
        ret = kare.kare_install_package()
    if ret !=0:
        if not is_over_install:
            kare.remove_package(package_name)
        exit(11)
    
    print("==========Installation succeeded==========")
    opt.find_opt_path(opt.postinst_opt_path)
    opt_list = []
    [opt_list.append(p) for p in opt.postinst_opt_path - opt.preinst_opt_path]
    if opt_list != []:
        with open("/etc/kare/container-opt-path", 'w') as file:
            json.dump(opt_list, file) 
    b = BrowserAgent()
    b.update_browser()
    b.update_xdg()
    b.update_dpkg()
    b.update_media()
    os.system("/usr/bin/python3 /usr/bin/fix_depends.py {}".format(package_name))
    print("==========Dependencies resolved==========")
