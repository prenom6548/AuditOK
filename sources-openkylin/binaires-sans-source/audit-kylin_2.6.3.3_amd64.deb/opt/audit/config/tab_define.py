from utils.system_utils import OSUtils
DEEP_SCAN_NAME = "已删除文件" if OSUtils.is_windows() else "已删除文件检查"
