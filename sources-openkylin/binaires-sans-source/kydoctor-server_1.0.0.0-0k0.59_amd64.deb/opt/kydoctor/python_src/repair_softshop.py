"""Copyright (c) KylinSoft  Co., Ltd. [2024].All rights reserved.
/*[kydoctor] licensed under the [Your LICENSE].
***************Your LICENSE Messages***********************
Author: [WangShuai]
Create: [2024]
"""
import json
import os
import sys
import re

from common_variables import PRINT_DEBUG

def print_deg(print_str):
    if PRINT_DEBUG == 1:
        print(print_str)
"""
返回值：
0：成功
1："系统本身存在依赖问题，请手动执行sudo dpkg --configure -a、sudo apt-get install -f修复"，直接返回
2：可以修复，通过检测，如果当前包依赖的包有二层依赖或包找不到的情况，则返回2
3：可以修复，通过检测，如果当前包依赖的包没有二层依赖或包找不到的情况，则修复，成功返回0，失败返回3
"""
def repairsoftshop():
    try:
        line_table = []
        with open("/tmp/kydoctor_softshop",'r') as f:
            lines = f.readlines()
            #print("line_s = ",line_s)
            #lines = line_s.split("\n")
            print_deg("----------lines = "+str(lines))
            for line in lines:
                if "Depends" in line and "install" in line:
                    if "not" in line and "installable" in line:
                        line_table.insert(0,line) #该应用包名的依赖冲突，优先检测but is not installable的依赖问题
                    else: 
                        line_table.append(line)
        print_deg("i am in repairsoftshop ,line_table = "+str(line_table))
        dependsdeb_num = 0
        for strstr in line_table:
            str_none = strstr.split("Depends")
            if str_none[0].strip() != "":
                dependsdeb_num = dependsdeb_num +1  #存在包名以外的包有依赖问题
        if dependsdeb_num > 1:
            print_deg("dependsdeb_num > 1")
            os.system("bash /opt/kydoctor/python_src/fix-tool.sh -y ")
            #print("------------------cc = ",cc)
            ret = os.system("bash /opt/kydoctor/python_src/fix-tool.sh -c > /dev/null")
            if ret == 0:
                return 0
            else:
                return 1
            #return 1 #提示：手动修复的方法--"系统本身存在依赖问题，请手动执行sudo dpkg --configure -a、sudo apt-get install -f修复"
        elif dependsdeb_num == 1: #将所有的依赖行都扫一遍，如果其还有依赖或失败，则退出，提示手动修复
            print_deg("dependsdeb_num == 1")
            for strstr in line_table:
                str_none = strstr.split("Depends:")
                if "(" in str_none[1] and ")" in str_none[1]:
                    kuohao_str = re.search(r'\((.*?)\)',str_none[1]).group(1)
                    kuohao_str = kuohao_str.replace(" ","").strip()
                    
                    if "=" in kuohao_str:
                        kuohao_str = kuohao_str.split('=')[1]
                    elif ">" in kuohao_str:
                        kuohao_str = kuohao_str.split('>')[1]
                    #print("kuohao_str=",kuohao_str)
                    str_none_d = str_none[1].strip()
                    deb_name = str_none_d.split()
                    #print("deb_name =",deb_name[0])
                    deb_name_id = deb_name[0]+"="+kuohao_str
                    print_deg("deb_name_id ="+str(deb_name_id))

                    #得到包名以及对应的版本号，接下来apt-get install deb_name_id,并判断返回值
                    update_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 apt-get --print-uris install " + deb_name_id + " 2>&1"
                    ces = os.popen(update_cmd)
                    ces_str = ces.read()

                    if "Depends" in ces_str or "depends" in ces_str or "E: " in ces_str:
                        print_deg("depends other package or E: ,don't update")
                        return 2
                    #cmd_deb = "apt-get install "+ deb_name_id
                    #print("cmd_deb =",cmd_deb)
                    # cc = os.system(cmd_deb)
                    # if cc != 0:
                    #     return 3 #提示修复失败
                else:
                    str_none_d = str_none[1].strip()
                    deb_name = str_none_d.split()
                    print_deg("deb_name ="+str(deb_name[0]))
                    update_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 apt-get --print-uris install " + deb_name[0] + " 2>&1"
                    ces = os.popen(update_cmd)
                    ces_str = ces.read()

                    if "Depends" in ces_str or "depends" in ces_str or "E: " in ces_str:
                        print_deg("depends other package or E: ,don't update")
                        return 2
                    #得到包名以及对应的版本号，接下来apt-get install deb_name,并判断返回值
                    #cmd_deb = "apt-get install "+ deb_name[0]
                    #print("cmd_deb =",cmd_deb)
                    # cc = os.system(cmd_deb)
                    # if cc != 0:
                    #     return 3 #提示修复失败
            #经过上面一圈的for循环，如果没有return出去，就开始实际的安装工作
            print_deg("3----------------- start install")
            for strstr in line_table:
                str_none = strstr.split("Depends:")
                if "(" in str_none[1] and ")" in str_none[1]:
                    kuohao_str = re.search(r'\((.*?)\)',str_none[1]).group(1)
                    kuohao_str = kuohao_str.replace(" ","").strip()
                    
                    if "=" in kuohao_str:
                        kuohao_str = kuohao_str.split('=')[1]
                    elif ">" in kuohao_str:
                        kuohao_str = kuohao_str.split('>')[1]
                    #print("kuohao_str=",kuohao_str)
                    str_none_d = str_none[1].strip()
                    deb_name = str_none_d.split()
                    #print("deb_name =",deb_name[0])
                    deb_name_id = deb_name[0]+"="+kuohao_str
                    print_deg("deb_name_id ="+str(deb_name_id))

                    #得到包名以及对应的版本号，接下来apt-get install deb_name_id,并判断返回值
                    cmd_deb = "apt-get install "+ deb_name_id
                    print_deg("cmd_deb ="+str(cmd_deb))
                    cc = os.system(cmd_deb)
                    if cc != 0:
                        print_deg("cc != 0-------------1\n")
                        return 3 #提示修复失败
                else:
                    str_none_d = str_none[1].strip()
                    deb_name = str_none_d.split()
                    print_deg("deb_name ="+str(deb_name[0]))

                    #得到包名以及对应的版本号，接下来apt-get install deb_name,并判断返回值
                    cmd_deb = "apt-get install "+ deb_name[0]
                    print_deg("cmd_deb ="+str(cmd_deb))
                    cc = os.system(cmd_deb)
                    if cc != 0:
                        print_deg("cc != 0-------------------2\n")
                        return 3 #提示修复失败
        else:
            print_deg("dependsdeb_num == 0")

        pass
    except Exception as e:
        print("i am in repairsoftshop,e = ",e)
        return 3  #提示修复失败
    return 0
def repairsoftshop_s():
    pass
if __name__ == "__main__":
    ret = repairsoftshop()
    print("i am in repairsoftshop,main ==  ret = ",ret)
    exit(ret)
