"""Copyright (c) KylinSoft  Co., Ltd. [2024].All rights reserved.
/*[kydoctor] licensed under the [Your LICENSE].
***************Your LICENSE Messages***********************
Author: [WangShuai]
Create: [2024]
"""
#公共变量设置
PRINT_DEBUG = 0  #打印日志