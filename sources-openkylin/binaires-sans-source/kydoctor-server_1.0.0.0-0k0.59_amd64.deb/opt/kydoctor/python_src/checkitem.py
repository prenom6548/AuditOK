"""Copyright (c) KylinSoft  Co., Ltd. [2024].All rights reserved.
/*[kydoctor] licensed under the [Your LICENSE].
***************Your LICENSE Messages***********************
Author: [WangShuai]
Create: [2024]
"""
import json
import os
import sys
import sqlite3 as sqlite
import glob
import configparser
#import subprocess
#from kysdk import Sysinfo 因为在2107和2203上面kysdk包无法使用，暂时将其功能屏蔽
import shutil
from common_variables import PRINT_DEBUG

def print_deg(print_str):
    if PRINT_DEBUG == 1:
        print(print_str)

'''--------------------条件检索开始--------------------'''
#产线 wayland/hwe/xc/openkylin
def condition_production_line(production_line):
    """下面这段代码，是老版本检测openkylin的代码，配合上层if调用来实现功能
    if production_line == "":
        cc = os.popen("cat /etc/lsb-release")
        cc_str = cc.read()
        if "openKylin" in cc_str:
            return False 
        else:
            return True
    """
    p_line = ""
    #通过判断/etc/lsb-release
    cc = os.popen("cat /etc/lsb-release")
    cc_str = cc.read()
    if "openKylin" in cc_str:
        p_line = "openkylin"
    #通过判断/etc/kylin-build文件中是否有hwe字符串来区分是否是hwe产线
    if p_line == "":
        cc = os.popen("cat /etc/kylin-build")
        cc_str = cc.read()
        if "hwe" in cc_str:
            p_line = "hwe"
    #通过env | grep wayland来检索是否是wayland产线
    if p_line == "":
        cc = os.popen("env | grep wayland")
        cc_str = cc.read()
        if cc_str != "":
            p_line = "wayland"
    #都不是的话 才是xc产线
    if p_line == "":
        p_line = "xc"
    
    if production_line in p_line:
        return True
    else:
        return False
#系统buildid
def get_buildid():
    buildid_str = ""
    cc = os.popen("cat /etc/kylin-build")
    cc_strs = cc.readlines()
    for cc_str in cc_strs:
        #if "buildid" in cc_str and buildid in cc_str:
        #    return True
        if "buildid" in cc_str:
            buildid_str = cc_str
            break
    print_deg("i am in get_buildid,buildid_str ="+str(buildid_str))
    return buildid_str
def get_osrelease():
    osrelease = "2107"
    cc = os.popen("cat /etc/os-release")
    cc_strs = cc.readlines()
    for cc_str in cc_strs:
        if "KYLIN_RELEASE_ID" in cc_str:
            cc_os = cc_str.split("=")
            osrelease = cc_os[1]
            break
    print_deg("i am in get_osrelease,osrelease ="+str(osrelease))
    return osrelease
    
def condition_buildid(buildid_line):
    ret_cond = True
    strstrs=buildid_line.split("&")
    for strstr in strstrs:
        ret_cond = True
        strstr1 = strstr.strip("[")
        strstr2 = strstr1.strip("]")
        print_deg("strstr2 = "+str(strstr2))
        bid_str = strstr2.split("|")
        print_deg("buildid_str = "+str(bid_str)+","+str(bid_str[0]))
        if bid_str[0] != "NULL" and bid_str[0] != "None":
            buildid_str = get_buildid()
            if bid_str[0] in buildid_str:
                print_deg("bid_str[0] in buildid_str")
                ret_cond = True
            else:
                print_deg("bid_str[0] not in buildid_str")
                ret_cond = False
        if ret_cond == True and bid_str[3] != "NULL" and bid_str[3] != "None":
            osrelease_str = get_osrelease()
            if bid_str[3] in osrelease_str:
                print_deg("bid_str[3] in osrelease_str")
                ret_cond = True
                return ret_cond
            else:
                print_deg("bid_str[3] not in osrelease_str")
                ret_cond = False
    print_deg("ret_cond = "+str(ret_cond))
    return ret_cond
    pass
#系统环境
def condition_sys_env(sys_env):
    #临时增加if判断 一旦有云平台的检测，都返回False,因为在2107和2203上面kysdk包无法使用，暂时将其功能屏蔽
    if "云" in sys_env:
        return False
    
    sys_env_str = ""
    #通过判断
    cc = os.popen("systemd-detect-virt")
    cc_str = cc.read()
    if "none" in cc_str:
        sys_env_str = "物理环境"
    else:
        pass
        #因为在2107和2203上面kysdk包无法使用，暂时将其功能屏蔽
        # sys1 = Sysinfo()
        # ret_str = sys1.getSystemHostCloudPlatform()
        # #物理环境：none
        # #华为云：huawei, FC, HCS, HWC, HCSO , SCE, 
        # #天翼云：ctyun
        # if "none" in ret_str:
        #     sys_env_str = "物理环境" 
        # elif "huawei" in ret_str or "FC" in ret_str or "HCS" in ret_str or "HWC" in ret_str or "HCSO" in ret_str or "SCE" in ret_str:
        #     sys_env_str = "华为云"
        # elif "ctyun" in ret_str:
        #     sys_env_str = "天翼云"
    
    if sys_env_str in sys_env:
        return True
    else:
        return False
    pass
#架构
def condition_arch(arch):
    p_line = ""
    #通过判断/etc/kylin-build文件中是否有hwe字符串来区分是否是hwe产线
    cc = os.popen("arch")
    cc_str = cc.read()
    if arch in cc_str:
        print_deg("i am in condition_arch ,return True")
        return True
    else:
        print_deg("i am in condition_arch ,return False")
        return False
#硬件 --注意（华为机型没有显卡的lspci指令，后期如果有华为相关显卡bug需要单独处理）
def condition_hardware_gpu(htype):
    return_ret = True
    try:
        #hardware_list = htype.split("---")
        #for hardware in hardware_list:
            #hardware_table = hardware.split("***")
            #if hardware_table[0] == "0x0008":  #显卡检索
                print_deg("i am in condition_hardware_gpu: htype == 0x0008")
                cc = os.popen("LANGUAGE=en_US LANG=en_US lspci -vnn | grep VGA") #先检索普通机型，没有的话用华为的指令再检索
                cc_str = cc.read()
                if htype in cc_str:
                    return_ret = True
                else:
                    return False
            # elif hardware_table[0] == "0x0003":  #CPU
            #     cc = os.popen("lscpu")
            #     cc_str = cc.read()
            #     if hardware_table[1] in cc_str:
            #         return_ret = True
            #     pass
            # elif hardware_table[0] == "0x0002":  #EC
            #     pass
            # elif hardware_table[0] == "0x0001":  #BIOS
            #     pass
            #     # cc = os.popen("LANGUAGE=en_US LANG=en_US gpuinfo")
            #     # cc_strs = cc.readlines()
            #     # for cc_str in cc_strs:
            #     #     if "type" in cc_str and "GPU" in cc_str:
            #     #         if type in cc_str:
            #     #             return True
    except Exception as e:
        print_deg("i am in condition_hardware_gpu,e = "+e)
        return False
    return return_ret
#硬件--cpu
def condition_hardware_cpu(type1):
    try:
        if type1 == "M900":
            cc = os.popen("LANGUAGE=en_US LANG=en_US dmidecode -t processor")
            cc_strs = cc.readlines()
            for cc_str in cc_strs:
                if "Version:" in cc_str:
                    if type1 in cc_str:
                        return True
        else:
            cc = os.popen("LANGUAGE=en_US LANG=en_US lscpu")
            cc_strs = cc.readlines()
            for cc_str in cc_strs:
                if "Model" in cc_str and "name" in cc_str:
                    if type1 in cc_str.lower():
                        return True
    except Exception as e:
        print_deg("i am in condition_hardware_cpu,e = "+e)
        return False
    return False
#硬件
def condition_hardware(hardware):
    return_tf = True
    hardware_list = hardware.split("---")
    for hdware in hardware_list:
        hd = hdware.split("***")
        if hd[0] == "0x0003" and hd[1] != "": #CPU
            return_tf = condition_hardware_cpu(hd[1])
            if return_tf == False:
                return False
        elif hd[0] == "0x0008" and hd[1] != "": #显卡型号
            #华为机器通过gpuinfo指令抓取，其他机型通过lshw -C display抓取
            return_tf = condition_hardware_gpu(hd[1])
            if return_tf == False:
                return False
        else:
            return False
    return True
#问题组件--版本号
def condition_assembly_banben(deb_package):
    try:
        command = "dpkg -l | grep " + deb_package
        cc = os.popen(command)
        cc_strs = cc.readlines()
        for cc_str in cc_strs:
            deb_p = cc_str.split()[1]
            if deb_p.strip() == deb_package.strip():            
                return cc_str.split()[2]
    except Exception as e:
        print_deg("i am in condition_assembly_banben,e = "+e)
        return ""
    return ""
#问题组件--版本号对比
def condition_assembly_banben_com(compare,now_banben,com_banben):
    try:
        command = "dpkg --compare-versions " + now_banben + " " + compare + " " + com_banben + " && echo 1 || echo 0"
        cc = os.popen(command)
        cc_str = cc.read()
        if "1" in cc_str:
            return 1
        else:
            return 0
    except Exception as e:
        print_deg("i am in condition_assembly_banben_com,e = "+e)
        return 0
#问题组件
def condition_assembly(assembly):
    #lt：less than 小于
    #le：less than or equal to 小于等于
    #eq：equal to 等于
    #ne：not equal to 不等于
    #ge：greater than or equal to 大于等于
    #gt：greater than 大于
    assembly_list = assembly.split("||")
    for assembly_str in assembly_list:
        if "<=" in assembly_str:
            print_deg("i am in condition_assembly----- <=")
            assembly_table = assembly_str.split("<=")
            ret = condition_assembly_banben(assembly_table[0])
            if ret == "":
                return False
            ret1 = condition_assembly_banben_com("le",ret,assembly_table[1])
            if ret1 == 0:
                return False
            pass
        elif ">=" in assembly_str:
            print_deg("i am in condition_assembly----- >=")
            assembly_table = assembly_str.split(">=")
            ret = condition_assembly_banben(assembly_table[0])
            if ret == "":
                return False
            ret1 = condition_assembly_banben_com("ge",ret,assembly_table[1])
            if ret1 == 0:
                return False
            pass
        elif "==" in assembly_str:
            print_deg("i am in condition_assembly----- ==")
            assembly_table = assembly_str.split("==")
            ret = condition_assembly_banben(assembly_table[0])
            if ret == "":
                return False
            ret1 = condition_assembly_banben_com("eq",ret,assembly_table[1])
            if ret1 == 0:
                return False
            pass
        elif ">" in assembly_str:
            print_deg("i am in condition_assembly----- >")
            assembly_table = assembly_str.split(">")
            ret = condition_assembly_banben(assembly_table[0])
            print_deg("ret = "+str(ret))
            if ret == "":
                return False
            ret1 = condition_assembly_banben_com("gt",ret,assembly_table[1])
            if ret1 == 0:
                return False
            pass
        elif "<" in assembly_str:
            print_deg("i am in condition_assembly----- <")
            assembly_table = assembly_str.split("<")
            ret = condition_assembly_banben(assembly_table[0])
            print_deg("ret = "+str(ret))
            if ret == "":
                return False
            ret1 = condition_assembly_banben_com("lt",ret,assembly_table[1])
            if ret1 == 0:
                return False
            pass
        else:
            print_deg("i am in condition_assembly----- condition error")
            return False

    return True
    pass
#日志路径、#日志关键信息
def condition_log_func(lst, str):
    ret_t = True
    for item in lst:  
        if item.lower() not in str:  
            ret_t = False
            break
    return ret_t  
def condition_log(log_path,key):
    des_log_path = "/tmp/kydoctor_log"
    #if os.path.exists(des_log_path):
    #    os.remove(des_log_path) 
    try:
        if not os.path.exists(des_log_path): #如果文件不存在 才创建，创建一次，在checkitem的过程中 就不再拷贝了 节省时间
            shutil.copy2(log_path, des_log_path)
    except Exception as e:
        print_deg("in condition_log,shutil.copy2 error")
        return False
    key_table = key.split(",")
    iii = 0
    with open(des_log_path,'r') as f:
        while True:
            try:   
                line = f.readline()
                if line=="":
                    break     

                line_temp = line.split()
                #关键字核对
                if len(key_table) > 0:
                    result = condition_log_func(key_table,line.lower().replace(" ",""))
                    if result == True:
                        print_deg("i am in condition_log resule == True")
                        if os.path.exists(des_log_path):
                            os.remove(des_log_path) 
                        return True
                    #for item in key_table:
                    #    if item.lower() in line.lower().replace(" ",""):
                    #        return True
                    #        break
                iii = 0
            except Exception as e:
                print_deg("i am in start_findlog_button_clicked")
                iii = iii + 1
                if iii > 10:
                    return False
                continue
    #if os.path.exists(des_log_path):
    #    os.remove(des_log_path) 
    return False

#def condition_log_key():
#    pass
#主动检测工具,检测结果
def condition_auto_check(shell_data,shell_result):
    try:
        report_result_name = ""
        if "#!/bin/env" in shell_data and "python3" in shell_data:
            report_result_name = "/tmp/kydoctor_python.py"
        else:
            report_result_name = "/tmp/kydoctor_shell.sh"
        
        result_fd = open(report_result_name,"w")
        result_fd.write(shell_data)
        result_fd.close()
        
        kysec_cmd = "kysec_set -rn exectl -v verified " + report_result_name
        os.system(kysec_cmd)

        cc = 0
        if "#!/bin/env" in shell_data and "python3" in shell_data:
            cc = os.system("python3 /tmp/kydoctor_python.py")
            print("--------------------------cc = ",cc)
        else:
            cc = os.system("bash /tmp/kydoctor_shell.sh")
        if cc != 0:
            return True
        else:
            return False
    except:
        return False
    pass
#检测结果
#def condition_check_result():
#    return True
#    pass
#文件权限
def condition_file_permission(file_perm_list):
        flag=0
        file_perm_items=file_perm_list.split('###')
        for item in file_perm_items:
                keys=item.split('|')

                try:
                        result = glob.glob(keys[0])
                        for file_path in result:
                                file_stat = os.stat(file_path)
                                print(f"File permissions for '{file_path}' is:",oct(file_stat.st_mode) )
                                if file_stat.st_mode&0o777 == int(keys[1],8):
                                        print(f"The file '{file_path}' Has permission: ", keys[1])
                                else:
                                        flag = 1 
                                        print(f"The file '{file_path}'No permission: ", keys[1])
                except :
                        print_deg("Error executing condition_file_permission")
    
        return flag

#文件配置项
def condition_config_item(file_perm_list):
    flag=0
    file_perm_items=file_perm_list.split('###')
    for item in file_perm_items:
        keys=item.split('|')
        try:
            result = glob.glob(keys[0])
            if keys[1] == "exist" and len(result) == 0:
                flag=1
                print(f"The file '{keys[0]}' not exist, but confitem needs exist")
                break
            for file_path in result:
                print(f"        for check file '{file_path}'")
                config = configparser.ConfigParser()
                config.read(file_path)
                confitem=keys[3].split('=')
                original_confvalue=confitem[1].split('+')
                confvalue = [word.lower() for word in original_confvalue]
                print(f"        sections:{config.sections()} ##  options:{config.options(keys[2])}")
                if keys[1]=="exist" and (keys[2] not in config.sections() or confitem[0].lower() not in config.options(keys[2]))  :
                        print(f"        The file '{file_path}' needs {confitem[0]} exist, but {confitem[0]} not exist")
                        flag=1
                        break
                if  keys[2] in config.sections() and confitem[0].lower() in config.options(keys[2]) and keys[1]=="notexist" :
                        print(f"        The file '{file_path}' needs {confitem[0]} notexist, but {confitem[0]} exist")
                        flag=1
                        break
                if keys[1]=="notexist" and (keys[2] not in config.sections() or confitem[0].lower() not in config.options(keys[2])) :
                        break
                settings_value = config.get(keys[2],confitem[0]).lower()
                if settings_value not in confvalue:
                        print(f"        The file '{file_path}' needs {confitem[0]} = {confitem[1]} , but {confitem[0]} != {confitem[1]}")
                        flag=1
                        break
        except :
                print_deg("except : Error executing condition_config")

    return flag
'''--------------------条件检索结束--------------------'''
#字符串增加一位
def add_char_to_string(string1):
    string_list = list(string1)
    string_list.insert(2,0)
    new_string = ''.join(str(x) for x in string_list)
    return new_string

def checkitemfromsql(error_cls):
    hexerror_cls_str = str(hex(int(error_cls)))
    if len(hexerror_cls_str) == 17:
        hexerror_cls_str = add_char_to_string(hexerror_cls_str)
    #提取hexerror_cls_str固定位数，用于检索数据库
    select_str = hexerror_cls_str[:8]
    
    db_dir = "/opt/kydoctor/common/db/" #数据库路径
    #db_dir = "./"
    db_dir_path = db_dir+"solution.db"
    if not os.path.exists(db_dir_path):
        print_deg("solution.db not exist!")
        return -1

    con = sqlite.connect(db_dir_path)
    try:
        my_dict = {}
        with con:
            cur = con.cursor()
            cur.execute("select * from errordata where error_cls=:error_cls",{"error_cls":select_str})
            rows = cur.fetchall()
            print_deg("i am in checkitem,len(rows) = "+str(len(rows)))
            
            test_all = len(rows)
            test_right = 0
            test_error = 0

            my_dict = {}
            for row in rows:
                temp_condition_all = True
                if row[3] == "" and row[4] == "" and row[5] == "" and row[6] == "" and row[7] == "" \
                and row[8] == "" and row[9] == "" and row[10] == "" and row[11] == "" and  row[12] == "":
                    temp_condition_all = False
                #产线
                if row[3] != "" and temp_condition_all == True:
                    if condition_production_line(row[3]) != True:
                        temp_condition_all = False
                #系统buildid
                if row[4] != "" and temp_condition_all == True:
                    if condition_buildid(row[4]) != True:
                        print_deg("i am in buildid,condition_buildid() != True")
                        temp_condition_all = False
                #系统环境
                if row[5] != "" and temp_condition_all == True:
                    if condition_sys_env() != True:
                        temp_condition_all = False
                #架构
                if row[6] != "" and temp_condition_all == True:
                    if condition_arch(row[6]) != True:
                        print_deg("i am in arch,row[6] != True")
                        temp_condition_all = False
                #硬件
                if row[7] != "" and temp_condition_all == True:
                    if condition_hardware(row[7]) != True:
                        temp_condition_all = False
                #问题组件
                if row[8] != "" and temp_condition_all == True:
                    if condition_assembly(row[8]) != True:
                        temp_condition_all = False
                #日志路径、#日志关键信息
                if row[9] != "" and row[10] != "" and temp_condition_all == True:
                    if condition_log(row[9],row[10]) != True:
                        temp_condition_all = False
                #自动检测工具--检测结果
                if row[11] != "" and temp_condition_all == True:
                    if condition_auto_check(row[11],row[12]) != True:
                        temp_condition_all = False
                #检测结果
                #if row[12] != "" and temp_condition_all == True:
                #    if condition_check_result() != True:
                #        temp_condition_all = False
                
                if temp_condition_all == True:
                    test_right = test_right + 1
                    error_dict = {}
                    error_dict["ErrorCode"] = row[2]
                    error_dict["Describe"] = row[13]
                    error_dict["Name"] = row[14]
                    if "Details" not in my_dict:
                        my_dict["Details"] = [error_dict]
                    else:
                        my_dict["Details"].append(error_dict)
            test_error = test_all - test_right
            overview_str = "检测了 " + str(test_all) + " 项，"+str(test_right) +" 项异常，"+ str(test_error)+" 项正常"
            my_dict["Overview"] = overview_str
            print_deg("i am in checkitem,my_dict = "+str(my_dict))

            json_table_str = json.dumps(my_dict)

            #开始往临时文件中写数据
            report_result_name = "/tmp/kydoctor"
            result_fd = open(report_result_name,"w")
            result_fd.write(json_table_str)
            result_fd.close()
    except Exception as e:
        print_deg("in checkitem,error :"+e)
        return -1
    return 0
def checkitemfromtxt(error_cls,net_hardware_ok):
    #hexerror_cls_str = str(hex(int(error_cls)))
    #if len(hexerror_cls_str) == 17:
    #    hexerror_cls_str = add_char_to_string(hexerror_cls_str)

    db_dir_path = "/tmp/kydoctor_c_sql"
    if not os.path.exists(db_dir_path):
        print_deg("checkitemfromtxt，/tmp/kydoctor_c_sql not exist!")
        return -1

    try:
        my_dict = {}
        test_all = 0
        test_right = 0
        test_error = 0
        file1 = open(db_dir_path)
        text = file1.read()
        text_line = text.split("****")
        

        #判断是否只有二级标题（检测项只有一个，且三级标题为空）
        only_class_b = 0
        if len(text_line) == 2 and text_line[0].split("+++")[19] == "":
            only_class_b = 1
        #print("-------------------------------text_line[0]= ",text_line[0])
        class_a_n = text_line[0].split("+++")[17]
        class_b_n = text_line[0].split("+++")[18]
        class_b_n_id  = text_line[0].split("+++")[20]
        #针对网络稳定性单独处理--设计要求当硬件链接异常时，网络稳定性也要报出异常
        if len(text_line) == 2 and text_line[0].split("+++")[19] == "" and int(net_hardware_ok) == 1 and class_b_n_id == "0x010004":
            overview_str = "检测了 1 项，1 项异常，0 项正常"
            my_dict["Overview"] = overview_str
            my_dict["class_a"] = class_a_n
            my_dict["class_b"] = class_b_n
            my_dict["class_b_id"] = class_b_n_id
            my_dict["ErrorCode"] = "0x0300060200000061"
            my_dict["Describe"] = ""
            my_dict["Details"] = []
            #my_dict["Type"] = hexerror_cls_str
            print_deg("i am in 333333333333333333333 checkitem,my_dict = "+str(my_dict))
            json_table_str = json.dumps(my_dict)
            #开始往临时文件中写数据
            report_result_name = "/tmp/kydoctor"
            result_fd = open(report_result_name,"w")
            result_fd.write(json_table_str)
            result_fd.close()
            file1.close()
            if os.path.exists(db_dir_path):
                os.remove(db_dir_path)
            return 0
        #针对工行项目，有线网络和无线网络，当检测到硬件设备异常时，不再进行接下来的检测
        if len(text_line) == 2 and text_line[0].split("+++")[19] == "" and class_b_n_id == "0x130002":
            net_ok = False
            cc = os.popen("LANGUAGE=en_US LANG=en_US nmcli device 2>&1")
            cc_strs = cc.readlines()
            for cc_str in cc_strs:
                if "ethernet" in cc_str:
                    cc_str_t = cc_str.split()
                    if len(cc_str_t) >=3 and "ethernet" == cc_str_t[1] and "connected" == cc_str_t[2]:
                        net_ok = True
                        break
            if net_ok == False:
                overview_str = "检测了 1 项，1 项异常，0 项正常"
                my_dict["Overview"] = overview_str
                my_dict["class_a"] = class_a_n
                my_dict["class_b"] = class_b_n
                my_dict["class_b_id"] = class_b_n_id
                my_dict["ErrorCode"] = "0x0300060200000064"
                my_dict["Describe"] = "2*|*有线网络未连接"
                my_dict["Details"] = []
                #my_dict["Type"] = hexerror_cls_str
                print_deg("i am in 333333333333333333333 checkitem,my_dict = "+str(my_dict))
                json_table_str = json.dumps(my_dict)
                #开始往临时文件中写数据
                report_result_name = "/tmp/kydoctor"
                result_fd = open(report_result_name,"w")
                result_fd.write(json_table_str)
                result_fd.close()
                file1.close()
                if os.path.exists(db_dir_path):
                    os.remove(db_dir_path)
                return 0
        if len(text_line) == 2 and text_line[0].split("+++")[19] == "" and class_b_n_id == "0x150002":
            net_ok = False
            cc = os.popen("LANGUAGE=en_US LANG=en_US nmcli device 2>&1")
            cc_strs = cc.readlines()
            for cc_str in cc_strs:
                if "wifi" in cc_str and "connected" in cc_str and "disconnected" not in cc_str:
                    net_ok = True
                    break
            if net_ok == False:
                overview_str = "检测了 1 项，1 项异常，0 项正常"
                my_dict["Overview"] = overview_str
                my_dict["class_a"] = class_a_n
                my_dict["class_b"] = class_b_n
                my_dict["class_b_id"] = class_b_n_id
                my_dict["ErrorCode"] = "0x0300060200000068"
                my_dict["Describe"] = "2*|*无线网卡未连接"
                my_dict["Details"] = []
                #my_dict["Type"] = hexerror_cls_str
                print_deg("i am in 333333333333333333333 checkitem,my_dict = "+str(my_dict))
                json_table_str = json.dumps(my_dict)
                #开始往临时文件中写数据
                report_result_name = "/tmp/kydoctor"
                result_fd = open(report_result_name,"w")
                result_fd.write(json_table_str)
                result_fd.close()
                file1.close()
                if os.path.exists(db_dir_path):
                    os.remove(db_dir_path)
                return 0
        for texts in text_line:
        #while True:
            #text = file1.readline()
            if len(texts) == 0:
                break
            test_all = test_all + 1
            row = texts.split("+++")
            temp_condition_all = True
            if row[3] == "" and row[4] == "" and row[5] == "" and row[6] == "" and row[7] == "" \
            and row[8] == "" and row[9] == "" and row[10] == "" and row[11] == "" and  row[12] == "" and row[13] == "" and row[14]:
                temp_condition_all = False
                continue
            #产线 wayland/hwe/xc/openkylin            
            #if temp_condition_all == True:
            if row[3] != "" and temp_condition_all == True:   #两个if，上面的if是老版本处理openkylin时使用的，配合condition_production_line内部代码使用
                if condition_production_line(row[3]) != True:
                    temp_condition_all = False
                    continue
            #系统buildid
            if row[4] != "" and temp_condition_all == True:
                if condition_buildid(row[4]) != True:
                    temp_condition_all = False
                    continue
            #系统环境 /华为云/深信服云/天翼云/物理环境
            if row[5] != "" and temp_condition_all == True:
                if condition_sys_env(row[5]) != True:
                    temp_condition_all = False
                    continue
            #架构
            if row[6] != "" and temp_condition_all == True:
                if condition_arch(row[6]) != True:
                    temp_condition_all = False
                    continue
            #硬件
            if row[7] != "" and temp_condition_all == True:
                if condition_hardware(row[7]) != True:                    
                    temp_condition_all = False
                    continue
            #问题组件
            if row[8] != "" and temp_condition_all == True:
                if condition_assembly(row[8]) != True:                    
                    temp_condition_all = False
                    continue
            #日志路径、#日志关键信息
            if row[9] != "" and row[10] != "" and temp_condition_all == True:
                if condition_log(row[9],row[10]) != True:
                    print_deg("i am in log,row[9] != True")
                    temp_condition_all = False
                    continue
            #自动检测工具--检测结果
            if row[11] != "" and temp_condition_all == True:
                if condition_auto_check(row[11],row[12]) != True:
                    temp_condition_all = False
                    continue
            #检测结果
            #if row[12] != "" and temp_condition_all == True:
            #    if condition_check_result() != True:
            #        temp_condition_all = False
            #文件权限检测
            if row[13] != "" and temp_condition_all == True:
               if condition_file_permission(row[13]) != True:
                   temp_condition_all = False
                   continue
            #文件配置项
            if row[14] != "" and temp_condition_all == True:
               if condition_config_item(row[14]) != True:
                   temp_condition_all = False
                   continue

            #只有二级标题
            if temp_condition_all == True and only_class_b == 1:
                test_right = test_right + 1
                my_dict["ErrorCode"] = row[2]
                my_dict["Describe"] = row[15]
                my_dict["Details"] = []
                break
            if temp_condition_all == True:
                test_right = test_right + 1
                error_dict = {}
                error_dict["ErrorCode"] = row[2]
                error_dict["Describe"] = row[15]
                #error_dict["Name"] = row[16]
                error_dict["class_c"] = row[19]
                if "Details" not in my_dict:
                    my_dict["Details"] = [error_dict]
                else:
                    my_dict["Details"].append(error_dict)
        test_error = test_all - test_right
        if test_all == test_error:
            my_dict["Details"] = []
        overview_str = "检测了 " + str(test_all) + " 项，"+str(test_right) +" 项异常，"+ str(test_error)+" 项正常"
        my_dict["Overview"] = overview_str
        my_dict["class_a"] = class_a_n
        my_dict["class_b"] = class_b_n
        my_dict["class_b_id"] = class_b_n_id
        if only_class_b == 0:
            my_dict["ErrorCode"] = ""
            my_dict["Describe"] = ""
        #my_dict["Type"] = hexerror_cls_str
        print_deg("i am in checkitem,my_dict = "+str(my_dict))

        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
        file1.close()
    except Exception as e:
        if os.path.exists(db_dir_path):
            os.remove(db_dir_path)
        print_deg("in checkitem,error :"+e)
        return -1
    if os.path.exists(db_dir_path):
        os.remove(db_dir_path)
    return 0
if __name__ == "__main__":
    #ret = checkitemfromsql(sys.argv[1])
    ret = checkitemfromtxt(sys.argv[1],sys.argv[2])
    if ret == -1:
        exit(-1)
    else:
        exit(0)

