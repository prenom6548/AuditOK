"""Copyright (c) KylinSoft  Co., Ltd. [2024].All rights reserved.
/*[kydoctor] licensed under the [Your LICENSE].
***************Your LICENSE Messages***********************
Author: [WangShuai]
Create: [2024]
"""
# import os

# def checkos_sqlcipher():
#     cc = os.popen("dpkg -l | grep libsqlcipher")
#     cc_str = cc.read()
#     if "libsqlcipher0" in cc_str:
#         return 0
#     else:
#         return 1

# if __name__ == "__main__":
#     ret = checkos_sqlcipher()
#     exit(ret)