"""Copyright (c) KylinSoft  Co., Ltd. [2024].All rights reserved.
/*[kydoctor] licensed under the [Your LICENSE].
***************Your LICENSE Messages***********************
Author: [WangShuai]
Create: [2024]
"""

import json
import os
import sys
import sqlite3 as sqlite
import glob
import configparser
#import subprocess
#from kysdk import Sysinfo 因为在2107和2203上面kysdk包无法使用，暂时将其功能屏蔽
import shutil
from common_variables import PRINT_DEBUG
import subprocess  
from subprocess import TimeoutExpired 

def print_deg(print_str):
    if PRINT_DEBUG == 1:
        print(print_str)

#字符串增加一位
def add_char_to_string(string1):
    string_list = list(string1)
    string_list.insert(2,0)
    new_string = ''.join(str(x) for x in string_list)
    return new_string

def check_0100(error_cls,locale_temp): 
    #print_deg("----------------locale_temp= ",locale_temp)
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        #update_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 kylin-source-update 2>&1"
        #proc = subprocess.Popen(update_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)  
        # try:  
        #     #stdout, stderr = proc.communicate(timeout=10)  
        #     proc.communicate(timeout=3)  
        # except:  
        #     proc.kill()  
        #     stdout, stderr = proc.communicate()  # 尝试获取可能的输出，但此时进程已被终止  
        #     print(f"命令 {cmd} 执行超时，已终止")  
        #     return -1
        # finally:  
        #     # 无论是否发生异常，都尝试关闭进程  
        #     proc.wait(timeout=1)  # 等待进程结束，以防它还在运行  
        try:  
            result = subprocess.run(['LANG=en_US.utf8 LANGUAGE=en_US.utf8 /usr/bin/kylin-source-update 2>&1'],   
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,   
                    timeout=15,  # 增加超时时间到30秒  
                    universal_newlines=True, shell=True)  
            print("----",result.stdout)  
        except subprocess.TimeoutExpired as e:  
            print(f"Command timed out after {e.timeout} seconds")
            return -1
        print("-------------------------------------------")
        print("retcode = ",result.returncode)
        print("stdout = ",result.stdout)
        #print("stderr = ",stderr.decode())
        print("*******************************************")
        my_dict = {}
        error_dict = {}
        is_have_error = 0
        
        #第一步，先检测程序返回值
        #cc = os.system(update_cmd)
        if int(result.returncode) != 0:        
            error_dict["ErrorCode"] = hexerror_cls_str
            if int(locale_temp) == 1: #英文
                error_dict["Describe"] = "Unable to access source management server"
            elif int(locale_temp) == 2: #繁体中文
                error_dict["Describe"] = "無法訪問源管理伺服器"
            elif int(locale_temp) == 3: #蒙古文
                error_dict["Describe"] = "ᠢᠷᠡᠯᠲᠡ ᠶᠢᠨ ᠬᠠᠮᠢᠶᠠᠷᠤᠯᠲᠠ ᠶᠢᠨ ᠦᠢᠯᠡᠴᠢᠯᠡᠭᠦᠷ ᠢ ᠰᠤᠷᠪᠤᠯᠵᠢᠯᠠᠬᠤ ᠶᠢᠨ ᠠᠷᠭ᠎ᠠ ᠦᠭᠡᠢ ᠃"
            elif int(locale_temp) == 4: #藏文
                error_dict["Describe"] = "འདྲི་རྩད་ཀྱི་འབྱུང་ཁུངས་དོ་དམ་ཞབས་ཞུའི་ཡོ་བྱད་ལ་བ"
            else:
                error_dict["Describe"] = "无法访问源管理服务器"
            error_dict["Context"] = ""
            error_dict["Name"] = "Upgrade"
            error_dict["CanRepair"] = "0"
            error_dict["NetworkState"] = "0"  #未进行网络检测 
            is_have_error = 1
        #第二步 
        if is_have_error == 0:
            #update_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 kylin-source-update 2>&1"
            #cc1 = os.popen(update_cmd)
            #cc_strs = cc1.read()
            if "true" not in result.stdout:#stdout.decode():
                error_dict["ErrorCode"] = hexerror_cls_str      
                if int(locale_temp) == 1: #英文
                    error_dict["Describe"] = "Unable to access source management server"
                elif int(locale_temp) == 2: #繁体中文
                    error_dict["Describe"] = "無法訪問源管理伺服器"
                elif int(locale_temp) == 3: #蒙古文
                    error_dict["Describe"] = "ᠢᠷᠡᠯᠲᠡ ᠶᠢᠨ ᠬᠠᠮᠢᠶᠠᠷᠤᠯᠲᠠ ᠶᠢᠨ ᠦᠢᠯᠡᠴᠢᠯᠡᠭᠦᠷ ᠢ ᠰᠤᠷᠪᠤᠯᠵᠢᠯᠠᠬᠤ ᠶᠢᠨ ᠠᠷᠭ᠎ᠠ ᠦᠭᠡᠢ ᠃"
                elif int(locale_temp) == 4: #藏文
                    error_dict["Describe"] = "འདྲི་རྩད་ཀྱི་འབྱུང་ཁུངས་དོ་དམ་ཞབས་ཞུའི་ཡོ་བྱད་ལ་བ"
                else:
                    error_dict["Describe"] = "无法访问源管理服务器"
                error_dict["Context"] = ""
                error_dict["Name"] = "Upgrade"
                error_dict["CanRepair"] = "0"
                error_dict["NetworkState"] = "0"  #未进行网络检测 
                is_have_error = 1
        #第三步
        if is_have_error == 0:
            #update_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 kylin-source-update 2>&1"
            #cc1 = os.popen(update_cmd)
            #cc_strs = cc1.read()
            if "100" not in result.stdout:#stdout.decode():
                error_dict["ErrorCode"] = hexerror_cls_str      
                if int(locale_temp) == 1: #英文
                    error_dict["Describe"] = "Unable to access source management server"
                elif int(locale_temp) == 2: #繁体中文
                    error_dict["Describe"] = "無法訪問源管理伺服器"
                elif int(locale_temp) == 3: #蒙古文
                    error_dict["Describe"] = "ᠢᠷᠡᠯᠲᠡ ᠶᠢᠨ ᠬᠠᠮᠢᠶᠠᠷᠤᠯᠲᠠ ᠶᠢᠨ ᠦᠢᠯᠡᠴᠢᠯᠡᠭᠦᠷ ᠢ ᠰᠤᠷᠪᠤᠯᠵᠢᠯᠠᠬᠤ ᠶᠢᠨ ᠠᠷᠭ᠎ᠠ ᠦᠭᠡᠢ ᠃"
                elif int(locale_temp) == 4: #藏文
                    error_dict["Describe"] = "འདྲི་རྩད་ཀྱི་འབྱུང་ཁུངས་དོ་དམ་ཞབས་ཞུའི་ཡོ་བྱད་ལ་བ"
                else:
                    error_dict["Describe"] = "无法访问源管理服务器"
                error_dict["Context"] = ""
                error_dict["Name"] = "Upgrade"
                error_dict["CanRepair"] = "0"
                error_dict["NetworkState"] = "0"  #未进行网络检测 
                is_have_error = 1
        if is_have_error == 0:
            overview_str = "检测了1项,0项错误,1项正确"
            
        elif is_have_error == 1:
            overview_str = "检测了1项,1项错误,0项正确"
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
        return 0
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1

    # try:
    #     hexerror_cls_str = str(hex(int(error_cls)))  
        
    #     if len(hexerror_cls_str) == 17:
    #         hexerror_cls_str = add_char_to_string(hexerror_cls_str)
    #     print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
    #     update_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 kylin-source-update 2>&1"
    #     my_dict = {}
    #     error_dict = {}
    #     is_have_error = 0
    #     #第一步，先检测程序返回值
    #     cc = os.system(update_cmd)
    #     if cc != 0:        
    #         error_dict["ErrorCode"] = hexerror_cls_str
    #         error_dict["Describe"] = "无法访问源管理服务器"
    #         error_dict["Context"] = ""
    #         error_dict["Name"] = "Upgrade"
    #         error_dict["CanRepair"] = "0"
    #         error_dict["NetworkState"] = "0"  #未进行网络检测 
    #         is_have_error = 1
    #     #第二步 
    #     if is_have_error == 0:
    #         update_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 kylin-source-update 2>&1"
    #         cc1 = os.popen(update_cmd)
    #         cc_strs = cc1.read()
    #         if "true" not in cc_strs:
    #             error_dict["ErrorCode"] = hexerror_cls_str      
    #             error_dict["Describe"] = "无法访问源管理服务器"
    #             error_dict["Context"] = ""
    #             error_dict["Name"] = "Upgrade"
    #             error_dict["CanRepair"] = "0"
    #             error_dict["NetworkState"] = "0"  #未进行网络检测 
    #             is_have_error = 1
    #     #第三步
    #     if is_have_error == 0:
    #         update_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 kylin-source-update 2>&1"
    #         cc1 = os.popen(update_cmd)
    #         cc_strs = cc1.read()
    #         if "100" not in cc_strs:
    #             error_dict["ErrorCode"] = hexerror_cls_str      
    #             error_dict["Describe"] = "无法访问源管理服务器"
    #             error_dict["Context"] = ""
    #             error_dict["Name"] = "Upgrade"
    #             error_dict["CanRepair"] = "0"
    #             error_dict["NetworkState"] = "0"  #未进行网络检测 
    #             is_have_error = 1
    #     if is_have_error == 0:
    #         overview_str = "检测了1项,0项错误,1项正确"
            
    #     elif is_have_error == 1:
    #         overview_str = "检测了1项,1项错误,0项正确"
    #     my_dict["Overview"] = overview_str
    #     my_dict["Type"] = hexerror_cls_str   
    #     my_dict["Details"] = [error_dict]
    #     print_deg("in checkitem,my_dict = "+str(my_dict))
    #     json_table_str = json.dumps(my_dict)

    #     #开始往临时文件中写数据
    #     report_result_name = "/tmp/kydoctor"
    #     result_fd = open(report_result_name,"w")
    #     result_fd.write(json_table_str)
    #     result_fd.close()
    #     return 0
    # except Exception as e:
    #     print("i am in checkitem_non_sysupdate,e = ",e)
    #     return -1
def check_0101(error_cls,locale_temp):#无法修复，管家处理
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str  
        if int(locale_temp) == 1: #英文 
            error_dict["Describe"] = "Server access timeout"   
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "訪問伺服器超時"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠦᠢᠯᠡᠴᠢᠯᠡᠭᠦᠷ ᠴᠠᠭ ᠠᠴᠠ ᠬᠡᠲᠦᠷᠡᠵᠡᠢ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "ཞབས་ཞུའི་ཡོ་བྱད་ལ་བཅར་འདྲི་བྱེད་པའི་དུས་"
        else:
            error_dict["Describe"] = "访问服务器超时"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "1"  #无法修复  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
    
def check_0102(error_cls,locale_temp):#管家调用通用网络诊断来修复
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str
        if int(locale_temp) == 1: #英文 
            error_dict["Describe"] = "Network abnormality"      
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "網路異常"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠲᠣᠣᠷ ᠰᠦᠯᠵᠢᠶ᠎ᠡ ᠬᠡᠪ ᠦᠨ ᠪᠤᠰᠤ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "དྲ་རྒྱ་རྒྱུན་ལྡན་མིན་པ།"
        else:
            error_dict["Describe"] = "网络异常"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "2"  #通用网络检测修复  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
    
def check_0107(error_cls,locale_temp):  #改为无法修复，直接上报
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str 
        if int(locale_temp) == 1: #英文  
            error_dict["Describe"] = "There is an exception in updating the environment, and the software package of kylin-update-desktop-config is missing from the warehouse source"    
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "更新環境存在異常，倉庫源中缺少kylin-update-desktop-config軟體包"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠰᠢᠨᠡᠳᠬᠡᠬᠦ ᠣᠷᠴᠢᠨ ᠲᠣᠭᠣᠷᠢᠨ ᠳᠤ ᠬᠡᠪ ᠦᠨ ᠪᠤᠰᠤ ᠪᠠᠶᠢᠵᠤ ᠂ ᠬᠥᠮᠥᠷᠭᠡ ᠶᠢᠨ ᠢᠷᠡᠯᠲᠡ ᠳᠦ ᠺᠧᠯᠧᠨᠲ᠋ ᠳᠤᠲᠠᠭᠳᠠᠵᠤ ᠪᠠᠶᠢᠨ᠎ᠠ ᠃ ᠧᠳ᠋ᠰᠺᠲ᠋ᠣᠫ config ᠵᠥᠭᠡᠯᠡᠨ ᠲᠣᠨᠣᠭ ᠤᠨ ᠪᠣᠭᠴᠣ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "ཁོར་ཡུག་གསར་བཅོས་བྱེད་པར་རྒྱུན་ལྡན་མིན་པའི་གནས་ཡོད་པ་དང་།མཛོད་ཁང་གི་འབྱུང་ཁུངས་ཁྲོད་དུ་ཁྲོད་མཉེན་ཆས་མཉེན་ཆས་ཐུམ་པོ་མེད་པ་རེད།"
        else:
            error_dict["Describe"] = "更新环境存在异常,仓库源中缺少kylin-update-desktop-config软件包"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "1"  #无法修复  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
    # try:
    #     hexerror_cls_str = str(hex(int(error_cls)))  
        
    #     if len(hexerror_cls_str) == 17:
    #         hexerror_cls_str = add_char_to_string(hexerror_cls_str)
    #     print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
    #     update_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 apt policy kylin-update-desktop-config 2>&1"
    #     cc1 = os.popen(update_cmd)
    #     cc_strs = cc1.readlines()
    #     my_dict = {}
    #     error_dict = {}
    #     is_have_error = 0
    #     #第一步 
    #     if is_have_error == 0:
    #         for cc_str in cc_strs:    
    #             if "N:" in cc_str:
    #                 error_dict["ErrorCode"] = hexerror_cls_str      
    #                 error_dict["Describe"] = "更新环境存在异常,仓库源中缺少kylin-update-desktop-config软件包"
    #                 error_dict["Context"] = ""
    #                 error_dict["Name"] = "Upgrade"
    #                 error_dict["CanRepair"] = "1"  #无法修复
    #                 error_dict["NetworkState"] = "0"  #未进行网络检测 
    #                 is_have_error = 1
    #     #第二步
    #     if is_have_error == 0:
    #         installed_deb = ""
    #         candidate_deb = ""
    #         for cc_str in cc_strs:
    #             if "installed:" in cc_str.lower():
    #                 installed_deb = cc_str.split(":")[1].strip(" ")
    #             if "candidate:" in cc_str.lower():
    #                 candidate_deb = cc_str.split(":")[1].strip(" ")
    #         if installed_deb != "" or candidate_deb != "":
    #             if installed_deb != candidate_deb:
    #                 print_deg("installed_deb != candidate_deb")
    #                 error_dict["ErrorCode"] = hexerror_cls_str      
    #                 error_dict["Describe"] = "更新环境存在异常,仓库源中缺少kylin-update-desktop-config软件包"
    #                 error_dict["Context"] = ""
    #                 error_dict["Name"] = "Upgrade"
    #                 error_dict["CanRepair"] = "0"
    #                 error_dict["NetworkState"] = "0"  #未进行网络检测 
    #                 is_have_error = 1
    #             elif installed_deb == candidate_deb:
    #                 print_deg("installed_deb == candidate_deb")
    #                 error_dict["ErrorCode"] = hexerror_cls_str      
    #                 error_dict["Describe"] = "更新环境存在异常,仓库源中缺少kylin-update-desktop-config软件包"
    #                 error_dict["Context"] = ""
    #                 error_dict["Name"] = "Upgrade"
    #                 error_dict["CanRepair"] = "1"  #无法修复
    #                 error_dict["NetworkState"] = "0"  #未进行网络检测 
    #                 is_have_error = 1

    #     if is_have_error == 0:
    #         overview_str = "检测了1项,0项错误,1项正确"
            
    #     elif is_have_error == 1:
    #         overview_str = "检测了1项,1项错误,0项正确"
    #     my_dict["Overview"] = overview_str
    #     my_dict["Type"] = hexerror_cls_str   
    #     my_dict["Details"] = [error_dict]
    #     print_deg("in checkitem,my_dict = "+str(my_dict))
    #     json_table_str = json.dumps(my_dict)

    #     #开始往临时文件中写数据
    #     report_result_name = "/tmp/kydoctor"
    #     result_fd = open(report_result_name,"w")
    #     result_fd.write(json_table_str)
    #     result_fd.close()
    #     return 0
    # except Exception as e:
    #     print("i am in checkitem_non_sysupdate,e = ",e)
    #     return -1
    # pass
   
def check_0111(error_cls,locale_temp): #改为无法修复，直接上报
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "Abnormal update environment"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "更新環境存在異常"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠣᠷᠴᠢᠨ ᠲᠣᠭᠣᠷᠢᠨ ᠢ ᠰᠢᠨᠡᠳᠬᠡᠬᠦ ᠳᠦ ᠬᠡᠪ ᠦᠨ ᠪᠤᠰᠤ ᠪᠠᠶᠢᠳᠠᠯ ᠣᠷᠣᠰᠢᠵᠤ ᠪᠠᠶᠢᠨ᠎ᠠ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "ཁོར་ཡུག་གསར་སྒྱུར་བྱེད་པར་རྒྱུན་ལྡན་མིན་པ་ཡོད།"
        else:
            error_dict["Describe"] = "更新环境存在异常"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "1"  #无法修复  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
    # try:
    #     hexerror_cls_str = str(hex(int(error_cls)))  
        
    #     if len(hexerror_cls_str) == 17:
    #         hexerror_cls_str = add_char_to_string(hexerror_cls_str)
    #     print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
    #     update_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 dpkg -l kylin-update-desktop-config | grep ii 2>&1"
    #     cc1 = os.popen(update_cmd)
    #     cc_strs = cc1.readlines()
    #     my_dict = {}
    #     error_dict = {}
    #     is_have_error = 0
    #     #第一步 
    #     if is_have_error == 0:
    #         for cc_str in cc_strs:    
    #             if cc_str.startswith("ii") and "kylin-update-desktop-config" in cc_str:
    #                 is_have_error = 1
    #                 break

    #     if is_have_error == 1:
    #         overview_str = "检测了1项,0项错误,1项正确"            
    #     elif is_have_error == 0:
    #         overview_str = "检测了1项,1项错误,0项正确"
    #         error_dict["ErrorCode"] = hexerror_cls_str      
    #         error_dict["Describe"] = "更新环境存在异常"
    #         error_dict["Context"] = ""
    #         error_dict["Name"] = "Upgrade"
    #         error_dict["CanRepair"] = "0"  
    #         error_dict["NetworkState"] = "0"  #未进行网络检测 
    #     my_dict["Overview"] = overview_str
    #     my_dict["Type"] = hexerror_cls_str   
    #     my_dict["Details"] = [error_dict]
    #     print_deg("in checkitem,my_dict = "+str(my_dict))
    #     json_table_str = json.dumps(my_dict)

    #     #开始往临时文件中写数据
    #     report_result_name = "/tmp/kydoctor"
    #     result_fd = open(report_result_name,"w")
    #     result_fd.write(json_table_str)
    #     result_fd.close()
    # except Exception as e:
    #     print("i am in checkitem_non_sysupdate,e = ",e)
    #     return -1
    # return 0
    # pass
    
def check_0112(error_cls,locale_temp):#无法修复，管家处理
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str      
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "Abnormal update environment"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "更新環境存在異常"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠣᠷᠴᠢᠨ ᠲᠣᠭᠣᠷᠢᠨ ᠢ ᠰᠢᠨᠡᠳᠬᠡᠬᠦ ᠳᠦ ᠬᠡᠪ ᠦᠨ ᠪᠤᠰᠤ ᠪᠠᠶᠢᠳᠠᠯ ᠣᠷᠣᠰᠢᠵᠤ ᠪᠠᠶᠢᠨ᠎ᠠ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "ཁོར་ཡུག་གསར་སྒྱུར་བྱེད་པར་རྒྱུན་ལྡན་མིན་པ་ཡོད།"
        else:
            error_dict["Describe"] = "更新环境存在异常"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "1"  #无法修复  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
    
def check_0113(error_cls,locale_temp):
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "Damaged update strategy"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "更新策略損壞"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠠᠷᠭ᠎ᠠ ᠪᠣᠳᠣᠯᠭ᠎ᠠ ᠶᠢᠨ ᠡᠪᠳᠡᠷᠡᠯ ᠢ ᠰᠢᠨᠡᠳᠬᠡᠨ᠎ᠡ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "ཐབས་ཇུས་གསར་བཅོས་བྱས་ནས་གཏོར་སྐྱོན་བཏང་བ།"
        else:
            error_dict["Describe"] = "更新策略损坏"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "0"  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
   
def check_0114(error_cls,locale_temp):
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str      
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "Abnormal update environment"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "更新環境存在異常"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠣᠷᠴᠢᠨ ᠲᠣᠭᠣᠷᠢᠨ ᠢ ᠰᠢᠨᠡᠳᠬᠡᠬᠦ ᠳᠦ ᠬᠡᠪ ᠦᠨ ᠪᠤᠰᠤ ᠪᠠᠶᠢᠳᠠᠯ ᠣᠷᠣᠰᠢᠵᠤ ᠪᠠᠶᠢᠨ᠎ᠠ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "ཁོར་ཡུག་གསར་སྒྱུར་བྱེད་པར་རྒྱུན་ལྡན་མིན་པ་ཡོད།"
        else:
            error_dict["Describe"] = "更新环境存在异常"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "0"  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
   
def check_0115(error_cls,locale_temp):
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str 
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "Unable to download software repository information"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "無法下載軟體倉庫資訊"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠵᠥᠭᠡᠯᠡᠨ ᠲᠣᠨᠣᠭ ᠤᠨ ᠬᠥᠮᠥᠷᠭᠡ ᠶᠢᠨ ᠮᠡᠳᠡᠭᠡ ᠵᠠᠩᠭᠢ ᠶᠢ ᠪᠠᠭᠤᠯᠭᠠᠬᠤ ᠶᠢᠨ ᠠᠷᠭ᠎ᠠ ᠦᠭᠡᠶ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "མཉེན་ཆས་མཛོད་ཁང་གི་ཆ་འཕྲིན་ཕབ་ལེན་བྱེད་ཐབས་མེད།"
        else:
            error_dict["Describe"] = "无法下载软件仓库信息"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "0"  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
    
def check_0116(error_cls,locale_temp):
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str      
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "Abnormal update environment"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "更新環境存在異常"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠣᠷᠴᠢᠨ ᠲᠣᠭᠣᠷᠢᠨ ᠢ ᠰᠢᠨᠡᠳᠬᠡᠬᠦ ᠳᠦ ᠬᠡᠪ ᠦᠨ ᠪᠤᠰᠤ ᠪᠠᠶᠢᠳᠠᠯ ᠣᠷᠣᠰᠢᠵᠤ ᠪᠠᠶᠢᠨ᠎ᠠ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "ཁོར་ཡུག་གསར་སྒྱུར་བྱེད་པར་རྒྱུན་ལྡན་མིན་པ་ཡོད།"
        else:
            error_dict["Describe"] = "更新环境存在异常"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "0"  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
    
def check_0117(error_cls,locale_temp):   #无法修复，管家处理
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str 
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "The updated patch package does not match the system version"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "更新補丁包與系統版本不匹配"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠨᠦᠬᠦᠪᠦᠷᠢᠯᠡᠬᠦ ᠨᠢ ᠳ᠋ᠢᠩ ᠪᠣᠣᠪᠣ ᠬᠢᠭᠡᠳ ᠰᠢᠰᠲ᠋ᠧᠮ ᠦᠨ ᠬᠡᠪᠯᠡᠯ ᠢ ᠲᠣᠬᠢᠷᠠᠬᠤ ᠦᠭᠡᠶ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "གསར་དུ་བསྣན་པའི་ཁུག་མ་དང་མ་ལག་གི་པར་གཞི་གཉིས་ཆ་མི་མཐུན་པ་རེད།"
        else:     
            error_dict["Describe"] = "更新补丁包与系统版本不匹配"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "1"  #无法修复  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
    
def check_0119(error_cls,locale_temp):
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "Abnormal update environment, critical directory detection failed"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "更新環境存在異常，關鍵目錄檢測未通過"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠣᠷᠴᠢᠨ ᠲᠣᠭᠣᠷᠢᠨ ᠢ ᠰᠢᠨᠡᠳᠬᠡᠬᠦ ᠳᠦ ᠬᠡᠪ ᠦᠨ ᠪᠤᠰᠤ ᠪᠠᠶᠢᠳᠠᠯ ᠣᠷᠣᠰᠢᠵᠤ ᠂ ᠵᠠᠩᠭᠢᠯᠠᠭ᠎ᠠ ᠶᠢᠨ ᠭᠠᠷᠴᠠᠭ ᠤᠨ ᠪᠠᠶᠢᠴᠠᠭᠠᠨ ᠰᠢᠯᠭᠠᠯᠲᠠ ᠳᠤ ᠪᠠᠲᠤᠯᠠᠭᠳᠠᠭᠰᠠᠨ ᠦᠭᠡᠶ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "ཁོར་ཡུག་གསར་སྒྱུར་བྱེད་པར་རྒྱུན་ལྡན་མིན་པའི་གནད་འགག་གི་དཀར་ཆག་ལ་ཞིབ་དཔྱད་ཚད་ལན་བྱས་མེད།"
        else:      
            error_dict["Describe"] = "更新环境存在异常，关键目录检测未通过"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "0"  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
def check_0121(error_cls,locale_temp):   #无法修复，管家处理
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str 
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "Check update timeout, please try again later"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "檢查更新超時，請稍後再試"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠪᠠᠶᠢᠴᠠᠭᠠᠵᠤ ᠰᠢᠨᠡᠳᠭᠡᠬᠦ ᠦᠶ᠎ᠡ ᠡᠴᠡ ᠬᠡᠲᠦᠷᠡᠵᠡᠢ ᠂ ᠵᠢᠭᠠᠬᠠᠨ ᠳᠠᠷᠠᠭ᠎ᠠ ᠨᠢ ᠲᠤᠷᠰᠢᠵᠤ ᠦᠵᠡᠭᠡᠷᠡᠢ ᠃ "
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "ཞིབ་བཤེར་གསར་སྒྱུར་བྱེད་སྐབས་རྗེས་སུ་ཡང་བསྐྱར་ཚོད་ལྟ་ཞིག་གནང་རོགས།"
        else:     
            error_dict["Describe"] = "检查更新超时，请稍后再试"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "1"  #无法修复  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass    
def check_0122(error_cls,locale_temp):
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str  
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "The configuration file does not have write permission"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "配置檔沒有寫入許可權"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠲᠣᠬᠢᠷᠠᠭᠤᠯᠤᠭᠰᠠᠨ ᠪᠢᠴᠢᠭ᠌ ᠮᠠᠲ᠋ᠧᠷᠢᠶᠠᠯ ᠢ ᠪᠢᠴᠢᠵᠦ ᠣᠷᠣᠭᠤᠯᠬᠤ ᠡᠷᠬᠡ ᠮᠡᠳᠡᠯ ᠦᠭᠡᠢ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "བཀོད་སྒྲིག་ཡིག་ཆའི་ནང་དུ་བཀོད་པའི་དབང་ཚད་མེད།"
        else:     
            error_dict["Describe"] = "配置文件没有写入权限"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "0"  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
  

def check_0200(error_cls,locale_temp):
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str  
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "Abnormal update environment, unable to install or remove software packages"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "更新環境存在異常，無法安裝或移除套件"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠣᠷᠴᠢᠨ ᠲᠣᠭᠣᠷᠢᠨ ᠢ ᠰᠢᠨᠡᠳᠬᠡᠬᠦ ᠳᠦ ᠬᠡᠪ ᠦᠨ ᠪᠤᠰᠤ ᠪᠠᠶᠢᠵᠤ ᠂ ᠵᠥᠭᠡᠯᠡᠨ ᠲᠣᠨᠣᠭ ᠤᠨ ᠪᠣᠭᠴᠣ ᠤᠭᠰᠠᠷᠠᠬᠤ ᠪᠤᠶᠤ ᠰᠢᠯᠵᠢᠭᠦᠯᠬᠦ ᠶᠢᠨ ᠠᠷᠭ᠎ᠠ ᠦᠭᠡᠶ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "ཁོར་ཡུག་གསར་སྒྱུར་བྱེད་པར་རྒྱུན་ལྡན་མིན་པ་དང་།མཉེན་ཆས་ཀྱི་ཁུག་མ་སྒྲིག་སྦྱོར་བྱེད་ཐབས་མེད།"
        else:     
            error_dict["Describe"] = "更新环境存在异常，无法安装或移除软件包"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "0"  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
    
def check_0201(error_cls,locale_temp):   #无法修复，管家处理
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str      
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "Abnormal update environment"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "更新環境存在異常"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠣᠷᠴᠢᠨ ᠲᠣᠭᠣᠷᠢᠨ ᠢ ᠰᠢᠨᠡᠳᠬᠡᠬᠦ ᠳᠦ ᠬᠡᠪ ᠦᠨ ᠪᠤᠰᠤ ᠪᠠᠶᠢᠳᠠᠯ ᠣᠷᠣᠰᠢᠵᠤ ᠪᠠᠶᠢᠨ᠎ᠠ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "ཁོར་ཡུག་གསར་སྒྱུར་བྱེད་པར་རྒྱུན་ལྡན་མིན་པ་ཡོད།"
        else:
            error_dict["Describe"] = "更新环境存在异常"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "1"  #无法修复  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
    
def check_0202(error_cls,locale_temp):#无法修复，管家处理
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str 
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "There are abnormalities in updating patches and system environment"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "更新補丁與系統環境存在異常"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠰᠢᠨᠡᠳᠬᠡᠨ ᠨᠥᠬᠥᠬᠦ ᠪᠠ ᠰᠢᠰᠲ᠋ᠧᠮ ᠦᠨ ᠣᠷᠴᠢᠨ ᠲᠣᠭᠣᠷᠢᠨ ᠳᠤ ᠬᠡᠪ ᠦᠨ ᠪᠤᠰᠤ ᠪᠠᠶᠢᠳᠠᠯ ᠣᠷᠣᠰᠢᠵᠤ ᠪᠠᠶᠢᠨ᠎ᠠ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "གསར་བཅོས་བྱེད་པ་དང་མ་ལག་ཁོར་ཡུག་ལ་རྒྱུན་ལྡན་མིན་པ་ཡོད།"
        else:     
            error_dict["Describe"] = "更新补丁与系统环境存在异常"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "1"  #无法修复  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
    
def check_0203(error_cls,locale_temp):#管家调用通用网络诊断来修复
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str 
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "Unable to download patch pack"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "無法下載補丁包"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠨᠥᠬᠥᠵᠦ ᠨᠥᠬᠥᠵᠦ ᠳᠡᠶᠢᠯᠬᠦ ᠦᠭᠡᠢ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "ཐུམ་རྒྱག་པ་ཕབ་ལེན་བྱེད་ཐབས་མེད།"
        else:         
            error_dict["Describe"] = "无法下载补丁包"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "2"  #通用网络检测修复  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
   
def check_0204(error_cls,locale_temp):#管家调用通用磁盘清理来修复
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "Insufficient disk space"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "磁碟空間不足"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠰᠣᠷᠢᠨᠵᠢᠨ ᠫᠠᠨᠰᠠ ᠶᠢᠨ ᠣᠷᠣᠨ ᠵᠠᠶ ᠬᠦᠷᠦᠯᠴᠡᠬᠦ ᠦᠭᠡᠢ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "ཁབ་ལེན་གྱི་བར་སྟོང་མི་འདང་།"
        else:        
            error_dict["Describe"] = "磁盘空间不足"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "3"  #通用磁盘清理修复  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
    
def check_0205(error_cls,locale_temp):#无法修复，管家处理
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str 
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "Patch format abnormality"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "補丁格式異常"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠨᠦᠬᠦᠪᠦᠷᠢ ᠮᠠᠶᠢᠭ ᠨᠢ ᠬᠡᠪ ᠦᠨ ᠪᠤᠰᠤ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "ལྷན་པ་རྒྱག་སྟངས་རྒྱུན་ལྡན་མིན་པ།"
        else:      
            error_dict["Describe"] = "补丁格式异常"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "1"  #通用磁盘清理修复  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
    
def check_0208(error_cls,locale_temp):#无法修复，管家处理
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str 
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "Insufficient device power"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "設備電量不足"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠲᠥᠬᠥᠭᠡᠷᠦᠮᠵᠢ ᠶᠢᠨ ᠴᠠᠬᠢᠯᠭᠠᠨ ᠤ ᠬᠡᠮᠵᠢᠶ᠎ᠡ ᠬᠦᠷᠦᠯᠴᠡᠬᠦ ᠦᠭᠡᠶ"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "སྒྲིག་ཆས་ཀྱི་གློག་ཚད་མི་འདང་བ།"
        else:      
            error_dict["Describe"] = "设备电量不足"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "1"  #通用磁盘清理修复  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
    
def check_0209(error_cls,locale_temp):#无法修复，管家处理
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str      
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "Patch format abnormality"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "補丁格式異常"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠨᠦᠬᠦᠪᠦᠷᠢ ᠮᠠᠶᠢᠭ ᠨᠢ ᠬᠡᠪ ᠦᠨ ᠪᠤᠰᠤ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "ལྷན་པ་རྒྱག་སྟངས་རྒྱུན་ལྡན་མིན་པ།"
        else:      
            error_dict["Describe"] = "补丁格式异常"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "1"  #通用磁盘清理修复  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
    
def check_0215(error_cls,locale_temp):
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str      
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "Abnormal update environment"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "更新環境存在異常"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠣᠷᠴᠢᠨ ᠲᠣᠭᠣᠷᠢᠨ ᠢ ᠰᠢᠨᠡᠳᠬᠡᠬᠦ ᠳᠦ ᠬᠡᠪ ᠦᠨ ᠪᠤᠰᠤ ᠪᠠᠶᠢᠳᠠᠯ ᠣᠷᠣᠰᠢᠵᠤ ᠪᠠᠶᠢᠨ᠎ᠠ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "ཁོར་ཡུག་གསར་སྒྱུར་བྱེད་པར་རྒྱུན་ལྡན་མིན་པ་ཡོད།"
        else:
            error_dict["Describe"] = "更新环境存在异常"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "0"  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
    
def check_0217(error_cls,locale_temp):#无法修复，管家处理
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "System upgrade abnormal interrupt"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "系統升級異常中斷"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠰᠢᠰᠲ᠋ᠧᠮ ᠦᠨ ᠳᠡᠰ ᠳᠡᠪᠰᠢᠬᠦ ᠨᠢ ᠬᠡᠪ ᠦᠨ ᠪᠤᠰᠤ ᠪᠠᠶᠢᠳᠠᠯ ᠲᠠᠰᠤᠷᠠᠪᠠ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "མ་ལག་རིམ་སྤར་རྒྱུན་ལྡན་མིན་པའི་མཚམས་ཆད་པ་རེད།"
        else:      
            error_dict["Describe"] = "系统升级异常中断"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "1"  #通用磁盘清理修复  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
def check_else(error_cls,locale_temp):#无法修复，管家处理
    try:
        hexerror_cls_str = str(hex(int(error_cls)))  
        
        if len(hexerror_cls_str) == 17:
            hexerror_cls_str = add_char_to_string(hexerror_cls_str)
        print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
        
        my_dict = {}
        error_dict = {}
        overview_str = "检测了1项,1项错误,0项正确"
        error_dict["ErrorCode"] = hexerror_cls_str
        if int(locale_temp) == 1: #英文   
            error_dict["Describe"] = "Unrecognized error code"     
        elif int(locale_temp) == 2: #繁体中文
            error_dict["Describe"] = "未識別錯誤碼"
        elif int(locale_temp) == 3: #蒙古文
            error_dict["Describe"] = "ᠪᠤᠷᠤᠭᠤ ᠨᠣᠮᠧᠷ ᠢ ᠢᠯᠭᠠᠵᠤ ᠴᠢᠳᠠᠭᠰᠠᠨ ᠦᠭᠡᠢ ᠃"
        elif int(locale_temp) == 4: #藏文
            error_dict["Describe"] = "ནོར་འཁྲུལ་གྱི་ཨང་གྲངས་མ་ཤེས་པ།"
        else:        
            error_dict["Describe"] = "未识别错误码"
        error_dict["Context"] = ""
        error_dict["Name"] = "Upgrade"
        error_dict["CanRepair"] = "1"  #通用磁盘清理修复  
        error_dict["NetworkState"] = "0"  #未进行网络检测 
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str   
        my_dict["Details"] = [error_dict]
        print_deg("in checkitem,my_dict = "+str(my_dict))
        json_table_str = json.dumps(my_dict)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate,e = ",e)
        return -1
    return 0
    pass
def rewrite_json(networkstate):
    try:
        my_dict = json.load(open("/tmp/kydoctor"))
        if len(my_dict["Details"]) > 0 and "NetworkState" in my_dict["Details"][0]:
            my_dict["Details"][0]["NetworkState"] = str(networkstate)
            json_table_str = json.dumps(my_dict)

            #开始往临时文件中写数据
            report_result_name = "/tmp/kydoctor"
            result_fd = open(report_result_name,"w")
            result_fd.write(json_table_str)
            result_fd.close()
    except Exception as e:
        print("i am in checkitem_non_sysupdate-rewrite_json,e = ",e)   
if __name__ == "__main__":
    ret = 0
    #print("i am in checkitem_non_sysupdate.py sys.argv[1] = ",sys.argv[1])
    if int(sys.argv[1]) == 0x1100010200000100:
        ret = check_0100(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000101:
        ret = check_0101(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000102:
        ret = check_0102(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000107:
        ret = check_0107(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000111:
        ret = check_0111(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000112:
        ret = check_0112(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000113:
        ret = check_0113(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000114:
        ret = check_0114(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000115:
        ret = check_0115(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000116:
        ret = check_0116(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000117:
        ret = check_0117(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000119:
        ret = check_0119(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000121:
        ret = check_0121(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000122:
        ret = check_0122(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000200:
        ret = check_0200(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000201:
        ret = check_0201(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000202:
        ret = check_0202(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000203:
        ret = check_0203(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000204:
        ret = check_0204(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000205:
        ret = check_0205(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000208:
        ret = check_0208(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000209:
        ret = check_0209(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000215:
        ret = check_0215(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 0x1100010200000217:
        ret = check_0217(sys.argv[1],sys.argv[2])
    elif int(sys.argv[1]) == 1:  #网络检测与修复成功
        ret = rewrite_json(sys.argv[1])
    elif int(sys.argv[1]) == 2:  #网络检测与修复失败
        ret = rewrite_json(sys.argv[1])
    else:
        ret = check_else(sys.argv[1],sys.argv[2])
    if ret == -1:
        exit(-1)
    else:
        exit(0)