"""Copyright (c) KylinSoft  Co., Ltd. [2024].All rights reserved.
/*[kydoctor] licensed under the [Your LICENSE].
***************Your LICENSE Messages***********************
Author: [WangShuai]
Create: [2024]
"""
import json
import os
import sys
import re
import time
from common_variables import PRINT_DEBUG

def print_deg(print_str):
    if PRINT_DEBUG == 1:
        print(print_str)

def repairsystemupdate_s():
    cc = os.popen("bash /opt/kydoctor/python_src/fix-tool.sh -s 2>&1")
    #cc_strs = cc.readlines()
    ces_str = cc.read()
    ces_lines = ces_str.split("\n")
    for ces_line in ces_lines:
        print_deg("ces_line = "+str(ces_line))
        if "upgraded" in ces_line and "installed" in ces_line and "downgraded" in ces_line and "remove" in ces_line:
            downgraded_num_str = ces_line.split(",")[2].strip()
            downgraded_num = downgraded_num_str.split(" ")[0]
            print_deg("downgraded_num = "+str(downgraded_num))

            remove_num_str = ces_line.split(",")[3].strip()
            remove_num = remove_num_str.split(" ")[0]
            print_deg("remove_num = "+str(remove_num))

            if int(downgraded_num) > 0 or int(remove_num) > 0:
                print("need downgraded  or remove other package ,return")
                #开始往临时文件中写数据
                json_table_str = "需要降级 " + str(downgraded_num) + " 个包，需要删除 " + str(remove_num) + " 个包"
                report_result_name = "/tmp/kydoctor"
                result_fd = open(report_result_name,"w")
                result_fd.write(json_table_str)
                result_fd.close()
                return 0
            break
        elif "upgraded" in ces_line and "installed" in ces_line and "remove" in ces_line:
            remove_num_str = ces_line.split(",")[2].strip()
            #print("remove_num_str =",remove_num_str)
            remove_num = remove_num_str.split(" ")[0]
            print_deg("remove_num = "+str(remove_num))
            if int(remove_num) > 0:
                print("need remove other package ,return")
                #开始往临时文件中写数据
                json_table_str = "需要删除 " + str(remove_num) + " 个包"
                report_result_name = "/tmp/kydoctor"
                result_fd = open(report_result_name,"w")
                result_fd.write(json_table_str)
                result_fd.close()
                return 0
            break
    #开始往临时文件中写数据
    json_table_str = "需要降级 0 个包，需要删除 0 个包"
    report_result_name = "/tmp/kydoctor"
    result_fd = open(report_result_name,"w")
    result_fd.write(json_table_str)
    result_fd.close()
    pass
def repairsystemupdate():
    os.system("bash /opt/kydoctor/python_src/fix-tool.sh -y ")
    #print("------------------cc = ",cc)
    ret = os.system("bash /opt/kydoctor/python_src/fix-tool.sh -c > /dev/null")
    if ret == 0:
        return 0
    else:
        return 1
    pass
def is_symlink(file_path):
    try:
        inode = os.stat(file_path).st_ino  
        link_inode = os.lstat(file_path).st_ino
        if inode == link_inode:
            return 1
        else:
            return 0
    except:
        return -1
def repairsystemupdate100():
    try:
        print_deg("i am in repairsystemupdate100")
        update_cmd = "dbus-send --system --type=method_call --print-reply --dest=com.kylin.software.properties /com/kylin/software/properties com.kylin.software.properties.interface.quitDbus"
        cc = os.system(update_cmd)
        if cc != 0:
            return -1
        time.sleep(1)
        update_cmd = "dbus-send --system --type=method_call --print-reply --dest=com.kylin.sodbus-send --system --type=method_call --print-reply --dest=com.kylin.software.properties /com/kylin/software/properties com.kylin.software.properties.interface.updateSourceTemplateftware.properties /com/kylin/software/properties com.kylin.software.properties.interface.updateSourceTemplate  2>&1"
        cc_str = os.popen(update_cmd)
        cc_strs = cc_str.read()
        if "true" not in cc_strs:
            return -1
    except Exception as e:
        print("i am in repairsystemupdate100,e = ",e)
        return -1
    return 0

    pass
def repairsystemupdate107():
    try:
        update_cmd = "apt install kylin-update-desktop-config"
        cc = os.system(update_cmd)
        if cc != 0:
            return -1
        update_cmd = "dpkg -l | grep kylin-update-desktop-config 2>&1"
        cc_str = os.popen(update_cmd)
        cc_strs = cc_str.read()
        if "kylin-update-desktop-config" in cc_strs and "ii" in cc_strs and cc_strs.startswith("ii"):
            return 0
        else:
            return -1

    except Exception as e:
        print("i am in repairsystemupdate107,e = ",e)
        return -1      
    return 0
    pass

def repairsystemupdate111():
    try:
        update_cmd = "apt install kylin-update-desktop-config"
        cc = os.system(update_cmd)
        if cc != 0:
            return -1
        update_cmd = "dpkg -l | grep kylin-update-desktop-config 2>&1"
        cc_str = os.popen(update_cmd)
        cc_strs = cc_str.read()
        if "kylin-update-desktop-config" in cc_strs and "ii" in cc_strs and cc_strs.startswith("ii"):
            return 0
        else:
            return -1

    except Exception as e:
        print("i am in repairsystemupdate111,e = ",e)
        return -1      
    return 0
    pass

def repairsystemupdate113():
    try:
        update_cmd = "apt reinstall kylin-update-desktop-config"
        cc = os.system(update_cmd)
        if cc != 0:
            return -1
    except Exception as e:
        print("i am in repairsystemupdate113,e = ",e)
        return -1      
    return 0
    pass

def repairsystemupdate114():
    try:
        update_cmd = "/opt/kydoctor/python_src/fix-tool.sh -r"
        cc = os.system(update_cmd)
        if cc != 0:
            return -1
    except Exception as e:
        print("i am in repairsystemupdate114,e = ",e)
        return -1      
    return 0
    pass

def repairsystemupdate115():
    try:
        # update_cmd = "apt update"
        # cc = os.system(update_cmd)
        # if cc != 0:
        #     return -1
        # update_cmd = "rm /var/lib/apt/lists/*Packages /var/lib/apt/lists/*InRelease"
        # cc = os.system(update_cmd)
        # if cc != 0:
        #     return -1
        update_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 apt update  -c /etc/kylin-system-updater/apt_private.conf"
        cc = os.system(update_cmd)
        if cc != 0:
            return -1
        update_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 apt update  -c /etc/kylin-system-updater/apt_private.conf 2>&1"
        cc_str = os.popen(update_cmd)
        cc_strs = cc_str.read()
        if "Err:" in cc_strs or "W:" in  cc_strs:
            return -1
    except Exception as e:
        print("i am in repairsystemupdate115,e = ",e)
        return -1      
    return 0
    pass

def repairsystemupdate116():
    try:
        update_cmd = "apt update"
        cc = os.system(update_cmd)
        if cc != 0:
            return -1
        update_cmd = "rm /var/lib/apt/lists/*Packages /var/lib/apt/lists/*InRelease"
        cc = os.system(update_cmd)
        if cc != 0:
            return -1
        update_cmd = "apt update -c /etc/kylin-system-updater/apt_private.conf"
        cc = os.system(update_cmd)
        if cc != 0:
            return -1
        update_cmd = "apt update -c /etc/kylin-system-updater/apt_private.conf 2>&1"
        cc_str = os.popen(update_cmd)
        cc_strs = cc_str.read()
        if "Err" in cc_strs:
            return -1
    except Exception as e:
        print("i am in repairsystemupdate115,e = ",e)
        return -1      
    return 0
    pass

def repairsystemupdate119():
    try:
        usr_local_lib_libs = []
        usr_lib_libs = []
        dir1 = "/usr/local/lib/"
        dir2 = "/usr/lib/"
        #检索/usr/local/lib下面所有so文件（非目录），得到列表
        for f in os.listdir(dir1):
            if '.so' in f:
                usr_local_lib_libs.append(f)
    
        #检索/usr/lib下面所有的so文件（非目录及软链接文件），得到列表
        # for f in os.listdir(dir2):
        #     if '.so' in f:
        #         ret = is_symlink(dir2+f)
        #         if  ret == 1:
        #             usr_lib_libs.append(f)
        print_deg("usr_local_lib_libs = "+str(usr_local_lib_libs))
        #print_deg("usr_lib_libs = "+str(usr_lib_libs))
        #遍历/usr/local/lib列表，dpkg -S /usr/local/lib/*,如果不是软件包安装的，且/usr/lib/下面有同名的，则重命名这个文件
        for lib in usr_local_lib_libs:
            cmd_str = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 dpkg -S /usr/lib/" + str(lib)  + " 2>&1"
            cc1 = os.system(cmd_str)
            if cc1 == 0:
                os.rename("/usr/local/lib/"+str(lib),"/usr/local/lib/"+str(lib)+".backup")
                continue
            cmd_str = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 dpkg -S /usr/lib/*/" + str(lib)  + " 2>&1"
            cc1 = os.system(cmd_str)
            if cc1 == 0:
                os.rename("/usr/local/lib/"+str(lib),"/usr/local/lib/"+str(lib)+".backup")                
            # cc_strs = cc1.read()
            # if "dpkg-query:" in cc_strs:
            #     if lib in usr_lib_libs:
            #         os.rename("/usr/local/lib/"+str(lib),"/usr/local/lib/"+str(lib)+".backup")
    except Exception as e:
        print("i am in repairsystemupdate119,e = ",e)
        return -1
    return 0
    pass
    # try:
    #     usr_local_lib_libs = []
    #     usr_lib_libs = []
    #     dir1 = "/usr/local/lib/"
    #     dir2 = "/usr/lib/"
    #     #检索/usr/local/lib下面所有so文件（非目录及软链接文件），得到列表
    #     for f in os.listdir(dir1):
    #         if '.so' in f:
    #             ret = is_symlink(dir1+f)
    #             if ret == 1:
    #                 usr_local_lib_libs.append(f)
    
    #     #检索/usr/lib下面所有的so文件（非目录及软链接文件），得到列表
    #     for f in os.listdir(dir2):
    #         if '.so' in f:
    #             ret = is_symlink(dir2+f)
    #             if  ret == 1:
    #                 usr_lib_libs.append(f)
    #     print_deg("usr_local_lib_libs = "+str(usr_local_lib_libs))
    #     print_deg("usr_lib_libs = "+str(usr_lib_libs))
    #     #遍历/usr/local/lib列表，dpkg -S /usr/local/lib/*,如果不是软件包安装的，且/usr/lib/下面有同名的，则重命名这个文件
    #     for lib in usr_local_lib_libs:
    #         cmd_str = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 dpkg -S /usr/local/lib/" + str(lib)  + " 2>&1"
    #         cc1 = os.popen(cmd_str)
    #         cc_strs = cc1.read()
    #         if "dpkg-query:" in cc_strs:
    #             if lib in usr_lib_libs:
    #                 os.rename("/usr/local/lib/"+str(lib),"/usr/local/lib/"+str(lib)+".backup")
    # except Exception as e:
    #     print("i am in repairsystemupdate119,e = ",e)
    #     return -1
    # return 0
    # pass
def repairsystemupdate122():
    try:
        update_cmd = "chattr -i /var/lib/kylin-system-updater/sources.list"
        cc = os.system(update_cmd)
        if cc != 0:
            return -1
        update_cmd = "chmod u+w /var/lib/kylin-system-updater/sources.list"
        cc = os.system(update_cmd)
        if cc != 0:
            return -1
        update_cmd = "lsattr /var/lib/kylin-system-updater/sources.list"
        cc_str = os.popen(update_cmd)
        cc_strs = cc_str.read()
        cc_strs_1 = cc_strs.split(" ")[0]
        if "i" in cc_strs_1:
            return -1
        update_cmd = "ls -al /var/lib/kylin-system-updater/sources.list"
        cc_str = os.popen(update_cmd)
        cc_strs = cc_str.read()
        if cc_strs[2] != "w":
            return -1
    except Exception as e:
        print("i am in repairsystemupdate119,e = ",e)
        return -1      
    return 0
def repairsystemupdate200():
    try:
        update_cmd = "/opt/kydoctor/python_src/fix-tool.sh -r"
        cc = os.system(update_cmd)
        if cc != 0:
            return -1
    except Exception as e:
        print("i am in repairsystemupdate114,e = ",e)
        return -1      
    return 0
    pass

def repairsystemupdate215():
    try:
        update_cmd = "rm /var/lib/apt/lists/*Packages /var/lib/apt/lists/*InRelease"
        cc = os.system(update_cmd)
        if cc != 0:
            return -1
        update_cmd = "apt update"
        cc = os.system(update_cmd)
        if cc != 0:
            return -1
        update_cmd = "apt update 2>&1"
        cc_str = os.popen(update_cmd)
        cc_strs = cc_str.read()
        if "Err" in cc_strs:
            return -1
    except Exception as e:
        print("i am in repairsystemupdate115,e = ",e)
        return -1      
    return 0
    pass
if __name__ == "__main__":
    ret = 0
    # if int(sys.argv[1]) == 1:
    #     print_deg("i am in repairsystemupdate_s--------")
    #     ret = repairsystemupdate_s()
    # elif int(sys.argv[1]) == 2:
    #     print_deg("i am in repairsystemupdate--------")
    #     ret = repairsystemupdate()
    print_deg("i am in repair_sysupdate --------sys.argv[1] = "+sys.argv[1])
    if sys.argv[1] == "0x1100010200000100":
        ret = repairsystemupdate100()
    elif sys.argv[1] == "0x1100010200000107":
        ret = repairsystemupdate107()
    elif sys.argv[1] == "0x1100010200000111":
        ret = repairsystemupdate111()
    elif sys.argv[1] == "0x1100010200000113":
        ret = repairsystemupdate113()
    elif sys.argv[1] == "0x1100010200000114":
        ret = repairsystemupdate114()
    elif sys.argv[1] == "0x1100010200000115":
        ret = repairsystemupdate115()
    elif sys.argv[1] == "0x1100010200000116":
        ret = repairsystemupdate116()
    elif sys.argv[1] == "0x1100010200000119":
        ret = repairsystemupdate119()
    elif sys.argv[1] == "0x1100010200000122":
        ret = repairsystemupdate122()
    elif sys.argv[1] == "0x1100010200000200":
        ret = repairsystemupdate200()
    elif sys.argv[1] == "0x1100010200000215":
        ret = repairsystemupdate215()

    print("i am in repairsoftshop,main ==  ret = ",ret)
    exit(ret)