"""Copyright (c) KylinSoft  Co., Ltd. [2024].All rights reserved.
/*[kydoctor] licensed under the [Your LICENSE].
***************Your LICENSE Messages***********************
Author: [WangShuai]
Create: [2024]
"""
import json
import os
import sys
import re
from common_variables import PRINT_DEBUG

def print_deg(print_str):
    if PRINT_DEBUG == 1:
        print(print_str)
#字符串增加一位
def add_char_to_string(string1):
    string_list = list(string1)
    string_list.insert(2,0)
    new_string = ''.join(str(x) for x in string_list)
    return new_string
def repairsoftshop_s(deb_name):
    try:
        line_table = []
        ret_deb_name = []
        remove_deb_name = [] #要返回的包列表
        down_deb_name = []   #要返回的包列表
        update_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 apt-get --print-uris install " + deb_name + " 2>&1"
        cc1 = os.popen(update_cmd)
        cc_strs = cc1.readlines()
        for line in cc_strs:
            if "Depends" in line and "install" in line:
                if "not" in line and "installable" in line:
                    line_table.insert(0,line) #该应用包名的依赖冲突，优先检测but is not installable的依赖问题
                else: 
                    line_table.append(line)
        print_deg("i am in repairsoftshop ,line_table = "+str(line_table))
        dependsdeb_num = 0
        for strstr in line_table:
            str_none = strstr.split("Depends")
            if str_none[0].strip() != "":
                dependsdeb_num = dependsdeb_num +1  #存在包名以外的包有依赖问题
        if dependsdeb_num > 1:
            print_deg("dependsdeb_num > 1")
            cc = os.popen("bash /opt/kydoctor/python_src/fix-tool.sh -s 2>&1")
            #cc_strs = cc.readlines()
            ces_str = cc.read()
            ces_lines = ces_str.split("\n")
            remove_deb_name_str = []
            down_deb_name_str = []
            for line in ces_lines:
                print_deg("line = "+str(line))
                if "following" in line and "packages" in line and "downgraded" in line.lower():
                    down_deb_name_str.append(cc_strs[cc_strs.index(line)+1])
                elif "following" in line and "packages" in line and "remove" in line.lower():
                    remove_deb_name_str.append(cc_strs[cc_strs.index(line)+1])
                if remove_deb_name_str != []:
                    for ret_line in remove_deb_name_str:
                        ret_line1 = ret_line.strip(" ").strip("\n")
                        for ret_line1_s in ret_line1.split(" "):
                            remove_deb_name.append(ret_line1_s)
                if down_deb_name_str != []:
                    for ret_line in down_deb_name_str:
                        ret_line1 = ret_line.strip(" ").strip("\n")
                        for ret_line1_s in ret_line1.split(" "):
                            down_deb_name.append(ret_line1_s)
            #ret_deb_name[remove_deb_name,down_deb_name]
            ret_deb_name.append(remove_deb_name)
            ret_deb_name.append(down_deb_name)
            #return 1 #提示：手动修复的方法--"系统本身存在依赖问题，请手动执行sudo dpkg --configure -a、sudo apt-get install -f修复"
        elif dependsdeb_num == 1: #将所有的依赖行都扫一遍，如果其还有依赖或失败，则退出，提示手动修复
            print_deg("dependsdeb_num == 1")
            depend_deb_name = []
            for strstr in line_table:
                str_none = strstr.split("Depends:")
                if "(" in str_none[1] and ")" in str_none[1]:
                    kuohao_str = re.search(r'\((.*?)\)',str_none[1]).group(1)
                    kuohao_str = kuohao_str.replace(" ","").strip()
                    
                    if "=" in kuohao_str:
                        kuohao_str = kuohao_str.split('=')[1]
                    elif ">" in kuohao_str:
                        kuohao_str = kuohao_str.split('>')[1]
                    #print("kuohao_str=",kuohao_str)
                    str_none_d = str_none[1].strip()
                    deb_name = str_none_d.split()
                    #print("deb_name =",deb_name[0])
                    deb_name_id = deb_name[0]+"="+kuohao_str
                    print_deg("deb_name_id ="+str(deb_name_id))
                    depend_deb_name.append(str(deb_name_id))
                    #得到包名以及对应的版本号，接下来apt-get install deb_name_id,并判断返回值
                    # update_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 apt-get --print-uris install " + deb_name_id + " 2>&1"
                    # ces = os.popen(update_cmd)
                    # ces_str = ces.read()

                    # if "Depends" in ces_str or "depends" in ces_str or "E: " in ces_str:
                    #     print_deg("depends other package or E: ,don't update")
                    #     return 2
                else:
                    str_none_d = str_none[1].strip()
                    deb_name = str_none_d.split()
                    print_deg("deb_name ="+str(deb_name[0]))
                    depend_deb_name.append(str(deb_name[0]))
                    # update_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 apt-get --print-uris install " + deb_name[0] + " 2>&1"
                    # ces = os.popen(update_cmd)
                    # ces_str = ces.read()

                    # if "Depends" in ces_str or "depends" in ces_str or "E: " in ces_str:
                    #     print_deg("depends other package or E: ,don't update")
                    #     return 2
            #根据LANG=en_US.utf8 LANGUAGE=en_US.utf8 apt-get --simulate install deb1 deb2 deb3 ... 2>&1返回值，解析需要降级或删除的包列表
            update_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 apt-get --simulate install"
            for depend_deb_name1 in depend_deb_name:
                update_cmd = update_cmd + " " + depend_deb_name1
            update_cmd = update_cmd + " 2>&1"
            print("--------------- end update_cmd = ",update_cmd)
            cc1 = os.popen(update_cmd)
            cc_strs = cc1.readlines()
            remove_deb_name_str = []
            down_deb_name_str = []
            for line in cc_strs: 
                if "following" in line and "packages" in line and "downgraded" in line.lower():
                    down_deb_name_str.append(cc_strs[cc_strs.index(line)+1])
                elif "following" in line and "packages" in line and "remove" in line.lower():
                    remove_deb_name_str.append(cc_strs[cc_strs.index(line)+1])
            if remove_deb_name_str != []:
                for ret_line in remove_deb_name_str:
                    ret_line1 = ret_line.strip(" ").strip("\n")
                    for ret_line1_s in ret_line1.split(" "):
                        remove_deb_name.append(ret_line1_s)
            if down_deb_name_str != []:
                for ret_line in down_deb_name_str:
                    ret_line1 = ret_line.strip(" ").strip("\n")
                    for ret_line1_s in ret_line1.split(" "):
                        down_deb_name.append(ret_line1_s)
            #ret_deb_name[remove_deb_name,down_deb_name]
            ret_deb_name.append(remove_deb_name)
            ret_deb_name.append(down_deb_name)
        else:
            print_deg("dependsdeb_num == 0")
        pass
    except Exception as e:
        print("i am in repairsoftshop,e = ",e)
        return [[],[]]
    print("--------------ret_deb_name = ",ret_deb_name)
    return ret_deb_name
def checkitem_kylinshop(error_cls,deb_name):
    hexerror_cls_str = str(hex(int(error_cls)))
    
    if len(hexerror_cls_str) == 17:
        hexerror_cls_str = add_char_to_string(hexerror_cls_str)
    print_deg("hexerror_cls_str = "+str(hexerror_cls_str))
    update_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 apt-get --print-uris install " + deb_name + " 2>&1"
    
    my_dict = {}
    cc1 = os.popen(update_cmd)
    cc_strs = cc1.readlines()
    for cc_str in cc_strs:
        if "Depends" in cc_str and "install" in cc_str:
            error_dict = {}
            error_dict["ErrorCode"] = hexerror_cls_str
            #cc = os.popen(update_cmd)
            #ccs = cc.read()
            ccs_ret = repairsoftshop_s(deb_name)
            #ccs = ""
            ccs = "Delete:"
            if ccs_ret[0] != []:                
                for r_deb in cc_ret[0]:
                    ccs = ccs + " " + r_deb
            ccs = ccs + "\r\nDowngrading:"
            if ccs_ret[1] != []:
                for d_deb in cc_ret[1]:
                    ccs = ccs + " " + d_deb
            print("------------------------ ccs = ",ccs)
            error_dict["Describe"] = "" #ccs            
            error_dict["Name"] = "Software"
            error_dict["Context"] = ccs
            error_dict["CanRepair"] = "5"
            error_dict["NetworkState"] = "0"
            if "Details" not in my_dict:
                my_dict["Details"] = [error_dict]
            else:
                my_dict["Details"].append(error_dict)
            #test_error = test_all - test_right
            overview_str = "检测了1项,1项错误,0项正确"
            my_dict["Overview"] = overview_str
            my_dict["Type"] = hexerror_cls_str
            #print("i am in checkitem,my_dict = ",my_dict)
            break
    if len(my_dict) == 0:
        overview_str = "检测了1项,0项错误,1项正确"
        my_dict["Overview"] = overview_str
        my_dict["Type"] = hexerror_cls_str
        my_dict["Details"] = []
    print_deg("in checkitem,my_dict = "+str(my_dict))
    json_table_str = json.dumps(my_dict)

    #开始往临时文件中写数据
    report_result_name = "/tmp/kydoctor"
    result_fd = open(report_result_name,"w")
    result_fd.write(json_table_str)
    result_fd.close()

    #开始往临时文件中写数据
    report_result_name = "/tmp/kydoctor_softshop"
    result_fd = open(report_result_name,"w")
    for cc_str in cc_strs:
        result_fd.write(cc_str)
    result_fd.close()
 
if __name__ == "__main__":
    #ret = checkitemfromsql(sys.argv[1])
    print("i am in checkitem_non_universal.py,argv = ",sys.argv[1],sys.argv[2])
    ret = 0
    ret = checkitem_kylinshop(sys.argv[1],sys.argv[2])
    if ret == -1:
        exit(-1)
    else:
        exit(0)