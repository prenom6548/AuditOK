"""Copyright (c) KylinSoft  Co., Ltd. [2024].All rights reserved.
/*[kydoctor] licensed under the [Your LICENSE].
***************Your LICENSE Messages***********************
Author: [WangShuai]
Create: [2024]
"""
import sqlite3 as sqlite
import json
import os
import sys
from common_variables import PRINT_DEBUG
import subprocess
def print_deg(print_str):
    if PRINT_DEBUG == 1:
        print(print_str)
def get_system_type():
    try:
        # 执行 'dmidecode' 命令
        process = subprocess.Popen(['dmidecode'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        output, error = process.communicate()        
        if process.returncode != 0:
            print("Error executing 'dmidecode': {}".format(error.decode('utf-8')))
            return 1       
        dmidata = output.decode('utf-8').lower()
        if 'laptop' in dmidata or 'notebook' in dmidata:
            return 0 #"笔记本电脑"
        else:
            return 1 #"台式电脑"   
    except Exception as e:
        print("The 'dmidecode' command is not found. Please ensure it is installed. Error: {}".format(e))
        return 1
#检索数据库，将itemlist生成json格式字符串保存到临时文件中
def get_itemlistfromsql():
    db_dir = "/opt/kydoctor/common/db/" #数据库路径
    #db_dir = "./"
    db_dir_path = db_dir+"solution.db"
    if not os.path.exists(db_dir_path):
        print_deg("solution.db not exist!")
        return -1

    con = sqlite.connect(db_dir_path)
    try:
        my_dict = {}
        with con:
            cur = con.cursor()
            cur.execute("select * from checkitemlist")
            rows = cur.fetchall()
            for row in rows:
                table_temp = []
                table_temp.append(row[2])
                table_temp.append(row[3])
                table_temp.append(row[4])
                if row[1] not in my_dict:
                    my_dict[row[1]] = [table_temp]
                else:
                    my_dict[row[1]].append(table_temp)
            print_deg("my_dict = "+str(my_dict))

        json_table = []
        for key,item in my_dict.items():
            dict_temp = {}
            dict_temp["Category"] = key
            types_table = []
            #types_dict = {}
            for t1_item in item:
                #for t2_num in len(t1_item):
                #print("t1_item = ",t1_item)
                type_dict = {}
                type_dict["Type"] = t1_item[0]
                type_dict["Name"] = t1_item[1]
                type_dict["Describe"] = t1_item[2]
                types_table.append(type_dict)
            dict_temp["Types"] = types_table
            json_table.append(dict_temp)

        print_deg("str === "+str(json_table))
        #print(json.dumps(json_table))
        json_table_str = json.dumps(json_table)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
                            
        #return -1
    except Exception as e:
        print("in get_itemlist,error :",e)
        return -1
    return 0
    pass
def get_itemlistfromtxt():
    des_log_path = "/tmp/kydoctor_log"
    if os.path.exists(des_log_path):
        os.remove(des_log_path) 
    db_dir_path = "/tmp/kydoctor_c_sql"
    if not os.path.exists(db_dir_path):
        print_deg("/tmp/kydoctor_c_sql not exist!")
        return -1

    try:
        my_dict = {}
        file1 = open(db_dir_path)
        while True:
            text = file1.readline()
            if len(text) == 0:
                break
            row = text.split("+++")
            table_temp = []
            table_temp.append(row[2])
            table_temp.append(row[3])
            table_temp.append(row[4])
            if row[1] not in my_dict:
                my_dict[row[1]] = [table_temp]
            else:
                my_dict[row[1]].append(table_temp)
        print_deg("my_dict = "+str(my_dict))

        json_table = []
        for key,item in my_dict.items():
            dict_temp = {}
            dict_temp["Category"] = key
            types_table = []
            #types_dict = {}
            for t1_item in item:
                #for t2_num in len(t1_item):
                #print("t1_item = ",t1_item)
                type_dict = {}
                type_dict["Type"] = t1_item[0]
                type_dict["Name"] = t1_item[1]
                type_dict["Describe"] = t1_item[2]
                types_table.append(type_dict)
            dict_temp["Types"] = types_table
            json_table.append(dict_temp)

        print_deg("str === "+str(json_table))
        #print(json.dumps(json_table))
        json_table_str = json.dumps(json_table)

        #开始往临时文件中写数据
        report_result_name = "/tmp/kydoctor"
        result_fd = open(report_result_name,"w")
        result_fd.write(json_table_str)
        result_fd.close()
        file1.close()                   
        #return -1
    except Exception as e:
        if os.path.exists(db_dir_path):
            os.remove(db_dir_path)
        print("in get_itemlist,error :",e)
        return -1
    if os.path.exists(db_dir_path):
        os.remove(db_dir_path)
    return 0
    pass
def get_newdesign_itemlistfromtxt(locales_temp):
    des_log_path = "/tmp/kydoctor_log"
    if os.path.exists(des_log_path):
        os.remove(des_log_path) 
    db_dir_path = "/tmp/kydoctor_c_sql"
    if not os.path.exists(db_dir_path):
        print("/tmp/kydoctor_c_sql not exist!")
        return -1
    #print("i am in ")
    json_table = []

    if locales_temp == "1":
        json_dict_classa_1 = {"class_a":"Network detection"}
        json_dict_classa_2 = {"class_a":"System components and performance testing"}
        json_dict_classa_3 = {"class_a":"Application detection"}
        json_dict_classa_4 = {"class_a":"Online System Update Detection"}
    elif locales_temp == "2":
        json_dict_classa_1 = {"class_a":"網路檢測"}
        json_dict_classa_2 = {"class_a":"系統元件與功能檢測"}
        json_dict_classa_3 = {"class_a":"應用程式檢測"}
        json_dict_classa_4 = {"class_a":"系統線上更新檢測"}
    elif locales_temp == "3":
        json_dict_classa_1 = {"class_a":"ᠰᠦᠯᠵᠢᠶᠡᠨ ᠦ ᠪᠠᠶᠢᠴᠠᠭᠠᠨ ᠬᠡᠮᠵᠢᠯᠲᠡ ᠃"}
        json_dict_classa_2 = {"class_a":"ᠰᠢᠰᠲ᠋ᠧᠮ ᠦᠨ ᠲᠣᠨᠣᠭᠯᠠᠯ ᠪᠠ ᠴᠢᠳᠠᠪᠬᠢ ᠶᠢᠨ ᠬᠡᠮᠵᠢᠯᠲᠡ ᠃"}
        json_dict_classa_3 = {"class_a":"ᠬᠡᠷᠡᠭᠯᠡᠭᠡᠨ ᠦ ᠳᠡᠰ ᠳᠠᠷᠠᠭᠠᠯᠠᠯ ᠢ ᠪᠠᠶᠢᠴᠠᠭᠠᠨ ᠬᠡᠮᠵᠢᠬᠦ ᠃"}
        json_dict_classa_4 = {"class_a":"ᠰᠢᠰᠲ᠋ᠧᠮ ᠢ ᠰᠢᠨᠡᠳᠬᠡᠨ ᠪᠠᠶᠢᠴᠠᠭᠠᠨ ᠬᠡᠮᠵᠢᠨ᠎ᠡ ᠃"}
    elif locales_temp == "4":
        json_dict_classa_1 = {"class_a":"དྲ་རྒྱའི་ཞིབ་དཔྱད་ཚད་ལེན།"}
        json_dict_classa_2 = {"class_a":"མ་ལག་གི་ལྷུ་ལག་དང་ནུས་པའི་ཚད་ལེན་ཚོད་ལྟ།"}
        json_dict_classa_3 = {"class_a":"ཉེར་སྤྱོད་གོ་རིམ་ལ་ཞིབ་དཔྱད་ཚད་ལེན་བྱ་"}
        json_dict_classa_4 = {"class_a":"རྒྱུད་རིམ་ལྡན་པའི་སྒོ་ནས་ཞིབ་དཔྱད་ཚད་ལེན་"}
    else:
        json_dict_classa_1 = {"class_a":"网络检测"}
        json_dict_classa_2 = {"class_a":"系统组件与性能检测"}
        json_dict_classa_3 = {"class_a":"应用程序检测"}
        json_dict_classa_4 = {"class_a":"系统在线更新检测"}

    json_table_classb_1 = []        
    json_table_classb_2 = []
    json_table_classb_3 = []
    json_table_classb_4 = []

    try:
        file1 = open(db_dir_path)
        while True:
            text = file1.readline()
            if len(text) == 0:
                break
            text = text.rstrip("\n")
            row = text.split("+++")
            if len(row) < 4:
                continue
            #print("row = ",row)
            #解析每一行，如果其一级标题==等于“网络检测”
            if str(row[1]) == "网络检测" or str(row[1]) == "Network detection" or str(row[1]) == "網路檢測" or str(row[1]) == "ᠰᠦᠯᠵᠢᠶᠡᠨ ᠦ ᠪᠠᠶᠢᠴᠠᠭᠠᠨ ᠬᠡᠮᠵᠢᠯᠲᠡ ᠃" or str(row[1]) == "དྲ་རྒྱའི་ཞིབ་དཔྱད་ཚད་ལེན།":
                #拿到二级标题，解析json_table_classb_1下面所有的字典，判断二级标题是否等于其"Name"值
                temp_class2_equal = 0
                for temp_dict2 in json_table_classb_1:
                    if temp_dict2["Name"] == str(row[2]):
                        temp_class2_equal = 1
                        #2:找到一个等于，如果三级标题不为空，则遍历for temp in json_table_classb_1[i]["class_c"]下面的所有字典，判断
                        #三级标题是否等于temp["Name"],没有的话 则新增，有的话退出
                        if str(row[4]) != "":
                            temp_class3_equal = 0
                            for temp_dict3 in temp_dict2["class_c"]:
                                if row[4] == temp_dict3["Name"]:
                                    temp_class3_equal = 1
                                    break
                            if temp_class3_equal == 0:
                                temp_dict4={}
                                temp_dict4["Name"] = str(row[4])
                                temp_dict4["Describe"] = str(row[5])
                                temp_dict2["class_c"].append(temp_dict4)
                                #print("2------------- json_table_classb_1 = ",json_table_classb_1)
                #1：都不等于，则新建一个临时dict2={"Name"=二级标题，"Descripe"="描述"}，并且判断三级标题是否为空
                #不为空则dict2["class_c"] = [],dict3 = {"Name"=三级标题，"Descripe"="描述"}
                #为空的话dict2["class_c"] = []，插入到json_table_classb_1
                if temp_class2_equal == 0:
                    temp_dict2 = {}
                    temp_dict2["Name"] = str(row[2])
                    temp_dict2["Describe"] = str(row[3])
                    temp_dict2["class_b_id"] = str(row[6])
                    temp_dict2["class_c"] = []
                    temp_dict3_1 = {}
                    if str(row[4]) != "":
                        temp_dict3_1["Name"] = str(row[4])
                        temp_dict3_1["Describe"] = str(row[5])
                    temp_dict2["class_c"].append(temp_dict3_1)
                    json_table_classb_1.append(temp_dict2)
                    #print("1------------- json_table_classb_1 = ",json_table_classb_1)                                    
            elif row[1] == "系统组件与性能检测" or str(row[1]) == "System components and performance testing" or str(row[1]) == "系統元件與功能檢測" or str(row[1]) == "ᠰᠢᠰᠲ᠋ᠧᠮ ᠦᠨ ᠲᠣᠨᠣᠭᠯᠠᠯ ᠪᠠ ᠴᠢᠳᠠᠪᠬᠢ ᠶᠢᠨ ᠬᠡᠮᠵᠢᠯᠲᠡ ᠃" or str(row[1]) == "མ་ལག་གི་ལྷུ་ལག་དང་ནུས་པའི་ཚད་ལེན་ཚོད་ལྟ།":
                #拿到二级标题，解析json_table_classb_2下面所有的字典，判断二级标题是否等于其"Name"值
                temp_class2_equal = 0
                for temp_dict2 in json_table_classb_2:
                    if temp_dict2["Name"] == str(row[2]):
                        temp_class2_equal = 1
                        #2:找到一个等于，如果三级标题不为空，则遍历for temp in json_table_classb_2[i]["class_c"]下面的所有字典，判断
                        #三级标题是否等于temp["Name"],没有的话 则新增，有的话退出
                        if str(row[4]) != "":
                            temp_class3_equal = 0
                            for temp_dict3 in temp_dict2["class_c"]:
                                if row[4] == temp_dict3["Name"]:
                                    temp_class3_equal = 1
                                    break
                            if temp_class3_equal == 0:
                                temp_dict4={}
                                temp_dict4["Name"] = str(row[4])
                                temp_dict4["Describe"] = str(row[5])
                                temp_dict2["class_c"].append(temp_dict4)
                                #print("2------------- json_table_classb_2 = ",json_table_classb_2)
                #1：都不等于，则新建一个临时dict2={"Name"=二级标题，"Descripe"="描述"}，并且判断三级标题是否为空
                #不为空则dict2["class_c"] = [],dict3 = {"Name"=三级标题，"Descripe"="描述"}
                #为空的话dict2["class_c"] = []，插入到json_table_classb_2
                if temp_class2_equal == 0:
                    temp_dict2 = {}
                    if str(row[6]) == "0x020005":  #针对台式机不检测电池 特殊处理
                        type_sys = get_system_type()
                        if type_sys == 1:
                            #print("----------------------now system_type = ",type_sys)
                            continue        
                    if str(row[6]) == "0x020001":  #当设备不支持温度检测时，不显示此检测项
                        cc_s = os.popen("sensors | grep 'Core'")                        
                        cc_s_strs = cc_s.read()
                        if cc_s_strs == "":
                            #print("----------------------now sensors no 'Core' = ")
                            continue
                    temp_dict2["Name"] = str(row[2])
                    temp_dict2["Describe"] = str(row[3])
                    temp_dict2["class_b_id"] = str(row[6])
                    temp_dict2["class_c"] = []
                    temp_dict3_1 = {}
                    if str(row[4]) != "":
                        temp_dict3_1["Name"] = str(row[4])
                        temp_dict3_1["Describe"] = str(row[5])
                    temp_dict2["class_c"].append(temp_dict3_1)
                    json_table_classb_2.append(temp_dict2)
                    #print("1------------- json_table_classb_2 = ",json_table_classb_2)
                pass
            elif row[1] == "应用程序检测"  or str(row[1]) == "Application detection" or str(row[1]) == "應用程式檢測" or str(row[1]) == "ᠬᠡᠷᠡᠭᠯᠡᠭᠡᠨ ᠦ ᠳᠡᠰ ᠳᠠᠷᠠᠭᠠᠯᠠᠯ ᠢ ᠪᠠᠶᠢᠴᠠᠭᠠᠨ ᠬᠡᠮᠵᠢᠬᠦ ᠃" or str(row[1]) == "ཉེར་སྤྱོད་གོ་རིམ་ལ་ཞིབ་དཔྱད་ཚད་ལེན་བྱ་":
                 #拿到二级标题，解析json_table_classb_3下面所有的字典，判断二级标题是否等于其"Name"值
                temp_class2_equal = 0
                for temp_dict2 in json_table_classb_3:
                    if temp_dict2["Name"] == str(row[2]):
                        temp_class2_equal = 1
                        #2:找到一个等于，如果三级标题不为空，则遍历for temp in json_table_classb_3[i]["class_c"]下面的所有字典，判断
                        #三级标题是否等于temp["Name"],没有的话 则新增，有的话退出
                        if str(row[4]) != "":
                            temp_class3_equal = 0
                            for temp_dict3 in temp_dict2["class_c"]:
                                if row[4] == temp_dict3["Name"]:
                                    temp_class3_equal = 1
                                    break
                            if temp_class3_equal == 0:
                                temp_dict4={}
                                temp_dict4["Name"] = str(row[4])
                                temp_dict4["Describe"] = str(row[5])
                                temp_dict2["class_c"].append(temp_dict4)
                                #print("2------------- json_table_classb_3 = ",json_table_classb_3)
                #1：都不等于，则新建一个临时dict2={"Name"=二级标题，"Descripe"="描述"}，并且判断三级标题是否为空
                #不为空则dict2["class_c"] = [],dict3 = {"Name"=三级标题，"Descripe"="描述"}
                #为空的话dict2["class_c"] = []，插入到json_table_classb_3
                if temp_class2_equal == 0:
                    temp_dict2 = {}
                    temp_dict2["Name"] = str(row[2])
                    temp_dict2["Describe"] = str(row[3])
                    temp_dict2["class_b_id"] = str(row[6])
                    temp_dict2["class_c"] = []
                    temp_dict3_1 = {}
                    if str(row[4]) != "":
                        temp_dict3_1["Name"] = str(row[4])
                        temp_dict3_1["Describe"] = str(row[5])
                    temp_dict2["class_c"].append(temp_dict3_1)
                    json_table_classb_3.append(temp_dict2)
                    #print("1------------- json_table_classb_3 = ",json_table_classb_3)
                pass
            elif row[1] == "系统在线更新检测" or str(row[1]) == "Online System Update Detection" or str(row[1]) == "系統線上更新檢測" or str(row[1]) == "ᠰᠢᠰᠲ᠋ᠧᠮ ᠢ ᠰᠢᠨᠡᠳᠬᠡᠨ ᠪᠠᠶᠢᠴᠠᠭᠠᠨ ᠬᠡᠮᠵᠢᠨ᠎ᠡ ᠃" or str(row[1]) == "རྒྱུད་རིམ་ལྡན་པའི་སྒོ་ནས་ཞིབ་དཔྱད་ཚད་ལེན་":
                 #拿到二级标题，解析json_table_classb_4下面所有的字典，判断二级标题是否等于其"Name"值
                temp_class2_equal = 0
                for temp_dict2 in json_table_classb_4:
                    if temp_dict2["Name"] == str(row[2]):
                        temp_class2_equal = 1
                        #2:找到一个等于，如果三级标题不为空，则遍历for temp in json_table_classb_4[i]["class_c"]下面的所有字典，判断
                        #三级标题是否等于temp["Name"],没有的话 则新增，有的话退出
                        if str(row[4]) != "":
                            temp_class3_equal = 0
                            for temp_dict3 in temp_dict2["class_c"]:
                                if row[4] == temp_dict3["Name"]:
                                    temp_class3_equal = 1
                                    break
                            if temp_class3_equal == 0:
                                temp_dict4={}
                                temp_dict4["Name"] = str(row[4])
                                temp_dict4["Describe"] = str(row[5])
                                temp_dict2["class_c"].append(temp_dict4)
                                #print("2------------- json_table_classb_4 = ",json_table_classb_4)
                #1：都不等于，则新建一个临时dict2={"Name"=二级标题，"Descripe"="描述"}，并且判断三级标题是否为空
                #不为空则dict2["class_c"] = [],dict3 = {"Name"=三级标题，"Descripe"="描述"}
                #为空的话dict2["class_c"] = []，插入到json_table_classb_2
                if temp_class2_equal == 0:
                    temp_dict2 = {}
                    temp_dict2["Name"] = str(row[2])
                    temp_dict2["Describe"] = str(row[3])
                    temp_dict2["class_b_id"] = str(row[6])
                    temp_dict2["class_c"] = []
                    temp_dict3_1 = {}
                    if str(row[4]) != "":
                        temp_dict3_1["Name"] = str(row[4])
                        temp_dict3_1["Describe"] = str(row[5])
                    temp_dict2["class_c"].append(temp_dict3_1)
                    if temp_dict2["class_b_id"] != "0x040001":   #主线备份空间检测跟工行不一样，主线不添加此功能
                        json_table_classb_4.append(temp_dict2)
                    #print("1------------- json_table_classb_4 = ",json_table_classb_4)
                pass
    except Exception as e:
        if os.path.exists(db_dir_path):
            os.remove(db_dir_path)
        print("e = ",e)
        return -1
    json_dict_classa_1["class_b"] = json_table_classb_1
    json_dict_classa_2["class_b"] = json_table_classb_2
    json_dict_classa_3["class_b"] = json_table_classb_3
    json_dict_classa_4["class_b"] = json_table_classb_4
    #最后
    json_table.append(json_dict_classa_1)
    json_table.append(json_dict_classa_2)
    json_table.append(json_dict_classa_3)
    json_table.append(json_dict_classa_4)

    print_deg("55------------- json_table = "+str(json_table))
    json_table_str = json.dumps(json_table)

    #开始往临时文件中写数据
    report_result_name = "/tmp/kydoctor"
    result_fd = open(report_result_name,"w")
    result_fd.write(json_table_str)
    result_fd.close()
    file1.close()
    if os.path.exists(db_dir_path):
        os.remove(db_dir_path)
    return 0
def get_newdesign_itemlistfromtxt_gh(locales_temp):
    des_log_path = "/tmp/kydoctor_log"
    if os.path.exists(des_log_path):
        os.remove(des_log_path) 
    db_dir_path = "/tmp/kydoctor_c_sql"
    if not os.path.exists(db_dir_path):
        print("/tmp/kydoctor_c_sql not exist!")
        return -1
    #print("i am in ")
    json_table = []

    if locales_temp == "1":
        json_dict_classa_1 = {"class_a":"System update detection"}
        json_dict_classa_2 = {"class_a":"Software Store Detection"}
        json_dict_classa_3 = {"class_a":"System disk availability detection"}
        json_dict_classa_4 = {"class_a":"Wired network detection"}
        json_dict_classa_5 = {"class_a":"Wireless network detection"}
    elif locales_temp == "2":
        json_dict_classa_1 = {"class_a":"系統更新檢測"}
        json_dict_classa_2 = {"class_a":"軟體商店檢測"}
        json_dict_classa_3 = {"class_a":"系統磁碟可用性檢測"}
        json_dict_classa_4 = {"class_a":"有線網路檢測"}
        json_dict_classa_5 = {"class_a":"無線網路檢測"}
    elif locales_temp == "3":
        json_dict_classa_1 = {"class_a":"ᠰᠢᠰᠲ᠋ᠧᠮ ᠢ ᠰᠢᠨᠡᠳᠬᠡᠨ ᠪᠠᠶᠢᠴᠠᠭᠠᠨ ᠬᠡᠮᠵᠢᠨ᠎ᠡ ᠃"}
        json_dict_classa_2 = {"class_a":"ᠵᠥᠭᠡᠯᠡᠨ ᠲᠣᠨᠣᠭ ᠬᠠᠳᠠᠭᠠᠯᠠᠵᠤ ᠪᠠᠢ᠌ᠴᠠᠭᠠᠵᠤ ᠪᠠᠢ᠌ᠴᠠᠭᠠᠨ ᠬᠡᠮᠵᠢᠬᠦ ᠃"}
        json_dict_classa_3 = {"class_a":"ᠰᠢᠰᠲ᠋ᠧᠮ ᠦᠨ ᠫᠠᠨᠰᠠ ᠶᠢᠨ ᠬᠡᠷᠡᠭᠯᠡᠵᠦ ᠪᠣᠯᠬᠤ ᠴᠢᠨᠠᠷ ᠢ ᠪᠠᠶᠢᠴᠠᠭᠠᠨ ᠬᠡᠮᠵᠢᠬᠦ ᠃"}
        json_dict_classa_4 = {"class_a":"ᠤᠲᠠᠰᠤᠲᠤ ᠰᠦᠯᠵᠢᠶ᠎ᠡ ᠶᠢ ᠪᠠᠶᠢᠴᠠᠭᠠᠨ ᠬᠡᠮᠵᠢᠬᠦ ᠬᠡᠷᠡᠭᠲᠡᠶ ᠃"}
        json_dict_classa_5 = {"class_a":"ᠷᠠᠳᠢᠣ᠋ ᠶᠢᠨ ᠰᠦᠯᠵᠢᠶ᠎ᠡ ᠶᠢ ᠪᠠᠶᠢᠴᠠᠭᠠᠨ ᠬᠡᠮᠵᠢᠬᠦ ᠃"}
    elif locales_temp == "4":
        json_dict_classa_1 = {"class_a":"རྒྱུད་རིམ་ལྡན་པའི་སྒོ་ནས་ཞིབ་དཔྱད་ཚད་ལེན་"}
        json_dict_classa_2 = {"class_a":"མཉེན་ཆས་གསོག་ཉར་ཞིབ་དཔྱད་ཚད་ལེན་"}
        json_dict_classa_3 = {"class_a":"མ་ལག་གི་སྡེར་མ་བཀོལ་སྤྱོད་རང་བཞིན་གྱི་ཞིབ་དཔྱད་ཚད"}
        json_dict_classa_4 = {"class_a":"སྐུད་ཡོད་དྲ་རྒྱར་ཞིབ་དཔྱད་ཚད་ལེན་བྱ་"}
        json_dict_classa_5 = {"class_a":"སྐུད་མེད་དྲ་རྒྱའི་ཞིབ་དཔྱད་ཚད་ལེན།"}
    else:
        json_dict_classa_1 = {"class_a":"系统更新检测"}
        json_dict_classa_2 = {"class_a":"软件商店检测"}
        json_dict_classa_3 = {"class_a":"系统磁盘可用性检测"}
        json_dict_classa_4 = {"class_a":"有线网络检测"}
        json_dict_classa_5 = {"class_a":"无线网络检测"}

    json_table_classb_1 = []
    json_table_classb_2 = []
    json_table_classb_3 = []
    json_table_classb_4 = []
    json_table_classb_5 = []
    
    try:
        file1 = open(db_dir_path)
        while True:
            text = file1.readline()
            if len(text) == 0:
                break
            text = text.rstrip("\n")
            row = text.split("+++")
            if len(row) < 4:
                continue
            #print("row = ",row)
            #解析每一行，如果其一级标题==等于“网络检测”
            if str(row[1]) == "系统更新检测" or str(row[1]) == "System update detection" or str(row[1]) == "系統更新檢測" or str(row[1]) == "ᠰᠢᠰᠲ᠋ᠧᠮ ᠢ ᠰᠢᠨᠡᠳᠬᠡᠨ ᠪᠠᠶᠢᠴᠠᠭᠠᠨ ᠬᠡᠮᠵᠢᠨ᠎ᠡ ᠃" or str(row[1]) == "རྒྱུད་རིམ་ལྡན་པའི་སྒོ་ནས་ཞིབ་དཔྱད་ཚད་ལེན་":
                #拿到二级标题，解析json_table_classb_1下面所有的字典，判断二级标题是否等于其"Name"值
                temp_class2_equal = 0
                for temp_dict2 in json_table_classb_1:
                    if temp_dict2["Name"] == str(row[2]):
                        temp_class2_equal = 1
                        #2:找到一个等于，如果三级标题不为空，则遍历for temp in json_table_classb_1[i]["class_c"]下面的所有字典，判断
                        #三级标题是否等于temp["Name"],没有的话 则新增，有的话退出
                        if str(row[4]) != "":
                            temp_class3_equal = 0
                            for temp_dict3 in temp_dict2["class_c"]:
                                if row[4] == temp_dict3["Name"]:
                                    temp_class3_equal = 1
                                    break
                            if temp_class3_equal == 0:
                                temp_dict4={}
                                temp_dict4["Name"] = str(row[4])
                                temp_dict4["Describe"] = str(row[5])
                                temp_dict2["class_c"].append(temp_dict4)
                                #print("2------------- json_table_classb_1 = ",json_table_classb_1)
                #1：都不等于，则新建一个临时dict2={"Name"=二级标题，"Descripe"="描述"}，并且判断三级标题是否为空
                #不为空则dict2["class_c"] = [],dict3 = {"Name"=三级标题，"Descripe"="描述"}
                #为空的话dict2["class_c"] = []，插入到json_table_classb_1
                if temp_class2_equal == 0:
                    temp_dict2 = {}
                    temp_dict2["Name"] = str(row[2])
                    temp_dict2["Describe"] = str(row[3])
                    temp_dict2["class_b_id"] = str(row[6])
                    temp_dict2["class_c"] = []
                    temp_dict3_1 = {}
                    if str(row[4]) != "":
                        temp_dict3_1["Name"] = str(row[4])
                        temp_dict3_1["Describe"] = str(row[5])
                    temp_dict2["class_c"].append(temp_dict3_1)
                    json_table_classb_1.append(temp_dict2)
                    #print("1------------- json_table_classb_1 = ",json_table_classb_1)                                    
            elif row[1] == "软件商店检测" or str(row[1]) == "Software Store Detection" or str(row[1]) == "軟體商店檢測" or str(row[1]) == "ᠵᠥᠭᠡᠯᠡᠨ ᠲᠣᠨᠣᠭ ᠬᠠᠳᠠᠭᠠᠯᠠᠵᠤ ᠪᠠᠢ᠌ᠴᠠᠭᠠᠵᠤ ᠪᠠᠢ᠌ᠴᠠᠭᠠᠨ ᠬᠡᠮᠵᠢᠬᠦ ᠃" or str(row[1]) == "མཉེན་ཆས་གསོག་ཉར་ཞིབ་དཔྱད་ཚད་ལེན་":
                 #拿到二级标题，解析json_table_classb_2下面所有的字典，判断二级标题是否等于其"Name"值
                temp_class2_equal = 0
                for temp_dict2 in json_table_classb_2:
                    if temp_dict2["Name"] == str(row[2]):
                        temp_class2_equal = 1
                        #2:找到一个等于，如果三级标题不为空，则遍历for temp in json_table_classb_2[i]["class_c"]下面的所有字典，判断
                        #三级标题是否等于temp["Name"],没有的话 则新增，有的话退出
                        if str(row[4]) != "":
                            temp_class3_equal = 0
                            for temp_dict3 in temp_dict2["class_c"]:
                                if row[4] == temp_dict3["Name"]:
                                    temp_class3_equal = 1
                                    break
                            if temp_class3_equal == 0:
                                temp_dict4={}
                                temp_dict4["Name"] = str(row[4])
                                temp_dict4["Describe"] = str(row[5])
                                temp_dict2["class_c"].append(temp_dict4)
                                #print("2------------- json_table_classb_2 = ",json_table_classb_2)
                #1：都不等于，则新建一个临时dict2={"Name"=二级标题，"Descripe"="描述"}，并且判断三级标题是否为空
                #不为空则dict2["class_c"] = [],dict3 = {"Name"=三级标题，"Descripe"="描述"}
                #为空的话dict2["class_c"] = []，插入到json_table_classb_2
                if temp_class2_equal == 0:
                    temp_dict2 = {}
                    temp_dict2["Name"] = str(row[2])
                    temp_dict2["Describe"] = str(row[3])
                    temp_dict2["class_b_id"] = str(row[6])
                    temp_dict2["class_c"] = []
                    temp_dict3_1 = {}
                    if str(row[4]) != "":
                        temp_dict3_1["Name"] = str(row[4])
                        temp_dict3_1["Describe"] = str(row[5])
                    temp_dict2["class_c"].append(temp_dict3_1)
                    json_table_classb_2.append(temp_dict2)
                    #print("1------------- json_table_classb_2 = ",json_table_classb_2)
                pass
            elif row[1] == "系统磁盘可用性检测" or str(row[1]) == "System disk availability detection" or str(row[1]) == "系統磁碟可用性檢測" or str(row[1]) == "ᠰᠢᠰᠲ᠋ᠧᠮ ᠦᠨ ᠫᠠᠨᠰᠠ ᠶᠢᠨ ᠬᠡᠷᠡᠭᠯᠡᠵᠦ ᠪᠣᠯᠬᠤ ᠴᠢᠨᠠᠷ ᠢ ᠪᠠᠶᠢᠴᠠᠭᠠᠨ ᠬᠡᠮᠵᠢᠬᠦ ᠃" or str(row[1]) == "མ་ལག་གི་སྡེར་མ་བཀོལ་སྤྱོད་རང་བཞིན་གྱི་ཞིབ་དཔྱད་ཚད":
                 #拿到二级标题，解析json_table_classb_2下面所有的字典，判断二级标题是否等于其"Name"值
                temp_class2_equal = 0
                for temp_dict2 in json_table_classb_3:
                    if temp_dict2["Name"] == str(row[2]):
                        temp_class2_equal = 1
                        #2:找到一个等于，如果三级标题不为空，则遍历for temp in json_table_classb_3[i]["class_c"]下面的所有字典，判断
                        #三级标题是否等于temp["Name"],没有的话 则新增，有的话退出
                        if str(row[4]) != "":
                            temp_class3_equal = 0
                            for temp_dict3 in temp_dict2["class_c"]:
                                if row[4] == temp_dict3["Name"]:
                                    temp_class3_equal = 1
                                    break
                            if temp_class3_equal == 0:
                                temp_dict4={}
                                temp_dict4["Name"] = str(row[4])
                                temp_dict4["Describe"] = str(row[5])
                                temp_dict2["class_c"].append(temp_dict4)
                                #print("2------------- json_table_classb_3 = ",json_table_classb_3)
                #1：都不等于，则新建一个临时dict2={"Name"=二级标题，"Descripe"="描述"}，并且判断三级标题是否为空
                #不为空则dict2["class_c"] = [],dict3 = {"Name"=三级标题，"Descripe"="描述"}
                #为空的话dict2["class_c"] = []，插入到json_table_classb_2
                if temp_class2_equal == 0:
                    temp_dict2 = {}
                    temp_dict2["Name"] = str(row[2])
                    temp_dict2["Describe"] = str(row[3])
                    temp_dict2["class_b_id"] = str(row[6])
                    temp_dict2["class_c"] = []
                    temp_dict3_1 = {}
                    if str(row[4]) != "":
                        temp_dict3_1["Name"] = str(row[4])
                        temp_dict3_1["Describe"] = str(row[5])
                    temp_dict2["class_c"].append(temp_dict3_1)
                    json_table_classb_3.append(temp_dict2)
                    #print("1------------- json_table_classb_3 = ",json_table_classb_3)
                pass
            elif row[1] == "有线网络检测" or str(row[1]) == "Wired network detection" or str(row[1]) == "有線網路檢測" or str(row[1]) == "ᠤᠲᠠᠰᠤᠲᠤ ᠰᠦᠯᠵᠢᠶ᠎ᠡ ᠶᠢ ᠪᠠᠶᠢᠴᠠᠭᠠᠨ ᠬᠡᠮᠵᠢᠬᠦ ᠬᠡᠷᠡᠭᠲᠡᠶ ᠃" or str(row[1]) == "སྐུད་ཡོད་དྲ་རྒྱར་ཞིབ་དཔྱད་ཚད་ལེན་བྱ་":
                 #拿到二级标题，解析json_table_classb_4下面所有的字典，判断二级标题是否等于其"Name"值
                temp_class2_equal = 0
                for temp_dict2 in json_table_classb_4:
                    if temp_dict2["Name"] == str(row[2]):
                        temp_class2_equal = 1
                        #2:找到一个等于，如果三级标题不为空，则遍历for temp in json_table_classb_4[i]["class_c"]下面的所有字典，判断
                        #三级标题是否等于temp["Name"],没有的话 则新增，有的话退出
                        if str(row[4]) != "":
                            temp_class3_equal = 0
                            for temp_dict3 in temp_dict2["class_c"]:
                                if row[4] == temp_dict3["Name"]:
                                    temp_class3_equal = 1
                                    break
                            if temp_class3_equal == 0:
                                temp_dict4={}
                                temp_dict4["Name"] = str(row[4])
                                temp_dict4["Describe"] = str(row[5])
                                temp_dict2["class_c"].append(temp_dict4)
                                #print("2------------- json_table_classb_4 = ",json_table_classb_4)
                #1：都不等于，则新建一个临时dict2={"Name"=二级标题，"Descripe"="描述"}，并且判断三级标题是否为空
                #不为空则dict2["class_c"] = [],dict3 = {"Name"=三级标题，"Descripe"="描述"}
                #为空的话dict2["class_c"] = []，插入到json_table_classb_2
                if temp_class2_equal == 0:
                    temp_dict2 = {}
                    temp_dict2["Name"] = str(row[2])
                    temp_dict2["Describe"] = str(row[3])
                    temp_dict2["class_b_id"] = str(row[6])
                    temp_dict2["class_c"] = []
                    temp_dict3_1 = {}
                    if str(row[4]) != "":
                        temp_dict3_1["Name"] = str(row[4])
                        temp_dict3_1["Describe"] = str(row[5])
                    temp_dict2["class_c"].append(temp_dict3_1)
                    json_table_classb_4.append(temp_dict2)
                    #print("1------------- json_table_classb_4 = ",json_table_classb_4)
                pass
            elif row[1] == "无线网络检测" or str(row[1]) == "Wireless network detection" or str(row[1]) == "無線網路檢測" or str(row[1]) == "ᠷᠠᠳᠢᠣ᠋ ᠶᠢᠨ ᠰᠦᠯᠵᠢᠶ᠎ᠡ ᠶᠢ ᠪᠠᠶᠢᠴᠠᠭᠠᠨ ᠬᠡᠮᠵᠢᠬᠦ ᠃" or str(row[1]) == "སྐུད་མེད་དྲ་རྒྱའི་ཞིབ་དཔྱད་ཚད་ལེན།":
                 #拿到二级标题，解析json_table_classb_5下面所有的字典，判断二级标题是否等于其"Name"值
                temp_class2_equal = 0
                for temp_dict2 in json_table_classb_5:
                    if temp_dict2["Name"] == str(row[2]):
                        temp_class2_equal = 1
                        #2:找到一个等于，如果三级标题不为空，则遍历for temp in json_table_classb_5[i]["class_c"]下面的所有字典，判断
                        #三级标题是否等于temp["Name"],没有的话 则新增，有的话退出
                        if str(row[4]) != "":
                            temp_class3_equal = 0
                            for temp_dict3 in temp_dict2["class_c"]:
                                if row[4] == temp_dict3["Name"]:
                                    temp_class3_equal = 1
                                    break
                            if temp_class3_equal == 0:
                                temp_dict4={}
                                temp_dict4["Name"] = str(row[4])
                                temp_dict4["Describe"] = str(row[5])
                                temp_dict2["class_c"].append(temp_dict4)
                                #print("2------------- json_table_classb_5 = ",json_table_classb_5)
                #1：都不等于，则新建一个临时dict2={"Name"=二级标题，"Descripe"="描述"}，并且判断三级标题是否为空
                #不为空则dict2["class_c"] = [],dict3 = {"Name"=三级标题，"Descripe"="描述"}
                #为空的话dict2["class_c"] = []，插入到json_table_classb_5
                if temp_class2_equal == 0:
                    temp_dict2 = {}
                    temp_dict2["Name"] = str(row[2])
                    temp_dict2["Describe"] = str(row[3])
                    temp_dict2["class_b_id"] = str(row[6])
                    temp_dict2["class_c"] = []
                    temp_dict3_1 = {}
                    if str(row[4]) != "":
                        temp_dict3_1["Name"] = str(row[4])
                        temp_dict3_1["Describe"] = str(row[5])
                    temp_dict2["class_c"].append(temp_dict3_1)
                    json_table_classb_5.append(temp_dict2)
                    #print("1------------- json_table_classb_5 = ",json_table_classb_5)
                pass
    except Exception as e:
        if os.path.exists(db_dir_path):
            os.remove(db_dir_path)
        print("e = ",e)
        return -1
    json_dict_classa_1["class_b"] = json_table_classb_1
    json_dict_classa_2["class_b"] = json_table_classb_2
    json_dict_classa_3["class_b"] = json_table_classb_3
    json_dict_classa_4["class_b"] = json_table_classb_4
    json_dict_classa_5["class_b"] = json_table_classb_5
    #最后
    json_table.append(json_dict_classa_1)
    json_table.append(json_dict_classa_2)
    json_table.append(json_dict_classa_3)
    json_table.append(json_dict_classa_4)
    json_table.append(json_dict_classa_5)

    print_deg("55------------- json_table = "+str(json_table))
    json_table_str = json.dumps(json_table)

    #开始往临时文件中写数据
    report_result_name = "/tmp/kydoctor"
    result_fd = open(report_result_name,"w")
    result_fd.write(json_table_str)
    result_fd.close()
    file1.close()
    if os.path.exists(db_dir_path):
        os.remove(db_dir_path)
    return 0
if __name__ == "__main__":
    #ret = get_itemlistfromsql() 
    #ret = get_itemlistfromtxt()
    print("---------------sys.argv[1] = ",sys.argv[1],sys.argv[2])
    if sys.argv[2] == "0":
        print("-------------------- i am in zhuxain !")
        ret = get_newdesign_itemlistfromtxt(sys.argv[1])     #主线
    elif sys.argv[2] == "1":
        print("-------------------- i am in gonghang!")
        ret = get_newdesign_itemlistfromtxt_gh(sys.argv[1])  #工行
    if ret == -1:
        exit(-1)
    else:
        exit(0)


