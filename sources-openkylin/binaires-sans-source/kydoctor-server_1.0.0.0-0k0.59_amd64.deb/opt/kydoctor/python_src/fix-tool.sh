#!/bin/bash

APPNAME=$(basename "$0" | sed "s/\.sh$//")

APT_CONFIG="/tmp/apt-fix.conf"
APT_PRIORITY_CONFIG="/tmp/apt-priority.pref"

APT_FLAGS="-c $APT_CONFIG"
DPKG_UPDATES_DIR="/var/lib/dpkg/updates"

DPKG_SCRIPT_DIR="/var/lib/dpkg/info"
TMP_SCRIPT_DIR="/var/lib/exception-scripts"
REPACK_DEB_DIR="/var/lib/repack-deb"

CONFIG_FILE="/usr/share/kylin-update-desktop-config/config/kylin-update-desktop-system.json"
REMOVE_PKG_LIMIT=5

TRUE=true
FALSE=false

command_exists() {
	command -v "$@" >/dev/null 2>&1

}

KYLINOS_BASE=$TRUE
OS_INFO=$(uname -a)
if ! [[ "$OS_INFO" == *"KYLINOS"* ]]; then
    KYLINOS_BASE=$FALSE
fi

# -----------------------------------------------------------------------------
# Log functions
# -----------------------------------------------------------------------------

fn_log_info()  { echo "$APPNAME: $1"; }
fn_log_warn()  { echo "$APPNAME: [WARNING] $1" 1>&2; }
fn_log_error() { echo "$APPNAME: [ERROR] $1" 1>&2; }

# -----------------------------------------------------------------------------
# 检查系统软件包环境
# -----------------------------------------------------------------------------
DPKG_DIRTY=$FALSE
if [ -d "$DPKG_UPDATES_DIR" ]; then
    # 递归目录下面的所有文件
    for f in $DPKG_UPDATES_DIR/*; do
        if [[ -f "$f" ]]; then
            if [[ $(basename "$f") =~ ^[0-9]+$ ]]; then
                DPKG_DIRTY=$TRUE
            fi
        fi
    done
fi

# 字符数组 保存所有异常软件包列表
iF_PACKAGES=($(dpkg -l | grep '^iF' | awk '{print $2}' | tr '\n' ' '))
iU_PACKAGES=($(dpkg -l | grep '^iU' | awk '{print $2}' | tr '\n' ' '))
iHR_PACKAGES=($(dpkg -l | grep '^iHR' | awk '{print $2}' | tr '\n' ' '))

fn_print_broken_pkgs() {

    if [ -n "$iF_PACKAGES" ] || [ -n "$iHR_PACKAGES" ] || [ -n "$iU_PACKAGES" ] || [ "$DPKG_DIRTY" = "$TRUE" ]; then
        echo "系统软件包环境异常，需要进行修复，异常软件包如下："
        echo ""
    else
        echo "系统软件包环境正常，不需要进行修复。"
        exit 0
    fi

    if [ "$DPKG_DIRTY" = "$TRUE" ]; then
        echo "dpkg状态异常"
    fi

    if [ -n "$iF_PACKAGES" ]; then
        echo "iF状态软件包：${iF_PACKAGES[@]}"
    fi

    if [ -n "$iU_PACKAGES" ]; then
        echo "iU状态软件包：${iU_PACKAGES[@]}"
    fi

    if [ -n "$iHR_PACKAGES" ]; then
        echo "iHR状态软件包：${iHR_PACKAGES[@]}"
    fi
    echo ""
    echo "修复系统软件包环境，请执行  fix-tool.sh -r"
    echo ""
}

# -----------------------------------------------------------------------------
# 设置apt修复时使用的配置，包括调整优先级设置到允许降级、禁止安装推荐和建议软件包、默认保留旧配置、允许降级、不更新非系统标准源
# -----------------------------------------------------------------------------
fn_make_tmp_config() {
    # 创建调整源优先级配置 统一允许降级
	cat > $APT_PRIORITY_CONFIG <<EOF
# 将调整所有的源优先级 允许使用降级
# 参考文档https://manpages.debian.org/bookworm/apt/apt_preferences.5.en.html
Package: *
Pin: origin "*"
Pin-Priority: 1001
EOF

    # 创建apt配置
	cat > $APT_CONFIG <<EOF
APT::Install-Recommends "false";
APT::Install-Suggests "false";
Dir::Etc::sourceparts "";
DPkg::Post-Invoke "";
APT::Get::allow-downgrades "true";
APT::Get::allow-change-held-packages "true";

Dpkg::Options {
	      "--force-confold";
	      "--force-confdef";
}
Dir::Etc::preferences "$APT_PRIORITY_CONFIG";
EOF
}

# -----------------------------------------------------------------------------
# 检查修复是否删除重要软件包，判断逻辑，首先检查config包中install_list 移除软件包是否在此列表在直接退出
# -----------------------------------------------------------------------------
check_remove_essential() {
    # 获取修复时被移除的包列表
    REMOVE_PACKAGES=($(apt install -f $APT_FLAGS -y --simulate 2>&1 | grep '^Remv' | awk '{print $2}' | tr '\n' ' '))
    if [ -n "$REMOVE_PACKAGES" ]; then
        echo "$FMT_RED下列软件包将被【卸载】: ${REMOVE_PACKAGES[@]} $FMT_RESET"

        # 强制同步一次config包
        if [ "$KYLINOS_BASE" = "$TRUE" ]; then
            apt download kylin-update-desktop-config -y $APT_FLAGS
            if [ $? -eq 0 ]; then
                dpkg -i ./kylin-update-desktop-config*.deb
                rm kylin-update-desktop-config*.deb
            fi
        fi
        
        if [ -f "$CONFIG_FILE" ]; then
            install_list=$(jq -r '.install_list' "$CONFIG_FILE")

            # 强制移除存在异常的软件包脚本 来修复系统环境
            for pkg_name in "${REMOVE_PACKAGES[@]}"; do
                if [[ "$install_list" == *"$pkg_name"* ]]; then
                    echo "警告：系统必须的软件包($pkg_name)被移除"
                    exit 100
                fi
            done
        else
            remove_size=${#REMOVE_PACKAGES[@]}
            if [ "$remove_size" -gt $REMOVE_PKG_LIMIT ]; then
                echo "警告：删除软件包数量超过5个 不允许删除，若判断删除没有影响，则添加参数 --force 强制执行"
                exit 100
            fi
        fi
        
        # 命令不存在时尝试进行安装
        if ! command_exists dpkg-repack; then
            apt download dpkg-repack -y $APT_FLAGS
            if [ $? -eq 0 ]; then
                dpkg -i ./dpkg-repack*.deb
                rm dpkg-repack*.deb
            fi
        fi

        if command_exists dpkg-repack; then
            if [ ! -d "$REPACK_DEB_DIR" ]; then
                # 不存在时创建
                mkdir -p "$REPACK_DEB_DIR"
            fi
            remove_list=${REMOVE_PACKAGES[@]}
            #将软件包进行打包保存 
            dpkg-repack $remove_list
            rm *.deb "$REPACK_DEB_DIR"
        fi
    fi
}

# -----------------------------------------------------------------------------
# 执行修复系统环境，包括dpkg状态异常修复、iF、iHR、iU软件包状态修复
# -----------------------------------------------------------------------------
fn_fix_broken_pkgs() {
    APPEND_FLAGS=$1
    
    # 检查是否仅模拟计算
    SIMULATE_MODE=$FALSE
    if [[ "$APPEND_FLAGS" == *"simulate"* ]]; then
        SIMULATE_MODE="$TRUE"
    fi

    FORCE_MODE=$FALSE
    if [[ "$APPEND_FLAGS" == *"force"* ]]; then
        FORCE_MODE="$TRUE"
    fi

    if [ "$DPKG_DIRTY" = "$TRUE" ]; then
        dpkg --configure -a
    fi
    
    result=""
    # 存在任何错误 都先执行 apt install -f 来尝试修复
    if [ -n "$iF_PACKAGES" ] || [ -n "$iHR_PACKAGES" ] || [ -n "$iU_PACKAGES" ]; then
        # 创建一些 apt 配置
        fn_make_tmp_config

        apt update $APT_FLAGS -y || true

        if [ "$FORCE_MODE" = "$FALSE" ]; then
            check_remove_essential
        fi

        if [ -n "$iF_PACKAGES" ] && [ -z "$iHR_PACKAGES" ] && [ -z "$iU_PACKAGES" ]; then
            # 仅有iF状态的软件包
            iF_pkgs=${iF_PACKAGES[@]}
            apt install -f $APT_FLAGS $APPEND_FLAGS $iF_pkgs
        elif [[ -z $iF_PACKAGES && (-n $iHR_PACKAGES || -n $iU_PACKAGES) ]]; then
            # 没有iF状态的修复办法
            apt install -f $APT_FLAGS $APPEND_FLAGS
        else
            # 存在iF 以及其他的异常 先修复其他 再修复iF
            apt install -f $APT_FLAGS $APPEND_FLAGS
            iF_PACKAGES=($(dpkg -l | grep '^iF' | awk '{print $2}' | tr '\n' ' '))
            if [ -n "$iF_PACKAGES" ]; then
                iF_pkgs=${iF_PACKAGES[@]}
                apt install -f $APT_FLAGS $APPEND_FLAGS $iF_pkgs
            fi
        fi
    fi

    # 重新扫描iF状态软件包
    iF_PACKAGES=($(dpkg -l | grep '^iF' | awk '{print $2}' | tr '\n' ' '))
    # iF 状态修复 安装前后脚本报错，强制将安装前后脚本移除
    if [ -n "$iF_PACKAGES" ] || [ "$SIMULATE_MODE" = "$TRUE" ]; then
        # 检查目录是否存在
        if [ ! -d "$TMP_SCRIPT_DIR" ]; then
            # 不存在时创建
            mkdir -p "$TMP_SCRIPT_DIR"
        fi

        # 强制移除存在异常的软件包脚本 来修复系统环境
        for pkg_name in "${iF_PACKAGES[@]}"; do
            post_script=$DPKG_SCRIPT_DIR/$pkg_name.postinst
            preinst_script=$DPKG_SCRIPT_DIR/$pkg_name.preinst

            if [ -f "$post_script" ]; then
                echo "异常脚本:$post_script 强制移除到 $TMP_SCRIPT_DIR"
                if [ "$SIMULATE_MODE" = "$FALSE" ]; then
                    mv $post_script $TMP_SCRIPT_DIR
                fi
            fi

            if [ -f "$preinst_script" ]; then
                echo "异常脚本:$preinst_script 强制移除到 $TMP_SCRIPT_DIR"
                if [ "$SIMULATE_MODE" = "$FALSE" ]; then
                    mv $preinst_script $TMP_SCRIPT_DIR
                fi
            fi
        done

        if [ "$SIMULATE_MODE" = "$FALSE" ]; then
            # 再次修复 重置软件包的状态
            apt install -f $APT_FLAGS $APPEND_FLAGS
        fi
    fi

    if [ "$SIMULATE_MODE" = "$TRUE" ]; then
        echo "模拟模式仅显示修复手段，不进行实际的修复"
    fi
}

# -----------------------------------------------------------------------------
# 配置显示不同的显色
# -----------------------------------------------------------------------------


if [ -t 1 ]; then
  is_tty() {
    true
  }
else
  is_tty() {
    false
  }
fi

supports_truecolor() {
  case "$COLORTERM" in
  truecolor|24bit) return 0 ;;
  esac

  case "$TERM" in
  iterm           |\
  tmux-truecolor  |\
  linux-truecolor |\
  xterm-truecolor |\
  screen-truecolor) return 0 ;;
  esac

  return 1
}

setup_color() {
  if ! is_tty; then
    FMT_RAINBOW=""
    FMT_RED=""
    FMT_GREEN=""
    FMT_YELLOW=""
    FMT_BLUE=""
    FMT_BOLD=""
    FMT_RESET=""
    return
  fi

  if supports_truecolor; then
    FMT_RAINBOW="
      $(printf '\033[38;2;255;0;0m')
      $(printf '\033[38;2;255;97;0m')
      $(printf '\033[38;2;247;255;0m')
      $(printf '\033[38;2;0;255;30m')
      $(printf '\033[38;2;77;0;255m')
      $(printf '\033[38;2;168;0;255m')
      $(printf '\033[38;2;245;0;172m')
    "
  else
    FMT_RAINBOW="
      $(printf '\033[38;5;196m')
      $(printf '\033[38;5;202m')
      $(printf '\033[38;5;226m')
      $(printf '\033[38;5;082m')
      $(printf '\033[38;5;021m')
      $(printf '\033[38;5;093m')
      $(printf '\033[38;5;163m')
    "
  fi

  FMT_RED=$(printf '\033[31m')
  FMT_GREEN=$(printf '\033[32m')
  FMT_YELLOW=$(printf '\033[33m')
  FMT_BLUE=$(printf '\033[34m')
  FMT_BOLD=$(printf '\033[1m')
  FMT_RESET=$(printf '\033[0m')
}

fn_display_usage() {
	echo "Usage: $(basename "$0") [OPTION]..."
	echo ""
	echo "Options"
    echo ""
	echo " -c, --check            仅检查系统环境并显示异常软件包。"
	echo " -r, --run              运行修复系统环境"
    echo ""
	echo " -y                     自动执行不需要确认。"
	echo " -s, --simulate         模拟执行，不进行实际修复操作。"
	echo " -f, --force            强制进行修复，忽略任何警告。"
	echo ""
	echo "更多帮助信息, 请查看README文件:"
	echo ""
	echo "https://gitee.com/newwangsong/fix-tool/blob/master/README.md"
}

main() {
    APPEND_FLAGS=""
    RUN_FIX=$FALSE
    setup_color

    # 如果没有参数，则显示帮助信息
    if [ $# -eq 0 ]; then
        fn_print_broken_pkgs
        fn_display_usage
        exit 0
    fi

    while :; do
        case $1 in
            -h|-\?|--help)
                fn_display_usage
                exit
                ;;
            -c|--check)
                shift
                fn_print_broken_pkgs
                exit
                ;;
            -y)
                shift
                APPEND_FLAGS="$APPEND_FLAGS -y"
                ;;
            -r|--run)
                shift
                ;;
            -s|--simulate)
                shift
                APPEND_FLAGS="$APPEND_FLAGS --simulate"
                ;;
            *)
                break
        esac
        shift
    done

    fn_print_broken_pkgs
    if [ -n "$iF_PACKAGES" ] || [ -n "$iHR_PACKAGES" ] || [ -n "$iU_PACKAGES" ] || [ "$DPKG_DIRTY" = "$TRUE" ]; then
        if [ "$(id -u)" != "0" ]; then
            echo "错误: 执行修复程序需要root权限"
            exit 1
        fi
        fn_fix_broken_pkgs $APPEND_FLAGS
    fi
}

main "$@"