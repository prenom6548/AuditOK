"""Copyright (c) KylinSoft  Co., Ltd. [2024].All rights reserved.
/*[kydoctor] licensed under the [Your LICENSE].
***************Your LICENSE Messages***********************
Author: [WangShuai]
Create: [2024]
"""

#!/bin/env python3
# -*- coding: utf-8 -*-

### https://apt-team.pages.debian.net/python-apt/library/index.html

import os
import apt
import apt_pkg
import sys  
import logging
from common_variables import PRINT_DEBUG

def print_deg(print_str):
    if PRINT_DEBUG == 1:
        print(print_str)

"""
返回值：
0：成功或不需要升级
1：升级的包不存在或指定的包版本不存在
2：要升级的包依赖其他包，或升级过程中需要删除/降级包，此操作有风险，建议手动升级
3：升级失败
"""
def upgrade_specific_version(package_name, fix_version,op):
    # 配置日志记录器
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG) # 设置日志等级为 DEBUG

    # 创建文件处理程序并添加到日志记录器

    file_handler = logging.FileHandler('/var/log/kydoctor-log.txt')
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    #维护一个列表，判断要升级的package_name是否在这个列表中，不在的话，跳过，不升级
    can_update_packages=[
    "accountsservice",\
    "bluez","dnsmasq","biometric-driver-seetaface-detect",\
    "cdcontrol","crossover","convmv",\
    "kylin-update-notify","ukui-control-center","kylin-burner","kylin-calculator","kylin-log-viewer",\
    "kylin-video","kylin-music","kylin-photo-viewer","kylin-software-center","kylin-user-guide",\
    "kylin-virtual-keyboard","kylin-software-properties","kylin-camera","kylin-device-daemon","kylin-nm",\
    "kylin-screenshot","kmre","kylin-os-installer","kylin-update-manager","kylin-system-updater",\
    "kylin-update-desktop-config","kylin-installer","kylin-activation","kylin-background-upgrade","kylincameralibs",\
    "kylincloud-remoteappclient","ubuntukylin-default-settings","kylin-mdm-service","kylin-boot-guide","kylin-kmre-window",\
    "kylin-flash-plugin","kylin-kwre-wecom","kylin-network-access-damon","kylin-scanner","kylin-ipmsg",\
    "engrampa",\
    "network-manager","nsmp",\
    "rtl8852be_wifi","remmina",\
    "gparted","genisoimage","gedit",\
    "ukui-bluetooth","ukui-system-monitor","udisks2","ukui-media","ubuntukylin-theme","ubuntukylin-default-settings","ukui-search",\
    "optilauncher",\
    "pulseaudio","pksav","p7zip","pluma","phytium-scto",\
    "qaxsafe",\
    "fcitx","fcitx-frontend-qt5",\
    "youker-assistant","yhkylin-backup-tools",\
    "zhaoxin-linux-graphics-driver-dri",\
    "wpasupplicant",\
    "shim","shim-signed","sogouimebs","sidebar",\
    "time-shutdown",\
    "libkylin-activation","libappindicator","libpam_modules",\
    "vino"
    ]
    if package_name not in can_update_packages:
        logger.info(str(package_name)+"not in can_update_packages,retrun 2")
        return 2
    try:
        # 初始化APT软件包管理器  
        apt_pkg.init()

        # 获取APT缓存
        cache = apt.Cache()

        # 更新APT缓存  
        cache.update()

        # 获取指定名称的软件包  
        package = cache[package_name]
        print("package = ",package)
        # 检查软件包是否存在  
        if not package:
            print(f"Package '{package_name}' not found.")
            return 1
        print_deg ("have package")

        # 获取当前包版本
        try:
            current_version = package.installed.version
            print_deg ("cur verison "+str(current_version))
        except Exception as e:
            current_version = "0"

        # 获取软件包的版本列表  
        versions = package.versions
        print_deg("versions = "+str(versions))

        # 检查指定版本是否存在
        fix_version_new = "0"
        if op == "=":  
            if fix_version not in versions:
                print(f"Version '{version}' of package '{package_name}' not found.")
                return 1
        elif op == ">=" or op == ">":
            for f_v in versions:
                print("f_v=",f_v,type(str(f_v)),str(f_v).split("=")[1])
                if (apt_pkg.version_compare(str(f_v).split("=")[1],fix_version_new) > 0):
                    fix_version_new=str(f_v).split("=")[1]
                    #break
        print_deg ("cache bested version: "+str(fix_version_new))
        if(apt_pkg.version_compare(fix_version_new, fix_version) > 0 and op == ">"):
            fix_version = fix_version_new
            print_deg ("cache have version: "+str(fix_version))
        elif (apt_pkg.version_compare(fix_version_new, fix_version) >= 0 and op == ">="):
            fix_version = fix_version_new
            print_deg ("cache have version: "+str(fix_version))
        else:
            print_deg ("cache have no version")
            logger.info("cache have no version")
            return 1


        if (apt_pkg.version_compare(current_version, fix_version) < 0):
            print_deg ("need update")
        else:
            print_deg ("no need update")
            return 0

        #核对包是否有依赖
        try:
            update_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 apt-get --print-uris install " + package_name  + "=" + str(fix_version) + " 2>&1"
            print_deg("update_cmd = "+str(update_cmd))
            logger.info("update_cmd = "+str(update_cmd))
            ces = os.popen(update_cmd)
            ces_str = ces.read()

            if "Depends" in ces_str or "depends" in ces_str:
                print_deg("depends other package ,don't update")
                return 2
            print("no depends--------")
        except:
            pass
        #判断是否有remove 或downgraded
        try:
            update_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 apt-get install " + package_name  + "=" + str(fix_version) + " --simulate 2>&1"
            print_deg("update_cmd = "+str(update_cmd))
            logger.info("update_cmd = "+str(update_cmd))
            ces = os.popen(update_cmd)
            ces_str = ces.read()

            print_deg("ces_str = "+str(ces_str))

            if "E:" in ces_str and "Version" in ces_str:
                print("--simulate package error")
                return 2
            else:
                ces_lines = ces_str.split("\n")
                for ces_line in ces_lines:
                    print_deg("ces_line = "+str(ces_line))
                    if "upgraded" in ces_line and "installed" in ces_line and "downgraded" in ces_line and "remove" in ces_line:
                        #print("find ces_line = ",ces_line)
                        downgraded_num_str = ces_line.split(",")[2].strip()
                        #print("downgraded_num_str =",downgraded_num_str)
                        downgraded_num = downgraded_num_str.split(" ")[0]
                        print_deg("downgraded_num = "+str(downgraded_num))
                        if int(downgraded_num) > 0:
                            print("need downgraded other package ,return")
                            logger.info("need downgraded other package ,return")
                            return 2
                        break
                    elif "upgraded" in ces_line and "installed" in ces_line and "remove" in ces_line:
                        #print("find ces_line = ",ces_line)
                        remove_num_str = ces_line.split(",")[2].strip()
                        #print("remove_num_str =",remove_num_str)
                        remove_num = remove_num_str.split(" ")[0]
                        print_deg("remove_num = "+str(remove_num))
                        if int(remove_num) > 0:
                            print("need remove other package ,return")
                            logger.info("need remove other package ,return")
                            return 2
                        break
        except:
            pass
        # 设置软件包的安装版本
        try:
            candidate = package.versions.get(fix_version)
            package.candidate = candidate  #package的属性，此属性是可写的，允许你设置包的候选版本
        except Exception as e:
            print("package.candidate set,e = ",e)

        #package.mark_install(fix_version)
        package.mark_install()  #标记要安装的程序包
        logger.info("执行升级操作....")
        logger.info("包：" + package_name + ",从版本号 " + current_version + " ,升级到版本号 "+ fix_version)
        # 执行升级操作
        try:
            #将标记的更改应用于缓存
            cache.commit(fetch_progress=apt.progress.base.AcquireProgress(),  
                        install_progress=apt.progress.base.InstallProgress())
        except apt.transaction.Error as e:
            print(f"Error upgrading package '{package_name}': {str(e)}")
            logger.warning("升级异常，" + e)
            return 3
        #else:
        #    print_deg ("update package success");
        #    return 0
        deb_cmd = "LANG=en_US.utf8 LANGUAGE=en_US.utf8 dpkg -l | grep  " + package_name + " 2>&1"
        debs = os.popen(deb_cmd)
        debs_str = debs.read()

        if fix_version in debs_str:
            print_deg("update package success")
            logger.info("执行升级操作成功....")
            return 0
        else:
            print_deg("update package failure")
            logger.info("执行升级操作失败....")
            return 3

    except Exception as e:
        print("i am in upgrade_specific_version,e = ",e)
        return 3
    return 0
if __name__ == "__main__":
    print (sys.argv[1])
    package_name=""
    version=""
    inputstrs=sys.argv[1]
    parmstrs= inputstrs.split("###")
    for parmstr in parmstrs:
        if ">=" in parmstr:
            package_name=parmstr.split("(>=")[0]
            num_str = parmstr.split("(>=")[1]
            version=num_str[:-1]
            print("package:",package_name,"version:",version)
            ret = upgrade_specific_version(package_name, version,">=")
            if ret != 0:
                exit(ret)
            pass
        elif ">" in parmstr:
            package_name=parmstr.split("(>")[0]
            num_str = parmstr.split("(>")[1]
            version=num_str[:-1]
            print("package:",package_name,"version:",version)
            ret = upgrade_specific_version(package_name, version,">")
            if ret != 0:
                exit(ret)
        elif "=" in parmstr:
            package_name=parmstr.split("(=")[0]
            num_str = parmstr.split("(=")[1]
            version=num_str[:-1]
            print("package:",package_name,"version:",version)
            ret = upgrade_specific_version(package_name, version,"=")
            if ret != 0:
                exit(ret)
            pass
    exit(0)
    