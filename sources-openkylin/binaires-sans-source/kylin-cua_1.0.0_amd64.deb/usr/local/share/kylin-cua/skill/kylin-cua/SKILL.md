---
name: kylin-cua
description: 使用 Kylin-CUA 通过屏幕截图、鼠标和键盘操作用户当前可见的电脑界面。当用户要求控制真实 GUI、桌面应用、浏览器页面、Web 应用、系统窗口、文件选择器、弹窗或任何可见界面时触发，例如打开、点击、填写、发送、上传、下载、复制粘贴、登录、搜索、预定、加入、切换窗口、处理弹窗，或在某个应用中完成任务。除非用户明确要求使用终端、Playwright、HTTP 调用或特定应用 API，否则可见界面操作应优先使用此 skill。
---

# Kylin-CUA

Kylin-CUA 是一个前台运行的 GUI 智能体，会读取屏幕并使用鼠标、键盘完成可见界面操作。把它作为真实界面操作的执行路径，不要把它当作规划工具。

## 执行约定

- 将用户的原始任务请求作为唯一的位置参数直接传给 Kylin-CUA。
- 原样保留姓名、消息内容、文件路径、URL、日期、时间、非敏感表单字段中的密码，以及中文标点。
- 启动 Kylin-CUA 前，不要把用户请求改写成计划，也不要拆成分步指令。
- 除非用户明确指定，否则不要用终端命令、Playwright、浏览器自动化、HTTP 调用、MCP document tools 或无关的应用专用工具替代可见界面操作。
- 在前台运行进程，并等待它完成、中断，或进入需要用户接手的状态。
- 使用 600 秒超时。

## 启动

严格使用以下命令形态：

```bash
python3 ~/.local/share/kylin-cua/run/kylin-cua.py "用户的任务请求"
```

如果系统 Python 环境缺少运行依赖，使用以下命令安装：

```bash
python3 -m pip install --break-system-packages \
  "pydantic>=2.0.0" \
  "python-dotenv>=1.0.0" \
  "openai>=1.0.0" \
  "langchain-core>=1.3.2,<2.0.0" \
  "langchain-openai>=0.1.0" \
  "pyautogui>=0.9.54" \
  "pyperclip>=1.9.0" \
  "pynput>=1.7.6" \
  "Pillow>=10.0.0" \
  "rapidfuzz>=3.0.0" \
  "PySide6>=6.6.0" \
  "oss2>=2.17.0" \
  "ddgs>=6.1.0"
```

## 启动前检查

启动前，根据当前上下文或环境确认：

- 任务确实需要操作可见桌面、浏览器或应用界面。
- GUI 会话可用。Linux 环境优先使用 X11，并确认已设置 `DISPLAY`。
- 屏幕未锁定，目标应用、网站或文件选择器可以访问。
- 请求不要求智能体独立输入密码、2FA code、付款信息、private key 或其他敏感凭据。

如果任务是代码编辑、仓库检查、测试、依赖安装、纯 shell 文件操作、问答、翻译、总结、文案撰写，或用户明确要求使用 API/CLI，不要使用 Kylin-CUA。

## 安全门槛

遇到以下情况时，先暂停并询问用户，再让 Kylin-CUA 继续：

- 认证流程需要私人凭据、2FA code 或扫码。
- 涉及付款、购买、转账或付费订阅。
- 发送消息、邮件、文件或公开内容，但用户尚未给出明确收件人和确切内容。
- 删除文件、修改账号或安全设置、发布内容，或执行其他破坏性、外部可见的操作。
- 权限弹窗会授予较大的设备、账号或数据访问权限。

需要用户参与时，让用户亲自完成敏感步骤；只有在用户确认后再继续。

## 状态上报

Kylin-CUA 会把实时状态写入：

```text
~/.hermes/sessions/step_record.json
```

预期状态结构：

```json
{
  "hermes_signal": {
    "type": "running|completed|interrupted",
    "message": "...",
    "reason": "...",
    "updated_at": "..."
  },
  "中断信号": null,
  "任务总结": null
}
```

完成信号：

- stdout 包含 `KYLIN_CUA_HERMES_STATUS=completed`。
- `hermes_signal.type` 为 `completed`。
- `任务总结` 包含最终总结。

中断信号：

- stdout 包含 `KYLIN_CUA_HERMES_STATUS=interrupted reason=<reason>`。
- `hermes_signal.type` 为 `interrupted`。
- `中断信号` 包含中断原因和已完成步骤数。

根据 stdout 和 `~/.hermes/sessions/step_record.json` 向用户报告最终结果。

## 已知注意事项

- 在此环境中，通过终端后台打开文档、PDF、表格或桌面应用可能失败。需要打开并操作可见应用时，使用 Kylin-CUA。
- 如果终端方式已经因后台运行或 GUI display 问题失败，改用 Kylin-CUA 处理可见界面任务。
- 文件选择器和中文桌面路径属于常规 GUI 任务；传入任务参数时保持原始路径文本不变。
