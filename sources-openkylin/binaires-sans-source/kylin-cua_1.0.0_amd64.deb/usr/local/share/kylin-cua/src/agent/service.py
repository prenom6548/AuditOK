from __future__ import annotations
import asyncio
import base64
import io
import json
import logging
import os
import platform
import tempfile
import time
from pathlib import Path
import re
from datetime import datetime
from typing import Any, Callable, Optional, Type, TypeVar
from collections import OrderedDict, deque

from dotenv import load_dotenv
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_openai import ChatOpenAI, AzureChatOpenAI
try:
    from langchain_anthropic import ChatAnthropic
except ImportError:
    ChatAnthropic = None
try:
    from langchain_google_genai import ChatGoogleGenerativeAI
except ImportError:
    ChatGoogleGenerativeAI = None
try:
    from langchain_ollama import ChatOllama
except ImportError:
    ChatOllama = None
from langchain_core.messages import BaseMessage
from openai import RateLimitError
from pydantic import BaseModel, ValidationError
from PIL import Image

from src.agent.message_manager.service import MessageManager
from src.agent.prompts import (
    BrainPrompt_kylin,
    ActorPrompt_kylin,
    MemoryPrompt,
    PlannerPrompt,
)
from src.agent.views import (
    ActionResult,
    AgentError,
    AgentHistory,
    AgentHistoryList,
    AgentOutput,
    AgentStepInfo,
    AgentBrain,
)
from src.utils.record_store import RecordStore
from src.utils.brain_search import BrainSearchFlow
from src.utils.skills import (
    load_skill_metadata,
    load_skill_contents,
    format_skill_catalog,
    format_skill_context,
)
from src.agent.planner_service import Planner
from src.controller.service import Controller
from src.utils import time_execution_async
from src.utils.token_counter import TokenCounter
from src.agent.output_schemas import OutputSchemas
from src.agent.structured_llm import *
from src.logger import get_session_logger

load_dotenv()
logger = logging.getLogger(__name__)
session_logger = None  # 将在 agent 初始化时设置

T = TypeVar("T", bound=BaseModel)

TASK_ID_MAX_LEN = 60
MAX_PENDING_LINES = 20
MAX_BRAIN_CONTEXT_ENTRIES = 50

if platform.system() == "Linux":
    from src.linux.screen import capture_target_screenshot
else:
    capture_target_screenshot = None


def _take_pyautogui_screenshot(region: Optional[tuple[int, int, int, int]] = None):
    import pyautogui

    if region is not None:
        return pyautogui.screenshot(region=region)
    return pyautogui.screenshot()


def _task_to_slug(task: str, max_len: int = TASK_ID_MAX_LEN) -> str:
    task = task.strip().lower()
    task = re.sub(r"[^a-z0-9]+", "-", task)
    task = task.strip("-")
    if not task:
        task = "task"
    return task[:max_len]


def _default_agent_id(task: str, now: datetime) -> str:
    date_str = now.strftime("%Y-%m-%d")
    slug = _task_to_slug(task)
    return f"{date_str}_{slug}"


def screenshot_to_dataurl(screenshot):
    img_byte_arr = io.BytesIO()
    screenshot.save(img_byte_arr, format="PNG")
    base64_encoded = base64.b64encode(img_byte_arr.getvalue()).decode("utf-8")
    return f"data:image/png;base64,{base64_encoded}"


def _llm_identity_text(llm: Optional[BaseChatModel]) -> str:
    if llm is None:
        return ""
    parts = [
        llm.__class__.__name__,
        getattr(llm, "model_name", ""),
        getattr(llm, "model", ""),
        getattr(llm, "openai_api_base", ""),
        getattr(llm, "base_url", ""),
    ]
    return " ".join(str(part).lower() for part in parts if part)


def llm_supports_response_format(llm: Optional[BaseChatModel]) -> bool:
    if llm is None:
        return False
    explicit = getattr(llm, "_kylin_supports_response_format", None)
    if explicit is not None:
        return bool(explicit)

    if isinstance(llm, (ChatOpenAI, AzureChatOpenAI)):
        identity = _llm_identity_text(llm)
        unsupported_tokens = ("deepseek", "minimax", "m2.5", "moonshot", "kimi")
        return not any(token in identity for token in unsupported_tokens)
    return True


def downscale_screenshot_by_tier(screenshot):
    """
    Apply tiered screenshot downscaling:
    - 720p/1080p: keep original
    - 2K/4K (and >2200px, <8K): divide width/height by 2
    - 8K/16K: divide width/height by 4
    """
    width, height = screenshot.size
    max_dim = max(width, height)
    scale_factor = 1

    if max_dim >= 7680:
        scale_factor = 4
    elif max_dim > 2200:
        scale_factor = 2

    if scale_factor == 1:
        return screenshot

    target_size = (max(1, width // scale_factor), max(1, height // scale_factor))
    if hasattr(Image, "Resampling"):
        resample = Image.Resampling.LANCZOS
    else:
        resample = Image.LANCZOS
    resized = screenshot.resize(target_size, resample=resample)
    logger.debug(
        "Downscaled screenshot from %sx%s to %sx%s (scale factor: %s)",
        width,
        height,
        resized.width,
        resized.height,
        scale_factor,
    )
    return resized


def to_structured(
    llm: Optional[BaseChatModel], Schema, Structured_Output
) -> Optional[BaseChatModel]:
    """
    Wrap any LangChain chat model with the right structured-output mechanism:

    - ChatOpenAI / AzureChatOpenAI -> bind(response_format=...) (OpenAI style)
    - ChatAnthropic / ChatGoogleGenerativeAI -> with_structured_output(...) (Claude/Gemini style)
    - ChatOllama -> bind(format=<json schema>) (Ollama json schema, when enabled)
    - LocalTransformersModel -> bind(response_format=...) (custom)
    - anything else -> returned unchanged
    """
    OPENAI_CLASSES: tuple[Type[BaseChatModel], ...] = (ChatOpenAI, AzureChatOpenAI)
    ANTHROPIC_OR_GEMINI: tuple[Type[BaseChatModel], ...] = tuple(
        cls for cls in [ChatAnthropic, ChatGoogleGenerativeAI] if cls is not None
    )
    OLLAMA_CLASSES: tuple[Type[BaseChatModel], ...] = tuple(cls for cls in [ChatOllama] if cls is not None)

    # Import LocalTransformersModel if available
    LOCAL_MODEL_CLASS = None
    try:
        from src.utils.local_model import LocalTransformersModel
        LOCAL_MODEL_CLASS = LocalTransformersModel
    except ImportError:
        pass

    if isinstance(llm, OPENAI_CLASSES):
        if not llm_supports_response_format(llm):
            logger.info(
                "Structured response_format is disabled for model '%s'; falling back to prompt-only JSON.",
                getattr(llm, "model_name", getattr(llm, "model", "unknown")),
            )
            return llm

        # OpenAI cloud endpoint expects flattened json_schema fields under response_format
        # (type/name/schema/strict), while many OpenAI-compatible backends accept the nested
        # {"type":"json_schema","json_schema":{...}} shape.
        response_format = Schema
        base_url = str(
            getattr(llm, "openai_api_base", "") or getattr(llm, "base_url", "") or ""
        ).lower()
        is_openai_cloud = (not base_url) or ("api.openai.com" in base_url)
        if is_openai_cloud and isinstance(Schema, dict):
            schema_type = Schema.get("type")
            json_schema = Schema.get("json_schema")
            if schema_type == "json_schema" and isinstance(json_schema, dict):
                flat = {"type": "json_schema"}
                if json_schema.get("name"):
                    flat["name"] = json_schema.get("name")
                if json_schema.get("schema") is not None:
                    flat["schema"] = json_schema.get("schema")
                if json_schema.get("strict") is not None:
                    flat["strict"] = json_schema.get("strict")
                response_format = flat
        return llm.bind(response_format=response_format)

    if isinstance(llm, ANTHROPIC_OR_GEMINI):
        return llm.with_structured_output(Structured_Output)

    if isinstance(llm, OLLAMA_CLASSES):
        if not llm_supports_response_format(llm):
            logger.info(
                "Structured response_format is disabled for Ollama model '%s'; falling back to prompt-only JSON.",
                getattr(llm, "model_name", getattr(llm, "model", "unknown")),
            )
            return llm
        # Ollama expects a raw JSON schema in the "format" param.
        schema = None
        if isinstance(Schema, dict):
            json_schema = Schema.get("json_schema")
            if isinstance(json_schema, dict):
                schema = json_schema.get("schema")
        return llm.bind(format=schema or "json")

    # Handle LocalTransformersModel
    if LOCAL_MODEL_CLASS and isinstance(llm, LOCAL_MODEL_CLASS):
        logger.info("Using local model with structured output support")
        return llm.bind(response_format=Schema)

    # Handle LocalTransformersModelWrapper (from examples/main.py model sharing)
    # Check for the class-level flag instead of importing the class
    if getattr(llm, "_is_local_transformers_wrapper", False):
        logger.info("Using shared local model wrapper with structured output support")
        return llm.with_structured_output(Structured_Output)

    return llm


class Agent:
    def __init__(
        self,
        task: str,
        brain_llm: BaseChatModel,
        actor_llm: BaseChatModel,
        memory_llm: BaseChatModel,
        controller: Controller = Controller(),
        use_search: bool = True,
        use_skills: bool = False,
        skills_dir: Optional[str] = None,
        skills_max_chars: int = 4000,
        planner_llm: Optional[BaseChatModel] = None,
        save_planner_conversation_path: Optional[str] = None,
        save_planner_conversation_path_encoding: Optional[str] = "utf-8",
        save_brain_conversation_path: Optional[str] = None,
        save_brain_conversation_path_encoding: Optional[str] = "utf-8",
        save_actor_conversation_path: Optional[str] = None,
        save_actor_conversation_path_encoding: Optional[str] = "utf-8",
        artifacts_dir: Optional[str] = None,
        max_failures: int = 5,
        memory_budget: int = 500,
        summary_memory_budget: Optional[int] = None,
        retry_delay: int = 10,
        max_input_tokens: int = 32000,
        resume: bool = False,
        include_attributes: list[str] = [
            "title",
            "type",
            "name",
            "role",
            "tabindex",
            "aria-label",
            "placeholder",
            "value",
            "alt",
            "aria-expanded",
        ],
        max_error_length: int = 400,
        max_actions_per_step: int = 10,
        step_delay: float = 0.2,
        register_new_step_callback: Callable[["str", "AgentOutput", int], None] | None = None,
        register_done_callback: Callable[["AgentHistoryList"], None] | None = None,
        tool_calling_method: Optional[str] = "auto",
        agent_id: Optional[str] = None,
        status_window_enabled: bool = True,
        brain_include_previous_screenshot: bool = False,
    ):
        global session_logger
        self.wait_this_step = False
        self.current_time = datetime.now()
        self.agent_id = agent_id or _default_agent_id(task, self.current_time)
        self.task = task
        self.artifacts_dir = Path(artifacts_dir).expanduser().resolve() if artifacts_dir else None
        if self.artifacts_dir:
            self.images_dir = str(self.artifacts_dir / "images" / self.agent_id)
            self.save_temp_file_path = str(self.artifacts_dir / "temp_files")
        else:
            self.images_dir = "images"
            self.save_temp_file_path = os.path.join(os.path.dirname(__file__), "temp_files")
        self.original_task = task
        self.resume = resume
        self.status_window_enabled = status_window_enabled
        self._status_window = None
        self._step_log_path = None  # 步骤记录文件路径
        self._step_record_json_path = Path.home() / ".hermes" / "sessions" / "step_record.json"
        self._step_records: list[dict[str, Any]] = []
        self._step_errors: dict[int, str] = {}

        # 获取状态窗口实例
        if self.status_window_enabled:
            try:
                from src.utils.status_window import get_status_window
                self._status_window = get_status_window()
                if self._status_window:
                    logger.info("状态窗口已关联到 Agent")
            except Exception as e:
                logger.warning(f"获取状态窗口失败：{e}")
                self._status_window = None
        
        # 初始化会话日志器
        session_logger = get_session_logger()
        if session_logger:
            session_logger.session_start(
                task=task,
                config={
                    "agent_id": self.agent_id,
                    "max_steps": max_input_tokens,
                    "memory_budget": memory_budget,
                    "use_search": use_search,
                    "use_skills": use_skills,
                    "brain_include_previous_screenshot": brain_include_previous_screenshot,
                }
            )
        
        self.memory_llm = to_structured(memory_llm, OutputSchemas.MEMORY_RESPONSE_FORMAT, MemoryOutput)
        self.brain_llm = to_structured(brain_llm, OutputSchemas.BRAIN_RESPONSE_FORMAT, BrainOutput)
        self.actor_llm = to_structured(actor_llm, OutputSchemas.ACTION_RESPONSE_FORMAT, ActorOutput)
        self.planner_llm_raw = planner_llm
        self.planner_llm = to_structured(planner_llm, OutputSchemas.PLANNER_RESPONSE_FORMAT, PlannerOutput)
        self.token_counter = TokenCounter(brain_llm)
        self.memory_budget_tokens = max(1, int(memory_budget))
        default_summary_budget = max(1, self.memory_budget_tokens * 4)
        self.summary_memory_budget_tokens = max(
            1,
            int(summary_memory_budget) if summary_memory_budget is not None else default_summary_budget,
        )
        # Backward-compatible aliases used by older run artifacts/config assumptions.
        self.memory_budget = self.memory_budget_tokens
        self.summary_memory_budget = self.summary_memory_budget_tokens
        self.memory_warn_ratio = 0.7
        self.memory_hard_ratio = 1.0

        self.save_actor_conversation_path = save_actor_conversation_path
        self.save_actor_conversation_path_encoding = save_actor_conversation_path_encoding
        self.save_brain_conversation_path = save_brain_conversation_path
        self.save_brain_conversation_path_encoding = save_brain_conversation_path_encoding
        self.save_planner_conversation_path = save_planner_conversation_path
        self.save_planner_conversation_path_encoding = save_planner_conversation_path_encoding or "utf-8"

        self.include_attributes = include_attributes
        self.max_error_length = max_error_length
        self.screenshot_annotated = None
        self.max_input_tokens = max_input_tokens
        self.brain_include_previous_screenshot = brain_include_previous_screenshot
        self.use_search = use_search
        self.use_skills = use_skills
        self.skills_dir = Path(skills_dir).expanduser() if skills_dir else None
        self.skills_max_chars = max(0, skills_max_chars or 0)
        self.available_skills = []
        self.selected_skills = []
        self.skill_context = ""
        self.next_goal = ""
        self.brain_thought = ""

        self.controller = controller
        self.max_actions_per_step = max_actions_per_step
        self.step_delay = max(0.0, float(step_delay))
        self.last_step_action = None
        self._recent_action_signatures = deque(maxlen=8)
        self.goal_action_memory = OrderedDict()

        self.last_goal = None
        self.brain_context = OrderedDict()
        self.status = "success"
        self._setup_action_models()
        # self._set_model_names()

        # Loop detection: track recent goals to detect repetition
        self._recent_goals: list[str] = []
        self._max_goal_history = 5
        self.save_temp_file_path = os.path.join(self.save_temp_file_path, f"{self.agent_id}")
        self.record_dir = os.path.join(self.save_temp_file_path, "records")
        self.record_store = RecordStore(
            self.record_dir,
            encoding=self.save_brain_conversation_path_encoding or "utf-8",
        )
        self.memory_snapshot_dir = os.path.join(self.save_temp_file_path, "memory_snapshots")
        self.memory_snapshot_store = RecordStore(
            self.memory_snapshot_dir,
            encoding=self.save_brain_conversation_path_encoding or "utf-8",
        )
        self.brain_search = BrainSearchFlow(self.record_store)
        logger.info("Agent ID: %s", self.agent_id)
        logger.info("Agent memory path: %s", self.save_temp_file_path)

        if self.resume and not agent_id:
            raise ValueError("Agent ID is required for resuming a task.")
        self.save_temp_file_path = os.path.join(self.save_temp_file_path, f"{self.agent_id}")
        self.record_dir = os.path.join(self.save_temp_file_path, "records")
        self.record_store = RecordStore(
            self.record_dir,
            encoding=self.save_brain_conversation_path_encoding or "utf-8",
        )
        self.memory_snapshot_dir = os.path.join(self.save_temp_file_path, "memory_snapshots")
        self.memory_snapshot_store = RecordStore(
            self.memory_snapshot_dir,
            encoding=self.save_brain_conversation_path_encoding or "utf-8",
        )
        self.brain_search = BrainSearchFlow(self.record_store)
        logger.info("Agent ID: %s", self.agent_id)
        logger.info("Agent memory path: %s", self.save_temp_file_path)

        if self.use_skills and self.skills_dir:
            self.available_skills = load_skill_metadata(self.skills_dir)
            if not self.available_skills:
                logger.info("No skills loaded from %s", self.skills_dir)
            else:
                skill_names = ", ".join(skill.name for skill in self.available_skills)
                logger.info(
                    "Loaded %d skill(s) from %s: %s",
                    len(self.available_skills),
                    self.skills_dir,
                    skill_names,
                )
        elif self.use_skills:
            logger.info("Skills enabled but no skills directory provided.")

        if self.planner_llm:
            skill_catalog = ""
            if self.use_skills and self.available_skills:
                skill_catalog = format_skill_catalog(self.available_skills)
            planner_preplan_llm = self.planner_llm_raw if (self.use_search or self.use_skills) else None
            self.planner = Planner(
                planner_llm=self.planner_llm,
                task=self.task,
                max_input_tokens=self.max_input_tokens,
                preplan_llm=planner_preplan_llm,
                use_search=self.use_search,
                skill_catalog=skill_catalog,
                use_skills=self.use_skills,
                available_skills=self.available_skills,
                skills_max_chars=self.skills_max_chars,
                save_planner_conversation_path=self.save_planner_conversation_path,
                save_planner_conversation_path_encoding=self.save_planner_conversation_path_encoding,
            )
        elif self.use_skills:
            logger.info("Skills enabled but planner is disabled. Set agent.use_plan=true to select skills.")

        self.initiate_messages()
        self._last_result = None

        self.register_new_step_callback = register_new_step_callback
        self.register_done_callback = register_done_callback

        self.history: AgentHistoryList = AgentHistoryList(history=[])
        self.n_steps = 1
        self.consecutive_failures = 0
        self.max_failures = max_failures
        self.retry_delay = retry_delay
        self._paused = False
        self._stopped = False
        self.brain_memory = ""
        self.summary_memory = ""
        self.recent_memory = ""
        # Pending step lines are finalized in the next brain step.
        self.pending_recent_memory = ""
        self.memory_snapshot_files: list[dict[str, Any]] = []
        self.infor_memory = []
        self.last_pid = None
        self.ask_for_help = False

        # Loop detection: track recent goals to detect repetition
        self._recent_goals: list[str] = []
        self._max_goal_history = 5

        self.history: AgentHistoryList = AgentHistoryList(history=[])
        self.n_steps = 1
        self.consecutive_failures = 0
        self.max_failures = max_failures
        self.retry_delay = retry_delay
        self._paused = False
        self._stopped = False
        self.brain_memory = ""
        self.summary_memory = ""
        self.recent_memory = ""
        # Pending step lines are finalized in the next brain step.
        self.pending_recent_memory = ""
        self.memory_snapshot_files: list[dict[str, Any]] = []
        self.infor_memory = []
        self.last_pid = None
        self.ask_for_help = False

    def _set_model_names(self) -> None:
        self.chat_model_library = self.llm.__class__.__name__
        if hasattr(self.llm, "model_name"):
            self.model_name = self.llm.model_name  # type: ignore
        elif hasattr(self.llm, "model"):
            self.model_name = self.llm.model  # type: ignore
        else:
            self.model_name = "Unknown"

    def set_tool_calling_method(self, tool_calling_method: Optional[str]) -> Optional[str]:
        if tool_calling_method == "auto":
            if self.chat_model_library == "ChatGoogleGenerativeAI":
                return None
            if self.chat_model_library == "ChatOpenAI":
                return "function_calling"
            if self.chat_model_library == "AzureChatOpenAI":
                return "function_calling"
            return None

    def _setup_action_models(self) -> None:
        """Setup dynamic action models from controller's registry"""
        self.ActionModel = self.controller.registry.create_action_model()
        self.AgentOutput = AgentOutput.type_with_custom_actions(self.ActionModel)

    def get_last_pid(self) -> Optional[int]:
        latest_pid = self.last_pid
        if self._last_result:
            for r in self._last_result:
                if r.current_app_pid:
                    latest_pid = r.current_app_pid
        return latest_pid

    def _refresh_brain_memory(self) -> None:
        parts = []
        if self.summary_memory:
            parts.append(
                "Summarized memory (compressed from earlier steps, details may be approximate):\n"
                + self.summary_memory
            )
        if self.recent_memory:
            parts.append("Recent steps:\n" + self.recent_memory)
        if self.pending_recent_memory:
            parts.append("Pending steps (not yet evaluated):\n" + self.pending_recent_memory)
        self.brain_memory = "\n\n".join(parts).strip()

    @property
    def total_memory_tokens(self) -> int:
        return (
            self.token_counter.count(self.summary_memory)
            + self.token_counter.count(self.recent_memory)
            + self.token_counter.count(self.pending_recent_memory)
        )

    def _log_memory_metrics(self) -> None:
        logger.info(
            "[Memory] Step %d | recent=%d tokens | summary=%d tokens | pending=%d tokens | total=%d/%d tokens | info_files=%d",
            self.n_steps,
            self.token_counter.count(self.recent_memory),
            self.token_counter.count(self.summary_memory),
            self.token_counter.count(self.pending_recent_memory),
            self.total_memory_tokens,
            self.memory_budget_tokens + self.summary_memory_budget_tokens,
            len(self.infor_memory),
        )

    def _detect_goal_loop(self, goal: str) -> bool:
        """
        Detect if the current goal is too similar to recent goals (loop detection).
        Returns True if a loop is detected.
        """
        if not goal:
            return False
        
        # Normalize the goal for comparison
        goal_normalized = goal.lower().strip()
        
        # Check similarity with recent goals
        for recent_goal in self._recent_goals:
            # Simple string similarity check
            if goal_normalized == recent_goal:
                return True
            # Check if one contains the other (for similar goals)
            if goal_normalized in recent_goal or recent_goal in goal_normalized:
                return True
        
        return False
    
    def _force_goal_progress(self, current_goal: str) -> str:
        """
        Modify the goal to encourage progress when a loop is detected.
        """
        # Add instruction to try a different approach
        progress_instructions = [
            " Try a different approach.",
            " Consider an alternative method.",
            " Look for other ways to complete this task.",
            " Check if the previous action had the expected effect.",
        ]
        
        # Select instruction based on loop count
        loop_count = len(self._recent_goals)
        instruction = progress_instructions[loop_count % len(progress_instructions)]
        
        return current_goal + instruction
    
    def _update_recent_goals(self, goal: str) -> None:
        """Update the recent goals list with the current goal."""
        self._recent_goals.append(goal.lower().strip())
        if len(self._recent_goals) > self._max_goal_history:
            self._recent_goals.pop(0)

    def _action_signature(self, action: Any) -> Optional[str]:
        if action is None:
            return None
        try:
            action_dict = action.model_dump(exclude_unset=True) if hasattr(action, "model_dump") else action
            return json.dumps(action_dict, ensure_ascii=False, sort_keys=True)
        except Exception:
            return str(action)

    def _action_name_and_params(self, action: Any) -> tuple[Optional[str], Any]:
        action_dict = action.model_dump(exclude_unset=True) if hasattr(action, "model_dump") else action
        if not isinstance(action_dict, dict) or not action_dict:
            return None, None
        action_name = next(iter(action_dict.keys()))
        return action_name, action_dict.get(action_name)

    def _is_select_all_hotkey(self, action: Any) -> bool:
        action_name, params = self._action_name_and_params(action)
        if action_name == "Hotkey" and isinstance(params, dict):
            key = str(params.get("key", "")).lower().replace(" ", "")
            return key in {"ctrl+a", "control+a"}

        if action_name == "multi_Hotkey" and isinstance(params, dict):
            keys = [
                str(params.get("key1", "")).lower(),
                str(params.get("key2", "")).lower(),
                str(params.get("key3", "") or "").lower(),
            ]
            keys = [key.replace("control", "ctrl").replace(" ", "") for key in keys if key]
            return len(keys) == 2 and set(keys) == {"ctrl", "a"}

        return False

    def _remove_redundant_select_all_before_input(self, actions: list[Any]) -> list[Any]:
        if not actions:
            return actions

        filtered_actions: list[Any] = []
        removed_count = 0
        for index, action in enumerate(actions):
            next_action = actions[index + 1] if index + 1 < len(actions) else None
            next_action_name, _ = self._action_name_and_params(next_action)
            if self._is_select_all_hotkey(action) and next_action_name == "input_text":
                removed_count += 1
                continue
            filtered_actions.append(action)

        if removed_count:
            logger.debug(
                "[ActionOptimizer] Removed %d redundant Ctrl+A action(s) before input_text",
                removed_count,
            )
        return filtered_actions

    def _extract_text_target_from_goal(self, goal: str) -> Optional[str]:
        if not goal:
            return None

        quote = r"[\"'“”‘’]"
        target_patterns = (
            rf"(?:完整[^，。；;]*为|完整[^，。；;]*是)\s*{quote}([^\"'“”‘’]+){quote}",
            rf"(?:直接输入|输入|键入|录入|填入)\s*{quote}([^\"'“”‘’]+){quote}",
            rf"(?:改为|更改为|修改为|设置为|替换为|变为)\s*{quote}([^\"'“”‘’]+){quote}",
            rf"(?:type|enter|input)\s*{quote}([^\"'“”‘’]+){quote}",
            rf"(?:set(?: it)? to|change(?: it)? to|replace(?: it)? with)\s*{quote}([^\"'“”‘’]+){quote}",
        )
        for pattern in target_patterns:
            matches = re.findall(pattern, goal, flags=re.IGNORECASE)
            if matches:
                return matches[-1].strip()

        time_target = self._extract_time_target_from_goal(goal)
        if time_target:
            return time_target

        if self._is_sensitive_text_goal(goal):
            unquoted_sensitive_patterns = (
                r"(?:密码|口令|验证码|校验码|pin|password|passcode|verification code|otp)[^，。；;\n]*?(?:设置为|设为|填入|输入|为|是)\s*([A-Za-z0-9@#._-]{3,64})",
                r"(?:设置|输入|填入|enter|input|set)[^，。；;\n]*?(?:密码|口令|验证码|校验码|pin|password|passcode|verification code|otp)[^，。；;\n]*?([A-Za-z0-9@#._-]{3,64})",
            )
            for pattern in unquoted_sensitive_patterns:
                matches = re.findall(pattern, goal, flags=re.IGNORECASE)
                if matches:
                    return matches[-1].strip()

        quoted_values = [value.strip() for value in re.findall(r"[\"'“‘]([^\"'”’]+)[\"'”’]", goal)]
        if not quoted_values:
            return None
        if any(term in goal for term in ("输入框", "文本框", "搜索框", "密码", "主题", "时间", "日期", "选择框", "下拉", "下拉按钮", "下拉箭头")):
            return quoted_values[-1]
        return None

    def _extract_time_target_from_goal(self, goal: str) -> Optional[str]:
        if not self._is_time_edit_goal(goal):
            return None

        time_matches = re.findall(r"(?<!\d)([0-2]?\d[:：][0-5]\d)(?!\d)", goal)
        if time_matches:
            return time_matches[-1].replace("：", ":")

        hour_matches = re.findall(r"(?:改为|更改为|修改为|设置为|输入|选择|to)\s*([0-2]?\d)(?!\d)", goal, flags=re.IGNORECASE)
        if hour_matches:
            return hour_matches[-1]
        return None

    def _is_click_action(self, action: Any) -> bool:
        action_name, _ = self._action_name_and_params(action)
        return action_name in {"Click", "DoubleClick"}

    def _has_input_text_action(self, actions: list[Any]) -> bool:
        return any(self._action_name_and_params(action)[0] == "input_text" for action in actions)

    def _input_text_values(self, actions: list[Any]) -> list[str]:
        values: list[str] = []
        for action in actions:
            action_name, params = self._action_name_and_params(action)
            if action_name == "input_text" and isinstance(params, dict):
                text = params.get("text")
                if isinstance(text, str) and text.strip():
                    values.append(text.strip())
        return values

    @staticmethod
    def _compact_text_for_match(text: str) -> str:
        return re.sub(r"\s+", "", text or "").lower()

    def _is_scroll_action(self, action: Any) -> bool:
        action_name, _ = self._action_name_and_params(action)
        return action_name in {"scroll_up", "scroll_down"}

    def _is_sensitive_text_goal(self, goal: str) -> bool:
        goal_lower = (goal or "").lower()
        sensitive_terms = (
            "密码",
            "口令",
            "验证码",
            "校验码",
            "pin",
            "password",
            "passcode",
            "verification code",
            "otp",
        )
        return any(term in goal_lower for term in sensitive_terms)

    def _sensitive_goal_includes_enabling_control(self, goal: str) -> bool:
        goal_lower = (goal or "").lower()
        enable_terms = (
            "开启",
            "打开",
            "启用",
            "勾选",
            "选中",
            "切换",
            "enable",
            "turn on",
            "toggle",
            "check",
        )
        return self._is_sensitive_text_goal(goal) and any(term in goal_lower for term in enable_terms)

    def _is_compact_selector_goal(self, goal: str) -> bool:
        goal_lower = (goal or "").lower()
        selector_terms = (
            "时间",
            "日期",
            "小时",
            "分钟",
            "时长",
            "选择器",
            "选择框",
            "下拉",
            "下拉框",
            "下拉按钮",
            "下拉箭头",
            "带下拉",
            "time",
            "date",
            "hour",
            "minute",
            "duration",
            "selector",
            "dropdown",
            "dropdown button",
            "dropdown arrow",
            "combobox",
            "combo box",
        )
        return any(term in goal_lower for term in selector_terms)

    def _is_time_edit_goal(self, goal: str) -> bool:
        goal_lower = (goal or "").lower()
        return any(term in goal_lower for term in ("时间", "小时", "分钟", "time", "hour", "minute"))

    def _goal_allows_direct_input_completion(self, goal: str) -> bool:
        goal_lower = goal.lower()
        direct_terms = (
            "输入",
            "键入",
            "录入",
            "填入",
            "选择",
            "直接",
            "改为",
            "更改为",
            "修改为",
            "设置为",
            "替换",
            "type",
            "enter",
            "input",
            "select",
            "change",
            "set",
            "replace",
        )
        editable_terms = (
            "输入框",
            "文本框",
            "搜索框",
            "密码",
            "主题",
            "时间",
            "日期",
            "选择框",
            "下拉",
            "下拉框",
            "下拉按钮",
            "下拉箭头",
            "带下拉",
            "field",
            "box",
            "dropdown",
            "dropdown button",
            "dropdown arrow",
            "combobox",
            "combo box",
        )
        return any(term in goal_lower for term in direct_terms) and any(term in goal_lower for term in editable_terms)

    def _goal_prefers_direct_input(self, goal: str) -> bool:
        goal_lower = (goal or "").lower()
        direct_input_terms = (
            "直接输入",
            "输入",
            "键入",
            "录入",
            "填入",
            "选择",
            "改为",
            "更改为",
            "修改为",
            "设置为",
            "替换为",
            "type",
            "enter",
            "input",
            "select",
            "change",
            "set",
            "replace",
        )
        return any(term in goal_lower for term in direct_input_terms)

    def _goal_requests_enter_confirmation(self, goal: str) -> bool:
        goal_lower = goal.lower()
        return (
            self._is_time_edit_goal(goal)
            or "enter" in goal_lower
            or "回车" in goal_lower
            or "按下确认" in goal_lower
            or "确认" in goal_lower
        )

    def _is_searchable_selection_goal(self, goal: str) -> bool:
        goal_lower = (goal or "").lower()
        selection_terms = (
            "选择",
            "选中",
            "添加",
            "邀请",
            "查找",
            "寻找",
            "搜索",
            "加入",
            "select",
            "add",
            "invite",
            "find",
            "search",
            "choose",
        )
        target_terms = (
            "联系人",
            "群成员",
            "成员",
            "好友",
            "用户",
            "人员",
            "收件人",
            "文件",
            "条目",
            "列表",
            "contact",
            "member",
            "user",
            "person",
            "people",
            "recipient",
            "file",
            "item",
            "list",
            "picker",
        )
        return any(term in goal_lower for term in selection_terms) and any(term in goal_lower for term in target_terms)

    def _limit_compact_selector_scroll(self, actions: list[Any]) -> list[Any]:
        if not actions or not self._is_compact_selector_goal(self.next_goal):
            return actions

        optimized_actions: list[Any] = []
        changed = False
        for action in actions:
            action_name, params = self._action_name_and_params(action)
            if action_name in {"scroll_up", "scroll_down"} and isinstance(params, dict):
                limited_params = dict(params)
                raw_dy = limited_params.get("dy", 2)
                try:
                    dy = int(abs(float(raw_dy)))
                except (TypeError, ValueError):
                    dy = 2
                limited_params["dy"] = min(max(dy, 1), 2)
                limited_params["dx"] = 0
                optimized_actions.append({action_name: limited_params})
                changed = changed or limited_params != params
                continue
            optimized_actions.append(action)

        if changed:
            logger.debug("[ActionOptimizer] Limited compact selector scroll magnitude to 1-2 ticks")
        return optimized_actions

    def _complete_direct_text_edit_actions(self, actions: list[Any]) -> list[Any]:
        if not actions or self._has_input_text_action(actions):
            return actions

        text_target = self._extract_text_target_from_goal(self.next_goal)
        if not text_target:
            return actions

        if len(actions) == 1 and self._is_select_all_hotkey(actions[0]):
            logger.debug("[ActionOptimizer] Replaced standalone Ctrl+A with input_text from goal")
            return [{"input_text": {"text": text_target}}]

        if (
            self._is_sensitive_text_goal(self.next_goal)
            and self._sensitive_goal_includes_enabling_control(self.next_goal)
            and sum(1 for action in actions if self._is_click_action(action)) < 2
        ):
            return actions

        if self._goal_allows_direct_input_completion(self.next_goal) and any(self._is_click_action(action) for action in actions):
            optimized_actions = [
                action
                for action in actions
                if not (
                    self._is_scroll_action(action)
                    and self._is_compact_selector_goal(self.next_goal)
                    and self._goal_prefers_direct_input(self.next_goal)
                )
            ]
            optimized_actions.append({"input_text": {"text": text_target}})
            if self._goal_requests_enter_confirmation(self.next_goal):
                optimized_actions.append({"Hotkey": {"key": "enter"}})
            logger.debug("[ActionOptimizer] Completed click-only text edit with input_text")
            return optimized_actions

        return actions

    def _is_once_only_goal(self, goal: str) -> bool:
        goal_lower = (goal or "").lower()
        if any(term in goal_lower for term in ("input", "type", "输入", "文本", "字段", "field")):
            return False
        once_only_terms = (
            "复制",
            "copy",
            "发送",
            "send",
            "提交",
            "submit",
            "预定",
            "schedule",
        )
        return any(term in goal_lower for term in once_only_terms)

    def _check_repeated_actions(self, actions: list[Any]) -> Optional[str]:
        if not actions:
            return None
        signatures = [sig for action in actions if (sig := self._action_signature(action))]
        if not signatures:
            return None

        current_signature = "|".join(signatures)
        repeated_count = 0
        for previous_signature in reversed(self._recent_action_signatures):
            if previous_signature != current_signature:
                break
            repeated_count += 1

        threshold = 1 if self._is_once_only_goal(self.next_goal) else 2
        if repeated_count >= threshold:
            return (
                f"Repeated action blocked after {repeated_count + 1} identical attempts. "
                "Do not repeat the same click/action again; assume one-shot actions succeeded, "
                "verify the current screen, and move to the next task step or choose a different method."
            )
        return None

    def _remember_action_attempt(self, actions: list[Any]) -> None:
        signatures = [sig for action in actions if (sig := self._action_signature(action))]
        if signatures:
            self._recent_action_signatures.append("|".join(signatures))

    def _check_text_input_focus(self, actions: list[Any], previous_actions: Optional[list[Any]] = None) -> Optional[str]:
        saw_focus_click = False
        previous_had_focus_click = any(self._is_click_action(action) for action in (previous_actions or []))
        click_count_before_input = 0
        saw_text_focus_action = False
        for action in actions:
            action_dict = action.model_dump(exclude_unset=True) if hasattr(action, "model_dump") else action
            if not isinstance(action_dict, dict):
                continue
            for action_name, params in action_dict.items():
                if params is None:
                    continue
                if action_name in {"Click", "DoubleClick"}:
                    saw_focus_click = True
                    click_count_before_input += 1
                    saw_text_focus_action = True
                elif action_name == "Hotkey" and isinstance(params, dict):
                    key = str(params.get("key", "")).lower().replace(" ", "")
                    if key in {"ctrl+a", "control+a"}:
                        saw_text_focus_action = True
                elif action_name == "input_text":
                    if not saw_focus_click:
                        if previous_had_focus_click and not self._sensitive_goal_includes_enabling_control(self.next_goal):
                            continue
                        return (
                            "Text input blocked because the target input field was not clicked in the same action list. "
                            "Click the exact text input field, then use input_text. Do not move to the next workflow step yet."
                        )
                    if (
                        self._sensitive_goal_includes_enabling_control(self.next_goal)
                        and click_count_before_input < 2
                    ):
                        return (
                            "Sensitive text input blocked because the action appears to click an enable/toggle control before typing. "
                            "First enable/show the field, then click the exact password/code input box before input_text."
                        )
        return None

    def _check_searchable_selection_strategy(self, actions: list[Any]) -> Optional[str]:
        if not actions or not self._is_searchable_selection_goal(self.next_goal):
            return None
        input_values = self._input_text_values(actions)
        if input_values:
            source_text = self._compact_text_for_match(f"{self.original_task}\n{self.next_goal}")
            for value in input_values:
                compact_value = self._compact_text_for_match(value)
                if len(compact_value) >= 2 and compact_value not in source_text:
                    return (
                        "Searchable selection input blocked because the typed keyword/name does not appear in the original task or current goal. "
                        "Use the exact contact/member/user/file/item name from the task or current goal; do not infer, translate, abbreviate, or alter characters."
                    )
            return None
        if any(self._is_scroll_action(action) for action in actions):
            return (
                "Searchable selection blocked because the action scrolls through a selectable list without searching. "
                "If the target is visible, click it directly. If a search box is visible, click it and use input_text "
                "with the exact target name/keyword before selecting the result. Scroll only after confirming no search box is available or search returned no match."
            )
        return None

    def _is_summary_valid(self, original_text: str, summary_text: str, tier: str) -> bool:
        summary_tokens = self.token_counter.count(summary_text)
        original_tokens = self.token_counter.count(original_text)

        if summary_tokens < 10:
            logger.warning(
                "[Memory] %s summary too short (%d tokens). Keeping original.",
                tier,
                summary_tokens,
            )
            return False
        if original_tokens > 0 and summary_tokens >= original_tokens:
            logger.warning(
                "[Memory] %s summary (%d tokens) not shorter than original (%d tokens). Keeping original.",
                tier,
                summary_tokens,
                original_tokens,
            )
            return False
        return True

    def _extract_response_token_usage(self, response: Any) -> tuple[Optional[int], Optional[int], Optional[int]]:
        usage_candidates = []
        response_metadata = getattr(response, "response_metadata", None)
        if isinstance(response_metadata, dict):
            usage_candidates.append(response_metadata.get("token_usage"))
            usage_candidates.append(response_metadata.get("usage"))
        usage_metadata = getattr(response, "usage_metadata", None)
        if isinstance(usage_metadata, dict):
            usage_candidates.append(usage_metadata)
        if isinstance(response, dict):
            usage_candidates.append(response.get("token_usage"))
            usage_candidates.append(response.get("usage"))

        usage = next((item for item in usage_candidates if isinstance(item, dict)), {})
        if not isinstance(usage, dict):
            return None, None, None

        def _to_int(value: Any) -> Optional[int]:
            try:
                return int(value) if value is not None else None
            except (TypeError, ValueError):
                return None

        prompt_tokens = _to_int(usage.get("prompt_tokens"))
        if prompt_tokens is None:
            prompt_tokens = _to_int(usage.get("input_tokens"))

        completion_tokens = _to_int(usage.get("completion_tokens"))
        if completion_tokens is None:
            completion_tokens = _to_int(usage.get("output_tokens"))

        total_tokens = _to_int(usage.get("total_tokens"))
        if total_tokens is None:
            total_tokens = self.token_counter.count_from_api_usage(response)

        return prompt_tokens, completion_tokens, total_tokens

    def _extract_memory_payload(self, response: Any) -> dict:
        parsed = getattr(response, "parsed", None)
        if isinstance(parsed, dict):
            return parsed
        if isinstance(response, dict):
            return response
        memory_text = str(getattr(response, "content", response))
        cleaned_memory_response = re.sub(r"^```(json)?", "", memory_text.strip())
        cleaned_memory_response = re.sub(r"```$", "", cleaned_memory_response).strip()
        logger.debug("[Memory] Raw text: %s", cleaned_memory_response)
        return json.loads(cleaned_memory_response)

    async def _run_memory_summary(self, memory_text: str, context_label: str) -> tuple[str, str]:
        memory_content = [
            {
                "type": "text",
                "content": f"{context_label}\n\n{memory_text}",
            }
        ]
        self.memory_message_manager._remove_last_state_message()
        self.memory_message_manager._remove_last_AIntool_message()
        self.memory_message_manager.add_state_message(memory_content)
        memory_messages = self.memory_message_manager.get_messages()
        response = await self.memory_llm.ainvoke(memory_messages)
        prompt_tokens, completion_tokens, total_tokens = self._extract_response_token_usage(response)
        estimate_tokens = self.token_counter.count(memory_text)
        if total_tokens:
            logger.info(
                "[Memory] Summary call (%s) token usage | prompt=%s output=%s total=%s estimate_input=%d",
                context_label,
                prompt_tokens if prompt_tokens is not None else "?",
                completion_tokens if completion_tokens is not None else "?",
                total_tokens,
                estimate_tokens,
            )
        if prompt_tokens is not None:
            logger.debug(
                "[Memory] Input token estimate delta (%s): estimate=%d, prompt=%d, delta=%d",
                context_label,
                estimate_tokens,
                prompt_tokens,
                estimate_tokens - prompt_tokens,
            )
        if completion_tokens is not None and completion_tokens > max(128, self.memory_budget_tokens // 2):
            logger.warning(
                "[Memory] Summary output is large (%d tokens). Compression quality may be poor.",
                completion_tokens,
            )
        parsed = self._extract_memory_payload(response)
        summary = str(parsed.get("summary", "")).strip()
        file_name = str(parsed.get("file_name", "")).strip()
        return summary, file_name

    def _save_memory_snapshot(
        self,
        memory_text: str,
        file_name: str,
        source: str,
        step_override: Optional[int] = None,
    ) -> Optional[str]:
        if not memory_text:
            return None
        step_value = step_override if step_override is not None else self.n_steps
        safe_name = file_name or f"memory_snapshot_{source}_step_{step_value}.txt"
        saved_name = self.memory_snapshot_store.save(memory_text, safe_name, step=step_value)
        self.memory_snapshot_files.append(
            {
                "file_name": saved_name,
                "source": source,
                "step": step_value,
            }
        )
        return saved_name

    async def _summarise_memory(self) -> None:
        """
        Summarise recent memory to reduce its size without counting summaries in the budget.
        """
        await self._summarise_recent_memory()

    async def _summarise_recent_memory(self, step_override: Optional[int] = None) -> None:
        if not self.recent_memory:
            return
        try:
            summary, file_name = await self._run_memory_summary(
                self.recent_memory,
                "Summarize the following recent-step memory.",
            )
        except Exception:
            logger.exception("[Memory] Failed to summarize recent memory.")
            self._save_memory_snapshot(self.recent_memory, "", "recent", step_override=step_override)
            self._refresh_brain_memory()
            return

        self._save_memory_snapshot(self.recent_memory, file_name, "recent", step_override=step_override)
        if not summary:
            logger.warning("[Memory] Empty summary from memory model; keeping recent memory.")
            self._refresh_brain_memory()
            return
        if not self._is_summary_valid(self.recent_memory, summary, tier="Recent"):
            self._refresh_brain_memory()
            return

        if self.summary_memory:
            self.summary_memory = "\n".join([self.summary_memory, summary]).strip()
        else:
            self.summary_memory = summary
        self.recent_memory = ""
        await self._summarise_summary_memory(step_override=step_override)
        self._refresh_brain_memory()

    async def _summarise_summary_memory(self, step_override: Optional[int] = None) -> None:
        if not self.summary_memory:
            return
        if self.token_counter.count(self.summary_memory) <= self.summary_memory_budget_tokens:
            return
        try:
            summary, file_name = await self._run_memory_summary(
                self.summary_memory,
                "Summarize the following accumulated summaries into a higher-level summary.",
            )
        except Exception:
            logger.exception("[Memory] Failed to summarize accumulated summaries.")
            self._save_memory_snapshot(self.summary_memory, "", "summary", step_override=step_override)
            return

        self._save_memory_snapshot(self.summary_memory, file_name, "summary", step_override=step_override)
        if not summary:
            logger.warning("[Memory] Empty high-level summary; keeping existing summaries.")
            self._refresh_brain_memory()
            return
        if not self._is_summary_valid(self.summary_memory, summary, tier="Higher-level"):
            self._refresh_brain_memory()
            return
        self.summary_memory = summary
        self._refresh_brain_memory()

    async def _update_memory(self) -> None:
        """
        Update memory content.
        """
        sorted_steps = sorted(self.brain_context.keys(), reverse=True)
        if not sorted_steps:
            return
        current_state = self.brain_context[sorted_steps[0]]["current_state"]
        step_goal = current_state["next_goal"] if current_state else None
        step_id = sorted_steps[0]

        # Always write the current step as pending. The success/failed signal for step N
        # arrives in brain_step() of step (N+1). Pending lines do not count toward budget.
        line = f"Step {step_id} | Eval: pending | Goal: {step_goal}"
        result_note = self._format_last_result_for_memory()
        if result_note:
            line = f"{line} | Result: {result_note}"
        pending_lines = [ln for ln in self.pending_recent_memory.splitlines() if ln.strip()]
        pending_lines = [ln for ln in pending_lines if not ln.startswith(f"Step {step_id} |")]
        pending_lines.append(line)
        if len(pending_lines) > MAX_PENDING_LINES:
            pending_lines = pending_lines[-MAX_PENDING_LINES:]
            logger.warning("[Memory] Trimmed pending memory to last %d lines.", MAX_PENDING_LINES)
        self.pending_recent_memory = "\n".join(pending_lines).strip()
        self._refresh_brain_memory()
        self._log_memory_metrics()

    def _format_last_result_for_memory(self, max_chars: int = 300) -> str:
        if not self._last_result:
            return ""
        parts = []
        for item in self._last_result[:3]:
            error = getattr(item, "error", None)
            extracted = getattr(item, "extracted_content", None)
            if error:
                parts.append(f"error={error}")
            elif extracted:
                parts.append(str(extracted))
        return "; ".join(parts)[:max_chars]

    def save_memory(self) -> None:
        """Save the current memory to a file."""
        if not self.save_temp_file_path:
            return
        data = {
            "pid": self.get_last_pid(),
            "task": self.task,
            "next_goal": self.next_goal,
            "last_step_action": self.last_step_action,
            "infor_memory": self.infor_memory,
            "brain_context": self.brain_context,
            "step": self.n_steps,
            "summary_memory": self.summary_memory,
            "pending_recent_memory": self.pending_recent_memory,
            "recent_memory": self.recent_memory,
            "memory_budget_tokens": self.memory_budget_tokens,
            "summary_memory_budget_tokens": self.summary_memory_budget_tokens,
            # Backward-compatible fields
            "memory_budget": self.memory_budget_tokens,
            "summary_memory_budget": self.summary_memory_budget_tokens,
            "recent_memory_tokens": self.token_counter.count(self.recent_memory),
            "summary_memory_tokens": self.token_counter.count(self.summary_memory),
            "pending_memory_tokens": self.token_counter.count(self.pending_recent_memory),
            "total_memory_tokens": self.total_memory_tokens,
            "memory_snapshot_files": self.memory_snapshot_files,
        }
        file_name = os.path.join(self.save_temp_file_path, "memory.jsonl")
        dir_name = os.path.dirname(file_name)
        if dir_name:
            os.makedirs(dir_name, exist_ok=True)
        fd, tmp_path = tempfile.mkstemp(dir=dir_name, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding=self.save_brain_conversation_path_encoding) as f:
                f.write(json.dumps(data, ensure_ascii=False, default=lambda o: list(o) if isinstance(o, set) else o) + "\n")
                # f.flush()
                # os.fsync(f.fileno())
            os.replace(tmp_path, file_name)
        except Exception:
            logger.exception("[Memory] Failed to save memory.")
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)

    async def load_memory(self) -> None:
        """Load the current memory from a file."""
        if not self.save_temp_file_path:
            return
        file_name = os.path.join(self.save_temp_file_path, "memory.jsonl")
        if os.path.exists(file_name):
            with open(file_name, "r", encoding=self.save_brain_conversation_path_encoding) as f:
                lines = f.readlines()
            if len(lines) >= 1:
                data = json.loads(lines[-1])
                self.task = data.get("task", "")
                self.last_pid = data.get("pid", None)
                self.infor_memory = data.get("infor_memory", [])
                self.brain_context = data.get("brain_context", OrderedDict())
                if self.brain_context:
                    self.brain_context = OrderedDict({int(k): v for k, v in self.brain_context.items()})
                    while len(self.brain_context) > MAX_BRAIN_CONTEXT_ENTRIES:
                        self.brain_context.popitem(last=False)
                self.summary_memory = data.get("summary_memory", "")
                self.pending_recent_memory = data.get("pending_recent_memory", "")
                self.recent_memory = data.get("recent_memory", "")
                self.memory_budget_tokens = data.get(
                    "memory_budget_tokens",
                    data.get("memory_budget", self.memory_budget_tokens),
                )
                self.summary_memory_budget_tokens = data.get(
                    "summary_memory_budget_tokens",
                    data.get("summary_memory_budget", self.summary_memory_budget_tokens),
                )
                self.memory_budget_tokens = max(1, int(self.memory_budget_tokens))
                self.summary_memory_budget_tokens = max(1, int(self.summary_memory_budget_tokens))
                self.memory_budget = self.memory_budget_tokens
                self.summary_memory_budget = self.summary_memory_budget_tokens
                self.n_steps = int(data.get("step", 1))
                self.memory_snapshot_files = data.get("memory_snapshot_files", [])
                # Back-compat: older runs may have stored pending lines in recent_memory.
                if self.recent_memory:
                    recent_lines = [ln for ln in self.recent_memory.splitlines() if ln.strip()]
                    keep_recent: list[str] = []
                    move_pending: list[str] = []
                    for ln in recent_lines:
                        if "| Eval: pending |" in ln:
                            move_pending.append(ln)
                        else:
                            keep_recent.append(ln)
                    if move_pending:
                        self.pending_recent_memory = "\n".join(
                            [ln for ln in [self.pending_recent_memory, "\n".join(move_pending)] if ln]
                        ).strip()
                        self.recent_memory = "\n".join(keep_recent).strip()
                pending_lines = [ln for ln in self.pending_recent_memory.splitlines() if ln.strip()]
                if len(pending_lines) > MAX_PENDING_LINES:
                    self.pending_recent_memory = "\n".join(pending_lines[-MAX_PENDING_LINES:]).strip()
                if "summary_memory" not in data and "recent_memory" not in data:
                    await self._rebuild_memory_from_context()
                else:
                    self._refresh_brain_memory()
                self._log_memory_metrics()
                self.last_step_action = data.get("last_step_action", None)
                self.next_goal = data.get("next_goal", "")
                logger.info("Loaded memory from %s", file_name)

    async def _rebuild_memory_from_context(self) -> None:
        self.summary_memory = ""
        self.recent_memory = ""
        self.memory_snapshot_files = []
        for step_id in sorted(self.brain_context.keys()):
            current_state = self.brain_context[step_id].get("current_state", {})
            evaluation = current_state.get("step_evaluate")
            step_goal = current_state.get("next_goal")
            line = f"Step {step_id} | Eval: {evaluation} | Goal: {step_goal}"
            self.recent_memory = "\n".join([ln for ln in [self.recent_memory, line] if ln]).strip()
            if self.token_counter.count(self.recent_memory) > self.memory_budget_tokens:
                await self._summarise_recent_memory(step_override=step_id)
        self._refresh_brain_memory()
        self._log_memory_metrics()

    @time_execution_async("--brain_step")
    async def brain_step(self) -> dict:
        step_id = self.n_steps
        self._step_errors.pop(step_id, None)
        if session_logger:
            session_logger.step_start(step_id, self.next_goal or "初始化任务分析")

        # 初始化步骤计时（如果还没有）
        if not hasattr(self, '_step_timing'):
            self._step_timing = {}
        self._step_timing[step_id] = {
            "step_start": time.time(),
            "brain_start": 0,
            "brain_end": 0,
            "brain_step_end": 0,
        }
        
        step_start_time = time.time()
        prev_step_id = step_id - 1
        
        try:
            # Screenshot timing
            screenshot_start = time.time()
            self._step_timing[step_id]["screenshot_start"] = screenshot_start
            self.previous_screenshot = self.screenshot_annotated
            if capture_target_screenshot is not None:
                screenshot = capture_target_screenshot()
            else:
                screenshot = _take_pyautogui_screenshot()
            screenshot = downscale_screenshot_by_tier(screenshot)
            self.screenshot_annotated = screenshot
            os.makedirs(self.images_dir, exist_ok=True)
            current_screenshot_path = os.path.join(self.images_dir, f"screenshot_{self.n_steps}.png")
            screenshot.save(current_screenshot_path)
            screenshot_end = time.time()
            screenshot_time = screenshot_end - screenshot_start
            self._step_timing[step_id]["screenshot_end"] = screenshot_end
            logger.debug(f"[Timing] Step {step_id}: Screenshot captured in {screenshot_time:.2f}s")

            # 记录截图时间供保存使用
            self._last_screenshot_time = screenshot_time

            # 更新状态窗口 - 截图完成
            self._add_log_window(f"步骤 {step_id}：截图已完成（{screenshot_time:.2f}s）", "timing")
            self._update_timing(step_id, screenshot_time)

            screenshot_dataurl = None
            previous_screenshot_dataurl = None
            if self.screenshot_annotated:
                screenshot_dataurl = screenshot_to_dataurl(self.screenshot_annotated)
            if self.brain_include_previous_screenshot and self.previous_screenshot:
                previous_screenshot_dataurl = screenshot_to_dataurl(self.previous_screenshot)
            info_files = "\n".join(str(item) for item in self.infor_memory) if self.infor_memory else "None"

            def build_state_content(
                read_files_content: Optional[str] = None,
                read_files_list: Optional[list[str]] = None,
            ) -> list[dict]:
                if step_id >= 2:
                    state_content = [
                        {
                            "type": "text",
                            "content": (
                                f"Previous step is {prev_step_id}.\n\n"
                                f"Recorded info files (filenames only):\n{info_files}\n\n"
                                f"Previous Actions Short History:\n{self.brain_memory}\n\n"
                            ),
                        }
                    ]
                else:
                    state_content = [
                        {
                            "type": "text",
                            "content": (
                                "This is the first step.\n\n"
                                "You should provide a JSON with a well-defined goal based on images information. "
                                "The other fields should be default value."
                            ),
                        }
                    ]
                if read_files_content:
                    files_label = ", ".join(read_files_list) if read_files_list else ""
                    read_label = (
                        f"Requested file contents for: {files_label}\n" if files_label else "Requested file contents:\n"
                    )
                    state_content.append(
                        {
                            "type": "text",
                            "content": f"{read_label}{read_files_content}",
                        }
                    )
                if step_id >= 2 and previous_screenshot_dataurl:
                    state_content.append(
                        {
                            "type": "image_url",
                            "image_url": {"url": previous_screenshot_dataurl},
                        }
                    )
                if screenshot_dataurl:
                    state_content.append(
                        {
                            "type": "image_url",
                            "image_url": {"url": screenshot_dataurl},
                        }
                    )
                return state_content

            state_content = build_state_content()
            self.brain_message_manager._remove_last_state_message()
            self.brain_message_manager._remove_last_AIntool_message()
            self.brain_message_manager.add_state_message(state_content)
            brain_messages = self.brain_message_manager.get_messages()

            # Brain model inference timing
            brain_inference_start = time.time()
            self._step_timing[step_id]["brain_start"] = brain_inference_start
            try:
                response = await self.brain_llm.ainvoke(brain_messages)
            finally:
                brain_inference_end = time.time()
                self._step_timing[step_id]["brain_end"] = brain_inference_end
            brain_inference_time = brain_inference_end - brain_inference_start
            logger.debug(f"[Timing] Step {step_id}: Brain model inference completed in {brain_inference_time:.2f}s")
            
            # 记录 Brain 推理时间
            self._last_brain_inference_time = brain_inference_time
            
            # 更新状态窗口 - Brain 推理完成
            self._add_log_window(f"步骤 {step_id}：分析模型推理（{brain_inference_time:.2f}s）", "timing")
            self._add_detail_window(f"分析模型推理：{brain_inference_time:.2f}s")

            # 记录 LLM 响应到会话日志
            if session_logger:
                prompt_tokens, completion_tokens, total_tokens = self._extract_response_token_usage(response)
                session_logger.log_llm_response(
                    "Brain",
                    str(response.content)[:500] if response.content else "N/A",
                    tokens=(prompt_tokens, completion_tokens, total_tokens) if total_tokens else None,
                    elapsed=brain_inference_time
                )

            # Try to use parsed response if available (for local models)
            if hasattr(response, "parsed") and response.parsed is not None:
                logger.debug(f"[Brain] Using response.parsed: %s", type(response.parsed).__name__)
                parsed = response.parsed
            else:
                logger.debug(f"[Brain] response.parsed is None or not available, parsing from content")
                parsed = self.brain_search.parse_response(str(response.content))
            
            logger.debug(f"[Brain] Parsed type: %s, value preview: %s", type(parsed).__name__, str(parsed)[:200])

            parsed, brain_messages = await self.brain_search.maybe_reinvoke(
                parsed,
                build_state_content,
                self.brain_message_manager,
                self.brain_llm,
            )
            if "current_state" not in parsed or "analysis" not in parsed:
                raise ValueError("Brain response missing required fields after read-files handling.")
            self._save_brain_conversation(brain_messages, parsed, step=self.n_steps)
            self.brain_context[self.n_steps] = parsed
            while len(self.brain_context) > MAX_BRAIN_CONTEXT_ENTRIES:
                self.brain_context.popitem(last=False)

            # Check for loop detection
            new_goal = parsed["current_state"]["next_goal"]
            if self._detect_goal_loop(new_goal):
                logger.warning(f"Detected goal loop. Forcing new goal different from recent history.")
                # Modify the next_goal to encourage progress
                parsed["current_state"]["next_goal"] = self._force_goal_progress(new_goal)

            self.next_goal = parsed["current_state"]["next_goal"]
            self.brain_thought = parsed["analysis"]
            self.current_state = parsed["current_state"]

            # Update recent goals for loop detection
            self._update_recent_goals(self.next_goal)

            # Log total brain step time
            brain_step_end = time.time()
            brain_step_total = brain_step_end - step_start_time
            logger.debug(f"[Timing] Step {step_id}: Brain step completed in {brain_step_total:.2f}s")
            
            # 记录 Brain 总时间
            self._last_brain_total_time = brain_step_total
            self._step_timing[step_id]["brain_step_end"] = brain_step_end  # brain_step 结束时间
            
            # 更新状态窗口 - 显示 brain 分析结果和耗时
            self._add_log_window(f"步骤 {step_id}：分析模型处理完成（{brain_step_total:.2f}s）", "timing")
            self._add_detail_window(f"分析模型总耗时：{brain_step_total:.2f}s")
            self._update_status_window(
                step_id,
                self.next_goal[:80] + "..." if len(self.next_goal) > 80 else self.next_goal,
                "running"
            )

            # Finalize the previous step's memory line based on this response's evaluation signal.
            # Keep step N in pending_recent_memory until step (N+1) arrives, so it won't be summarized away.
            if prev_step_id >= 1:
                raw_eval = str(self.current_state.get("step_evaluate", "")).lower()
                if "success" in raw_eval:
                    final_status = "success"
                elif "fail" in raw_eval:
                    final_status = "failed"
                else:
                    final_status = "pending"

                pending_lines = [ln for ln in self.pending_recent_memory.splitlines() if ln.strip()]
                new_pending: list[str] = []
                goal_text: Optional[str] = None
                for ln in pending_lines:
                    if ln.startswith(f"Step {prev_step_id} |"):
                        if "| Goal: " in ln:
                            goal_text = ln.split("| Goal: ", 1)[1].strip()
                        continue
                    new_pending.append(ln)
                self.pending_recent_memory = "\n".join(new_pending).strip()

                if goal_text is not None:
                    final_line = f"Step {prev_step_id} | Eval: {final_status} | Goal: {goal_text}"
                    recent_lines = [ln for ln in self.recent_memory.splitlines() if ln.strip()]
                    recent_lines = [ln for ln in recent_lines if not ln.startswith(f"Step {prev_step_id} |")]
                    recent_lines.append(final_line)
                    self.recent_memory = "\n".join(recent_lines).strip()
                    recent_tokens = self.token_counter.count(self.recent_memory)
                    hard_limit = int(self.memory_budget_tokens * self.memory_hard_ratio)
                    warn_limit = int(self.memory_budget_tokens * self.memory_warn_ratio)
                    if recent_tokens > hard_limit:
                        await self._summarise_recent_memory(step_override=prev_step_id)
                    elif recent_tokens > warn_limit:
                        logger.info(
                            "[Memory] Recent memory at %.0f%% of budget (%d/%d tokens). Compression will trigger soon.",
                            (recent_tokens / self.memory_budget_tokens) * 100,
                            recent_tokens,
                            self.memory_budget_tokens,
                        )
                        self._refresh_brain_memory()
                    else:
                        self._refresh_brain_memory()
                else:
                    self._refresh_brain_memory()
            self._log_memory_metrics()

        except Exception as e:
            now = time.time()
            timing = self._step_timing.get(step_id, {})
            if timing.get("brain_start") and not timing.get("brain_end"):
                timing["brain_end"] = now
            timing["brain_step_end"] = now
            timing["brain_error"] = str(e)[:500]
            self._step_errors[step_id] = f"Brain error: {str(e)[:500]}"
            logger.exception("[Brain] Unexpected error in brain_step.")
            return {"Brain_text": {"step_evaluate": "unknown", "reason": str(e)}}

    @time_execution_async("--actor_step")
    async def actor_step(self, step_info: Optional[AgentStepInfo] = None) -> None:
        step_id = self.n_steps
        state = ""
        model_output = None
        result: list[ActionResult] = []
        prev_step_id = step_id - 1
        actor_step_start = time.time()
        self.wait_this_step = False
        
        # 初始化当前步骤的计时（如果还没有）
        if not hasattr(self, '_step_timing'):
            self._step_timing = {}
        if step_id not in self._step_timing:
            self._step_timing[step_id] = {"step_start": actor_step_start}
        
        # 记录 actor_step 时间点
        self._step_timing[step_id]["actor_start"] = actor_step_start
        self._step_timing[step_id]["actor_inference_start"] = 0
        self._step_timing[step_id]["actor_inference_end"] = 0
        self._step_timing[step_id]["action_exec_start"] = 0
        self._step_timing[step_id]["action_exec_end"] = 0
        self._step_timing[step_id]["actor_end"] = 0
        
        try:
            self.save_memory()
            info_files = "\n".join(str(item) for item in self.infor_memory) if self.infor_memory else "None"

            # Debug: Log brain_thought and next_goal before building state_content
            logger.debug("[Actor] step_id=%d, brain_thought='%s', next_goal='%s'",
                        step_id,
                        str(self.brain_thought)[:100] if self.brain_thought else 'None',
                        str(self.next_goal)[:100] if self.next_goal else 'None')

            if self.n_steps >= 2:
                state_content = [
                    {
                        "type": "text",
                        "content": (
                            f"Recorded info files (filenames only): {info_files}\n\n"
                            f"Analysis to the current screen is: {self.brain_thought}.\n\n"
                            f"Your goal to achieve in this step is: {self.next_goal}\n\n"
                        ),
                    },
                    {"type": "image_url", "image_url": {"url": screenshot_to_dataurl(self.screenshot_annotated)}},
                ]
            else:
                state_content = [
                    {
                        "type": "text",
                        "content": (
                            f"Analysis to the current screen is: {self.brain_thought}. "
                            f"Your goal to achieve in this step is: {self.next_goal}"
                        ),
                    },
                    {"type": "image_url", "image_url": {"url": screenshot_to_dataurl(self.screenshot_annotated)}},
                ]

            self.actor_message_manager._remove_last_AIntool_message()
            self.actor_message_manager._remove_last_state_message()
            self.actor_message_manager.add_state_message(state_content, step_info=step_info)

            actor_messages = self.actor_message_manager.get_messages()
            
            # Debug: Log actor message structure
            logger.debug("[Actor] Input messages count: %d", len(actor_messages))
            for i, msg in enumerate(actor_messages[-3:]):  # Last 3 messages
                logger.debug("[Actor] Message %d: %s - content preview: %s", 
                           i, type(msg).__name__, 
                           str(msg.content)[:200] if hasattr(msg, 'content') else 'N/A')

            # Actor model inference timing
            actor_inference_start = time.time()
            self._step_timing[step_id]["actor_inference_start"] = actor_inference_start
            try:
                model_output, raw = await self.get_next_action(actor_messages)
            finally:
                actor_inference_end = time.time()
                self._step_timing[step_id]["actor_inference_end"] = actor_inference_end
            actor_inference_time = actor_inference_end - actor_inference_start
            logger.debug(f"[Timing] Step {step_id}: Actor model inference completed in {actor_inference_time:.2f}s")
            
            # 记录 Actor 推理时间
            self._last_actor_inference_time = actor_inference_time
            
            # 更新状态窗口 - Actor 推理完成
            self._add_log_window(f"步骤 {step_id}：动作模型推理（{actor_inference_time:.2f}s）", "timing")
            self._add_detail_window(f"动作模型推理：{actor_inference_time:.2f}s")

            # 记录 LLM 响应到会话日志
            if session_logger:
                # 尝试提取 token 信息
                prompt_tokens, completion_tokens, total_tokens = None, None, None
                if hasattr(model_output, 'response_metadata'):
                    prompt_tokens, completion_tokens, total_tokens = self._extract_response_token_usage(model_output)
                elif hasattr(raw, 'response_metadata'):
                    prompt_tokens, completion_tokens, total_tokens = self._extract_response_token_usage(raw)

                session_logger.log_llm_response(
                    "Actor",
                    str(model_output.action)[:500] if model_output and hasattr(model_output, 'action') else "N/A",
                    tokens=(prompt_tokens, completion_tokens, total_tokens) if total_tokens else None,
                    elapsed=actor_inference_time
                )

            self.last_goal = self.next_goal
            if self.register_new_step_callback:
                self.register_new_step_callback(state, model_output, self.n_steps)
            self._save_actor_conversation(actor_messages, model_output, step=self.n_steps)

            self.actor_message_manager._remove_last_state_message()
            self.actor_message_manager.add_model_output(model_output)

            previous_step_action = self.last_step_action
            self.last_step_action = (
                [action.model_dump(exclude_unset=True) for action in model_output.action] if model_output else []
            )

            # Action execution timing - 为每个动作单独计时
            action_execution_start = time.time()
            self._step_timing[step_id]["action_exec_start"] = action_execution_start
            # 更新状态窗口 - 显示正在执行动作
            self._update_status_window(
                step_id,
                f"正在执行 {len(model_output.action) if model_output else 0} 个动作",
                "running"
            )
            self._add_log_window(f"步骤 {step_id}：正在执行 {len(model_output.action) if model_output else 0} 个动作", "info")
            if model_output and hasattr(model_output, 'action'):
                for index, action in enumerate(model_output.action, start=1):
                    action_dict = action.model_dump(exclude_unset=True)
                    for action_name, action_params in action_dict.items():
                        if action_params is not None:
                            params_text = json.dumps(action_params, ensure_ascii=False, default=str)
                            params_text = params_text[:120] + "..." if len(params_text) > 120 else params_text
                            self._add_detail_window(f"动作 {index}: {action_name} {params_text}")
            try:
                action_list = model_output.action if model_output else []
                action_guard_message = (
                    self._check_text_input_focus(action_list, previous_step_action)
                    or self._check_searchable_selection_strategy(action_list)
                    or self._check_repeated_actions(action_list)
                )
                if action_guard_message:
                    logger.warning("[ActionGuard] Step %s: %s", step_id, action_guard_message)
                    result = [ActionResult(error=action_guard_message, include_in_memory=True)]
                    self._step_errors[step_id] = action_guard_message
                    self._step_timing[step_id]["repeat_guard"] = True
                else:
                    result = await self.controller.multi_act(action_list)
                    self._remember_action_attempt(action_list)
            finally:
                action_execution_end = time.time()
                self._step_timing[step_id]["action_exec_end"] = action_execution_end
            action_execution_time = action_execution_end - action_execution_start
            logger.debug(f"[Timing] Step {step_id}: Action execution completed in {action_execution_time:.2f}s")

            # 记录动作执行时间
            self._last_action_execution_time = action_execution_time

            # 更新状态窗口 - 显示动作执行完成和耗时
            self._add_log_window(f"步骤 {step_id}：动作执行完成（{action_execution_time:.2f}s）", "timing")
            self._add_detail_window(f"动作执行：{action_execution_time:.2f}s")
            
            # 记录 actor_step 结束时间
            actor_step_end = time.time()
            self._step_timing[step_id]["actor_end"] = actor_step_end
            
            # 计算步骤总时间（从步骤开始到 actor 结束）
            step_total_time = actor_step_end - self._step_timing[step_id].get("step_start", actor_step_end)
            self._step_timing[step_id]["step_total"] = step_total_time
            
            # 显示动作详情
            if model_output and hasattr(model_output, 'action'):
                for action in model_output.action:
                    action_dict = action.model_dump(exclude_unset=True)
                    for action_name, action_params in action_dict.items():
                        if action_params is not None:
                            # 简化参数显示
                            params_str = str(action_params)[:60] + "..." if len(str(action_params)) > 60 else str(action_params)
                            self._add_detail_window(f"  -> {action_name}: {params_str}")

            # 记录执行的动作到会话日志（每个动作平均耗时）
            if session_logger and model_output and hasattr(model_output, 'action'):
                actions_count = len(model_output.action)
                avg_action_time = action_execution_time / actions_count if actions_count > 0 else 0
                for i, action in enumerate(model_output.action):
                    action_dict = action.model_dump(exclude_unset=True)
                    # 获取动作名称：从 dict 的 key 中获取（第一个非 None 的 key）
                    action_name = "unknown"
                    for key, val in action_dict.items():
                        if val is not None:
                            action_name = key
                            break

                    # 美化动作名称显示
                    session_logger.log_action(action_name, action_dict, elapsed=avg_action_time)
            
            self._last_result = result

            if len(self.last_step_action) == 0:
                self.wait_this_step = True
            elif "wait" in str(self.last_step_action[0]):
                self.wait_this_step = True
            else:
                self.wait_this_step = False
            if self.last_step_action and not self.wait_this_step:
                # 计时：内存更新
                memory_update_start = time.time()
                await self._update_memory()
                self.save_memory()
                memory_update_time = time.time() - memory_update_start
                self._step_timing[step_id]["memory_update_time"] = memory_update_time

        except Exception as e:
            now = time.time()
            timing = self._step_timing.get(step_id, {})
            if timing.get("actor_inference_start") and not timing.get("actor_inference_end"):
                timing["actor_inference_end"] = now
            if timing.get("action_exec_start") and not timing.get("action_exec_end"):
                timing["action_exec_end"] = now
            timing["actor_end"] = now
            timing["actor_error"] = str(e)[:500]
            self._step_errors[step_id] = f"Actor error: {str(e)[:500]}"
            result = await self._handle_step_error(e)
            self._last_result = result
            # 更新状态窗口 - 显示错误
            self._update_status_window(step_id, f"错误：{str(e)[:40]}", "error")
            self._add_log_window(f"步骤 {step_id} 失败：{str(e)[:50]}...", "error")
        finally:
            # Check if the task is complete based on Brain's next_goal
            # Brain should set next_goal to "[TASK_COMPLETE] ..." when the task is done
            # This check must happen even if result is empty (e.g., when no actions are needed)
            if self.next_goal and "[TASK_COMPLETE]" in self.next_goal:
                # Set is_done=True for all results to signal task completion
                if result:
                    for r in result:
                        r.is_done = True
                else:
                    # If no actions were executed but task is complete, create a dummy result
                    result = [ActionResult(is_done=True, extracted_content="Task completed")]
                logger.info(f"[Task Complete] Brain signaled task completion at step {step_id}")

            # Always create history item, even if result is empty
            if result or (self.next_goal and "[TASK_COMPLETE]" in self.next_goal):
                # 计时：历史记录创建
                history_start = time.time()
                self._make_history_item(model_output, state, result)
                history_time = time.time() - history_start
                self._step_timing[step_id]["history_create_time"] = history_time

            # 内存更新时间（在 try 块中已经执行）
            # 注意：_update_memory 和 save_memory 在 try 块中执行，需要在那里计时

            if not self.wait_this_step:
                self.n_steps += 1

            # Log total actor step time
            actor_step_total = time.time() - actor_step_start
            logger.debug(f"[Timing] Step {step_id}: Actor step completed in {actor_step_total:.2f}s")

            # 计算整个步骤的总时间（从 brain_step 开始到 actor_step 结束）
            step_total_time = time.time() - self._step_timing.get(step_id, {}).get("step_start", time.time())
            logger.debug(f"[Timing] Step {step_id}: Total step time: {step_total_time:.2f}s")

            # 更新状态窗口并计时
            status_update_start = time.time()
            step_failed = step_id in getattr(self, "_step_errors", {})
            step_status = "error" if step_failed else "success"
            self._add_log_window(
                f"步骤 {step_id}：{'失败' if step_failed else '完成'}（{step_total_time:.2f}s）",
                step_status,
            )
            self._add_detail_window(f"步骤 {step_id} 总计：{step_total_time:.2f}s")
            self._add_detail_window("---")
            status_update_time = time.time() - status_update_start
            self._step_timing[step_id]["status_update_time"] = status_update_time

            # 保存步骤记录（使用整个步骤的总时间）并计时
            record_save_start = time.time()
            self._save_step_record(step_id, step_total_time)
            record_save_time = time.time() - record_save_start
            self._step_timing[step_id]["record_save_time"] = record_save_time

            # 记录步骤完成到会话日志并计时
            session_log_time = 0
            if session_logger:
                session_log_start = time.time()
                session_logger.step_end(success=not step_failed)
                session_log_time = time.time() - session_log_start
            self._step_timing[step_id]["session_log_time"] = session_log_time

            # 更新状态窗口 - 显示步骤完成并计时
            final_status_update_start = time.time()
            self._update_status_window(
                step_id,
                self.next_goal[:50] + "..." if len(self.next_goal) > 50 else self.next_goal,
                step_status,
            )
            final_status_update_time = time.time() - final_status_update_start
            self._step_timing[step_id]["final_status_update_time"] = final_status_update_time

    async def _handle_step_error(self, error: Exception) -> list[ActionResult]:
        include_trace = logger.isEnabledFor(logging.DEBUG)
        error_msg = AgentError.format_error(error, include_trace=include_trace)
        prefix = f"Result failed {self.consecutive_failures + 1}/{self.max_failures} times:\n "

        if isinstance(error, (ValidationError, ValueError)):
            logger.error("%s%s", prefix, error_msg)
            if "Max token limit reached" in error_msg:
                self.actor_message_manager.max_input_tokens -= 500
                logger.info(
                    "Reducing agent max input tokens: %s", self.actor_message_manager.max_input_tokens
                )
                self.actor_message_manager.cut_messages()
            elif "Could not parse response" in error_msg:
                error_msg += "\n\nReturn a valid JSON object with the required fields."
            self.consecutive_failures += 1

        elif isinstance(error, RateLimitError):
            logger.warning("%s%s", prefix, error_msg)
            await asyncio.sleep(self.retry_delay)
            self.consecutive_failures += 1

        else:
            logger.error("%s%s", prefix, error_msg)
            self.consecutive_failures += 1

        return [ActionResult(error=error_msg, include_in_memory=True)]

    def _make_history_item(
        self,
        model_output: AgentOutput | None,
        state: str,
        result: list[ActionResult],
    ) -> None:
        history_item = AgentHistory(
            model_output=model_output,
            result=result,
            state=state,
        )
        self.history.history.append(history_item)

    @time_execution_async("--get_next_action")
    async def get_next_action(self, input_messages: list[BaseMessage]) -> AgentOutput:
        """
        Build a structured_llm approach on top of actor_llm.
        """
        response: dict[str, Any] = await self.actor_llm.ainvoke(input_messages)
        
        # Debug: Log response structure
        logger.debug("[Actor] Raw response type: %s", type(response).__name__)
        logger.debug("[Actor] Has 'parsed' attr: %s", hasattr(response, "parsed"))
        if hasattr(response, "parsed"):
            logger.debug("[Actor] response.parsed = %s", response.parsed)
        logger.debug("[Actor] response.content (first 500 chars): %s", str(response.content)[:500] if hasattr(response, "content") else "N/A")
        
        # Try to use parsed response if available (for local models)
        if hasattr(response, "parsed") and response.parsed is not None:
            logger.debug("[Actor] Using response.parsed")
            record = response.parsed
        else:
            logger.debug("[Actor] response.parsed is None, parsing from content")
            record = str(response.content)
            try:
                record = json.loads(record)
                logger.debug("[Actor] Parsed from content: %s", record)
            except json.JSONDecodeError as e:
                logger.error("[Actor] Failed to parse JSON from content: %s", e)
                logger.error("[Actor] Raw content: %s", str(response.content)[:1000])
                raise ValueError(f"Failed to parse actor response as JSON: {e}")

        # Ensure record is a dict
        if not isinstance(record, dict):
            logger.warning("Parsed record is not a dict: %s", type(record))
            record = {"action": record} if isinstance(record, list) else {}

        # Check if action list is empty - this indicates the model didn't generate any actions
        action_list = record.get("action", [])
        
        # Handle common model output variations
        if not action_list:
            # Try "actions" (plural) if "action" is not found
            if "actions" in record:
                logger.info("[Actor] Model used 'actions' (plural), converting to 'action'")
                action_list = record.get("actions", [])
                record["action"] = action_list
            
        if not action_list:
            logger.warning("Model returned empty action list. Raw response: %s", record)
            logger.warning("[Actor] Full record keys: %s", list(record.keys()) if isinstance(record, dict) else "N/A")
            raise ValueError(
                "Model returned empty action list. "
                "Please output at least one action in the format: "
                '{"action": [{"action_name": {"param1": "value1"}}]}'
            )

        # Validate action format - each action should be a dict
        normalized_actions = []
        has_record_info = False  # 标记是否有 record_info 动作被执行
        for i, action in enumerate(action_list):
            # Skip non-dict items (like raw floats from position arrays)
            if not isinstance(action, dict):
                logger.warning(f"Skipping invalid action item {i}: {action} (type: {type(action)})")
                continue

            if not action:
                normalized_actions.append(action)
                continue

            outer_key = list(action.keys())[0]
            inner_value = action[outer_key] if isinstance(action, dict) else {}

            # Skip if outer_key looks like a position coordinate (float/int)
            if isinstance(outer_key, (float, int)):
                logger.warning(f"Skipping action with numeric key: {outer_key}")
                continue

            # Handle model output format: {"action": "Click", "position": [16, 281]}
            # Convert to expected format: {"Click": {"position": [16, 281]}}
            if outer_key == "action" and isinstance(inner_value, str):
                action_name = inner_value
                # Collect all other fields as parameters
                params = {k: v for k, v in action.items() if k != "action"}
                normalized_action = {action_name: params}
                logger.debug(f"[Actor] Converting action format: {action} -> {normalized_action}")
                action = normalized_action
                outer_key = action_name
                inner_value = params

            if outer_key == "record_info" and isinstance(inner_value, dict):
                information_stored = inner_value.get("text", "")
                file_name = inner_value.get("file_name", "")
                saved_name = self.record_store.save(
                    information_stored,
                    file_name,
                    screenshot=self.screenshot_annotated,
                    step=self.n_steps,
                )
                if saved_name and saved_name not in self.infor_memory:
                    self.infor_memory.append(saved_name)
                has_record_info = True
                # record_info 只记录到日志，不添加到动作列表中
                continue
            normalized_actions.append(action)

        # If no valid actions after filtering, raise error (unless only record_info actions were present)
        if not normalized_actions and not has_record_info:
            logger.error(f"No valid actions found after filtering. Original: {action_list}")
            raise ValueError(
                f"No valid actions found. Model output may be malformed. "
                f"Expected format: [{{\"action_name\": {{\"param\": \"value\"}}}}], "
                f"got: {action_list}"
            )
        
        normalized_actions = self._remove_redundant_select_all_before_input(normalized_actions)
        normalized_actions = self._limit_compact_selector_scroll(normalized_actions)
        normalized_actions = self._complete_direct_text_edit_actions(normalized_actions)
        parsed: AgentOutput | None = AgentOutput(action=normalized_actions)

        self._log_response(parsed)
        return parsed, record

    def _log_response(self, response: AgentOutput) -> None:
        if "Success" in self.current_state["step_evaluate"]:
            emoji = "OK"
        elif "Failed" in self.current_state["step_evaluate"]:
            emoji = "FAIL"
        else:
            emoji = "UNKNOWN"
        logger.info("%s Eval: %s", emoji, self.current_state["step_evaluate"])
        logger.info("Memory: %s", self.brain_memory)
        logger.info("Goal to achieve this step: %s", self.next_goal)
        for i, action in enumerate(response.action):
            action_payload = action.model_dump(exclude_unset=True)
            logger.info(
                "Action %s/%s: %s",
                i + 1,
                len(response.action),
                json.dumps(action_payload, ensure_ascii=False, default=str),
            )

    # ========== 以下方法已禁用，不再保存 LLM 对话记录 ==========
    # 如需启用，请注释掉下面的 return 语句
    
    def _save_brain_conversation(
        self,
        input_messages: list[BaseMessage],
        response: Any,
        step: int,
    ) -> None:
        """
        Write all the Brain agent conversation into a file.
        DISABLED: To save resources and reduce file clutter.
        """
        # DISABLED: Brain conversation logging is disabled by default
        # To re-enable: remove the 'return' statement below
        return
        
        if not self.save_brain_conversation_path:
            return
        file_name = f"{self.save_brain_conversation_path}_brain_{step}.txt"
        os.makedirs(os.path.dirname(file_name), exist_ok=True) if os.path.dirname(file_name) else None

        with open(file_name, "w", encoding=self.save_brain_conversation_path_encoding) as f:
            self._write_messages_to_file(f, input_messages)
            if response is not None:
                self._write_response_to_file(f, response)

        logger.info("Brain conversation saved to: %s", file_name)

    def _save_actor_conversation(
        self,
        input_messages: list[BaseMessage],
        response: Any,
        step: int,
    ) -> None:
        """
        Write all the Actor agent conversation into a file.
        DISABLED: To save resources and reduce file clutter.
        """
        # DISABLED: Actor conversation logging is disabled by default
        # To re-enable: remove the 'return' statement below
        return
        
        if not self.save_actor_conversation_path:
            return
        file_name = f"{self.save_actor_conversation_path}_actor_{step}.txt"
        os.makedirs(os.path.dirname(file_name), exist_ok=True) if os.path.dirname(file_name) else None

        with open(file_name, "w", encoding=self.save_actor_conversation_path_encoding) as f:
            self._write_messages_to_file(f, input_messages)
            if response is not None:
                self._write_response_to_file(f, response)

        logger.info("Actor conversation saved to: %s", file_name)

    def _write_messages_to_file(self, f: Any, messages: list[BaseMessage]) -> None:
        for message in messages:
            f.write(f"\n{message.__class__.__name__}\n{'-'*40}\n")
            if isinstance(message.content, list):
                for item in message.content:
                    if isinstance(item, dict):
                        if item.get("type") == "text":
                            txt = item.get("content") or item.get("text", "")
                            f.write(f"[Text Content]\n{txt.strip()}\n\n")
                        elif item.get("type") == "image_url":
                            image_url = item["image_url"]["url"]
                            f.write(f"[Image URL]\n{image_url[:100]}...\n\n")
            else:
                f.write(f"{str(message.content)}\n\n")
            f.write("\n" + "=" * 60 + "\n")

    def _write_response_to_file(self, f: Any, response: Any) -> None:
        f.write("RESPONSE\n")
        f.write(str(response) + "\n")
        f.write("\n" + "=" * 60 + "\n")

    def _log_agent_run(self) -> None:
        logger.info("Starting task: %s", self.task)

    def _init_step_log_file(self) -> None:
        """初始化步骤记录文件（每次运行前清空）"""
        self._init_step_record_json()
        if self._step_log_path:
            step_log_dir = os.path.dirname(self._step_log_path)
            if step_log_dir:
                os.makedirs(step_log_dir, exist_ok=True)
            # 清空文件（覆盖模式）
            with open(self._step_log_path, 'w', encoding='utf-8') as f:
                # 写入文件头注释
                f.write("# 步骤日志\n")
                f.write("# 每次任务执行前自动清空，每完成一步自动记录\n")
                f.write("=" * 80 + "\n\n")
            logger.info("步骤日志文件已初始化：%s", self._step_log_path)
        else:
            logger.debug("未设置步骤日志路径，跳过初始化")

    def _init_step_record_json(self) -> None:
        """初始化固定 JSON 步骤记录文件（每次运行前清空）"""
        self._step_records = []
        data = {
            "任务": self.original_task,
            "开始时间": datetime.now().isoformat(),
            "更新时间": datetime.now().isoformat(),
            "智能体ID": self.agent_id,
            "步骤记录": [],
            "动作数量": 0,
            "任务总结": "",
        }
        try:
            self._step_record_json_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self._step_record_json_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            logger.info("步骤 JSON 记录已初始化：%s", self._step_record_json_path)
        except Exception as e:
            logger.warning("初始化步骤 JSON 记录失败：%s", e)

    def _clear_step_log_file(self) -> None:
        """清空步骤记录文件（任务结束或中断时调用）"""
        if self._step_log_path:
            try:
                with open(self._step_log_path, 'w', encoding='utf-8') as f:
                    pass  # 完全清空，不写入任何内容
                logger.info("步骤日志文件已清空：%s", self._step_log_path)
            except Exception as e:
                logger.debug(f"清空步骤日志失败：{e}")

    async def run(self, max_steps: int = 100) -> AgentHistoryList:
        run_start_time = time.time()
        final_status = "unknown"
        stop_reason = "unknown"

        try:
            self._log_agent_run()

            # 初始化步骤记录文件（每次运行前清空）
            self._init_step_log_file()

            # 更新状态窗口
            self._update_status_window(0, "正在初始化...", "running")
            self._add_log_window(f"任务：{self.task[:50]}...", "info")
            self._add_log_window("正在启动智能体...", "info")

            # 设置任务描述到窗口
            if self._status_window:
                from src.utils.status_window import set_task
                set_task(self.task)

            if self.planner_llm and not self.resume:
                await self.edit()

            final_status = "success"
            for step in range(max_steps):
                # 检查停止标志
                if self._stopped:
                    final_status = "stopped"
                    stop_reason = "user_stopped"
                    # 用户停止，清空步骤日志
                    self._clear_step_log_file()
                    break

                if self.resume:
                    await self.load_memory()
                    self.resume = False
                if self._too_many_failures():
                    final_status = "max_failures"
                    stop_reason = "max_failures"
                    # 达到最大失败次数，清空步骤日志
                    self._clear_step_log_file()
                    break
                if not await self._handle_control_flags():
                    final_status = "stopped"
                    stop_reason = "control_flag"
                    # 控制标志停止，清空步骤日志
                    self._clear_step_log_file()
                    break

                # 更新步骤信息到状态窗口
                self._update_status_window(
                    self.n_steps,
                    getattr(self, 'next_goal', f'步骤 {self.n_steps}'),
                    "running"
                )

                await self.brain_step()
                await self.actor_step()

                if self.history.is_done():
                    logger.info("Task completed successfully")
                    self._update_status_window(self.n_steps, "任务完成", "success")
                    self._add_log_window("任务已成功完成", "success")
                    if self.register_done_callback:
                        self.register_done_callback(self.history)
                    final_status = "success"
                    stop_reason = "task_completed"
                    # 任务完成，清空步骤日志
                    self._clear_step_log_file()
                    break
                if self.step_delay > 0:
                    await asyncio.sleep(self.step_delay)
            else:
                logger.info("Failed to complete task in maximum steps")
                final_status = "max_steps"
                stop_reason = "max_steps_reached"
                self._update_status_window(max_steps, "已达到最大步骤数", "warning")
                self._add_log_window("已达到最大步骤数", "warning")
                # 达到最大步骤，清空步骤日志
                self._clear_step_log_file()

            # 计算总运行时间
            total_run_time = time.time() - run_start_time
            logger.info(f"Total run time: {total_run_time:.2f}s")
            self._add_log_window(f"总执行耗时：{total_run_time:.2f}s", "timing")

            # 记录会话结束
            if session_logger:
                session_logger.session_end(final_status)

            # 完成会话并保存日志
            if self._status_window:
                self._finalize_session(stop_reason, total_run_time)

            # 非正常结束（用户停止、错误等），清空步骤日志
            if final_status in ["stopped", "error"]:
                self._clear_step_log_file()

            return self.history
        except (Exception, KeyboardInterrupt, asyncio.CancelledError) as e:
            logger.exception("Error running agent")
            final_status = "error"
            stop_reason = f"error: {str(e)[:50]}"
            self._update_status_window(self.n_steps, f"错误：{str(e)[:30]}", "error")
            self._add_log_window(f"错误：{str(e)[:50]}...", "error")

            # 计算总运行时间
            total_run_time = time.time() - run_start_time

            if session_logger:
                session_logger.session_end("error")

            # 完成会话并保存日志（即使出错）
            if self._status_window:
                self._finalize_session(stop_reason, total_run_time)

            # 发生错误，清空步骤日志
            self._clear_step_log_file()

            # 不再 raise，让调用者通过返回值判断状态
            return self.history

    async def edit(self):
        result = await self.planner.edit_task()
        self._set_new_task(result.raw_text, result.payload)

    PREFIX = "The overall user's task is: "
    SUFFIX = "The step by step plan is: "

    def _set_new_task(self, generated_plan: str, plan_payload: Optional[dict] = None) -> None:
        """
        Build the final task string:
            "The overall plan is: <original task>\n\n<generated plan>"
        and update every MessageManager in one go.
        """
        plan_text = generated_plan
        if isinstance(plan_payload, dict):
            plan_text = self._format_plan_payload(plan_payload)
        if generated_plan.startswith(self.PREFIX):
            final_task = generated_plan
        else:
            final_task = f"{self.PREFIX}{self.original_task}\n{self.SUFFIX}\n{plan_text}"

        if self.use_skills and self.available_skills:
            selected = []
            if isinstance(plan_payload, dict):
                selected = plan_payload.get("selected_skills", []) or []
            if isinstance(selected, list):
                selected = [str(s) for s in selected if isinstance(s, str) and s.strip()]
            else:
                selected = []

            self.selected_skills = selected
            if self.selected_skills:
                logger.info("Planner selected skills: %s", ", ".join(self.selected_skills))
            else:
                logger.info("Planner selected no skills.")
            skill_contents = load_skill_contents(
                self.available_skills,
                self.selected_skills,
                max_chars=self.skills_max_chars or None,
            )
            self.skill_context = format_skill_context(skill_contents)
            if self.skill_context:
                final_task = (
                    f"{final_task}\n\nSelected skills (planner-chosen):\n"
                    f"{self.skill_context}"
                )

        self.task = final_task
        self.initiate_messages()

    def _format_plan_payload(self, payload: dict) -> str:
        lines: list[str] = []
        iteration = payload.get("iteration_info")
        if isinstance(iteration, dict):
            current = iteration.get("current_iteration")
            total = iteration.get("total_iterations")
            if current and total:
                lines.append(f"Iteration: {current}/{total}")

        search_summary = payload.get("search_summary")
        if isinstance(search_summary, str) and search_summary.strip():
            lines.append(f"Search summary: {search_summary.strip()}")

        selected = payload.get("selected_skills")
        if isinstance(selected, list):
            selected_clean = [str(s) for s in selected if isinstance(s, str) and s.strip()]
            if selected_clean:
                lines.append(f"Selected skills: {', '.join(selected_clean)}")

        natural_plan = payload.get("natural_language_plan")
        if isinstance(natural_plan, str) and natural_plan.strip():
            lines.append("Plan:")
            lines.append(natural_plan.strip())
        else:
            steps = payload.get("step_by_step_plan")
            if isinstance(steps, list) and steps:
                lines.append("Plan:")
                for step in steps:
                    if not isinstance(step, dict):
                        continue
                    desc = step.get("description") or ""
                    info = step.get("important_search_info") or ""
                    if not desc:
                        continue
                    if info:
                        lines.append(f"- {desc} (search: {info})")
                    else:
                        lines.append(f"- {desc}")

        return "\n".join(lines) if lines else json.dumps(payload, ensure_ascii=False)

    def _too_many_failures(self) -> bool:
        if self.consecutive_failures >= self.max_failures:
            logger.error("Stopping due to %s consecutive failures", self.max_failures)
            return True
        return False

    async def _handle_control_flags(self) -> bool:
        if self._stopped:
            logger.info("Agent stopped")
            return False

        while self._paused:
            await asyncio.sleep(0.2)
            if self._stopped:
                return False

        return True

    def stop(self, reason: Optional[str] = None) -> None:
        if reason:
            logger.warning("Stopping agent: %s", reason)
        self._stopped = True
        # 更新状态窗口显示停止原因
        if self._status_window and reason:
            self._add_log_window(f"智能体已停止：{reason}", "warning")

    def save_history(self, file_path: Optional[str | Path] = None) -> None:
        if not file_path:
            file_path = "AgentHistory.json"
        self.history.save_to_file(file_path)

    def _update_status_window(self, step_number: int, goal: str, status: str) -> None:
        """更新状态窗口（如果启用）"""
        if self._status_window:
            try:
                self._status_window.update_step(step_number, goal, status)
            except Exception as e:
                logger.debug(f"Failed to update status window: {e}")

    def _add_log_window(self, message: str, level: str = "info") -> None:
        """添加日志到状态窗口（如果启用）"""
        if self._status_window:
            try:
                self._status_window.add_log(message, level)
            except Exception as e:
                logger.debug(f"Failed to add log to status window: {e}")

    def _add_detail_window(self, message: str) -> None:
        """添加详情到状态窗口（如果启用）"""
        if self._status_window:
            try:
                self._status_window.add_detail(message)
            except Exception as e:
                logger.debug(f"Failed to add detail to status window: {e}")

    def _update_timing(self, step_number: int, elapsed: float) -> None:
        """更新耗时显示（如果启用）"""
        if self._status_window:
            try:
                self._status_window.update_timing(elapsed)
            except Exception as e:
                logger.debug(f"Failed to update timing: {e}")

    def _save_step_record(self, step_id: int, step_total_time: float) -> None:
        """保存步骤记录（如果启用）"""
        try:
            # 从 _step_timing 获取当前步骤的时间记录
            timing = getattr(self, '_step_timing', {}).get(step_id, {})

            # 计算各阶段时间（基于时间戳差值）
            screenshot_time = 0
            brain_inference_time = 0
            brain_other_time = 0
            actor_inference_time = 0
            action_execution_time = 0
            memory_update_time = 0
            history_create_time = 0
            record_save_time = 0
            other_overhead_time = 0

            if timing:
                # 截图时间
                if timing.get("screenshot_start") and timing.get("screenshot_end"):
                    screenshot_time = timing["screenshot_end"] - timing["screenshot_start"]

                # Brain 推理时间
                if timing.get("brain_start") and timing.get("brain_end"):
                    brain_inference_time = timing["brain_end"] - timing["brain_start"]

                # Brain 其他时间（截图结束到 brain 开始 + brain 结束到 brain_step 结束）
                if timing.get("screenshot_end") and timing.get("brain_start"):
                    brain_other_time += timing["brain_start"] - timing["screenshot_end"]
                if timing.get("brain_step_end") and timing.get("brain_end"):
                    brain_other_time += timing["brain_step_end"] - timing["brain_end"]

                # Actor 推理时间
                if timing.get("actor_inference_start") and timing.get("actor_inference_end"):
                    actor_inference_time = timing["actor_inference_end"] - timing["actor_inference_start"]

                # 动作执行时间
                if timing.get("action_exec_start") and timing.get("action_exec_end"):
                    action_execution_time = timing["action_exec_end"] - timing["action_exec_start"]

                # 内存更新时间（如果有记录）
                memory_update_time = timing.get("memory_update_time", 0)

                # 历史记录创建时间（如果有记录）
                history_create_time = timing.get("history_create_time", 0)

                # 记录保存时间（如果有记录）
                record_save_time = timing.get("record_save_time", 0)

                # 状态窗口更新时间（如果有记录）
                status_update_time = timing.get("status_update_time", 0)

                # 会话日志记录时间（如果有记录）
                session_log_time = timing.get("session_log_time", 0)

                # 最终状态窗口更新时间（如果有记录）
                final_status_update_time = timing.get("final_status_update_time", 0)

            # 使用传入的 step_total_time（从 actor_step 结束时计算）
            # 如果为 0 则从 timing 获取
            if step_total_time <= 0 and timing.get("step_total"):
                step_total_time = timing["step_total"]
            step_error = getattr(self, "_step_errors", {}).get(step_id, "")
            if timing.get("brain_error") and not step_error:
                step_error = f"Brain error: {timing['brain_error']}"
            if timing.get("actor_error") and not step_error:
                step_error = f"Actor error: {timing['actor_error']}"

            # 计算已知时间总和（不包括系统开销）
            known_total = (
                screenshot_time + brain_inference_time + brain_other_time +
                actor_inference_time + action_execution_time +
                memory_update_time + history_create_time + record_save_time +
                status_update_time + session_log_time + final_status_update_time
            )

            # 剩余的其他开销（主要是 Python 代码执行、循环迭代等基础开销）
            code_execution_overhead = max(0, step_total_time - known_total)

            details = {
                "截图": round(screenshot_time, 3),
                "Brain 推理": round(brain_inference_time, 3),
                "Brain 其他": round(brain_other_time, 3),
                "Actor 推理": round(actor_inference_time, 3),
                "动作执行": round(action_execution_time, 3),
                "系统开销": {
                    "内存更新": round(memory_update_time, 3),
                    "历史记录创建": round(history_create_time, 3),
                    "记录保存": round(record_save_time, 3),
                    "状态窗口更新": round(status_update_time + final_status_update_time, 3),
                    "会话日志记录": round(session_log_time, 3),
                    "代码执行开销": round(code_execution_overhead, 3),
                },
                "步骤总计": round(step_total_time, 3)
            }

            # 验证：各分项之和应等于 step_total
            # 系统开销是嵌套字典，需要计算其子项之和
            verified_sum = 0
            for k, v in details.items():
                if k == "步骤总计":
                    continue
                if k == "系统开销" and isinstance(v, dict):
                    verified_sum += sum(v.values())
                else:
                    verified_sum += v
                    
            if abs(verified_sum - step_total_time) > 0.01:
                logger.debug(f"Time mismatch for step {step_id}: {verified_sum:.3f} vs {step_total_time:.3f}")
                # 调整代码执行开销使总和等于 step_total
                details["系统开销"]["代码执行开销"] = round(details["系统开销"]["代码执行开销"] + (step_total_time - verified_sum), 3)

            # 收集动作信息
            actions_info = []
            last_action = getattr(self, 'last_step_action', None)
            if last_action:
                for action in last_action:
                    if isinstance(action, dict):
                        for action_name, action_params in action.items():
                            if action_params is not None:
                                action_record = {
                                    "动作": action_name,
                                    "参数": action_params
                                }
                                # 为点击动作添加点击类型信息
                                if action_name in ["Click", "RightSingle", "DoubleClick"]:
                                    click_type_map = {
                                        "Click": "左键点击",
                                        "RightSingle": "右键点击",
                                        "DoubleClick": "双击"
                                    }
                                    action_record["点击类型"] = click_type_map.get(action_name, action_name)
                                
                                actions_info.append(action_record)

            # 获取思考内容（从 brain_context 中获取）
            thinking_content = ""
            brain_context = getattr(self, 'brain_context', {})
            if step_id in brain_context:
                step_context = brain_context[step_id]
                # 提取 analysis 字段作为思考内容
                if isinstance(step_context, dict):
                    analysis = step_context.get("analysis", "")
                    if isinstance(analysis, dict):
                        # 如果 analysis 是字典，提取关键信息
                        thinking_content = json.dumps(analysis, ensure_ascii=False)[:2000]
                    elif isinstance(analysis, str):
                        thinking_content = analysis[:2000]

            # 获取步骤评估结果
            step_evaluate = ""
            if step_id in brain_context:
                step_context = brain_context[step_id]
                if isinstance(step_context, dict):
                    current_state = step_context.get("current_state", {})
                    if isinstance(current_state, dict):
                        step_evaluate = current_state.get("step_evaluate", "")
            if step_error and not step_evaluate:
                step_evaluate = "Error"

            # 构建完整的记录（使用中文键名）
            record = {
                "步骤序号": step_id,
                "时间戳": datetime.now().isoformat(),
                "目标": self.next_goal[:500] if self.next_goal else "",
                "思考": thinking_content[:2000] if thinking_content else "",
                "步骤评估": step_evaluate,
                "计时": details,
                "动作": actions_info,
                "动作数量": len(actions_info),
                "状态": "error" if step_error else "success"
            }
            if step_error:
                record["错误"] = step_error

            # 保存到状态窗口（如果启用）
            if self._status_window:
                self._status_window.save_record(record)

            # 保存到 JSONL 文件
            self._write_step_to_jsonl(record)
            self._write_step_record_json(record)

        except Exception as e:
            logger.debug(f"保存步骤记录失败：{e}")

    def _write_step_record_json(self, record: dict) -> None:
        """写入固定 JSON 步骤记录文件，供外部工具读取最新运行记录。"""
        try:
            self._step_records.append(record)
            total_actions = sum(int(item.get("动作数量", 0) or 0) for item in self._step_records)
            data = {
                "任务": self.original_task,
                "开始时间": self.current_time.isoformat(),
                "更新时间": datetime.now().isoformat(),
                "智能体ID": self.agent_id,
                "步骤记录": self._step_records,
                "动作数量": total_actions,
                "任务总结": self._generate_step_record_summary(),
            }
            self._step_record_json_path.parent.mkdir(parents=True, exist_ok=True)
            tmp_path = self._step_record_json_path.with_suffix(".json.tmp")
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            os.replace(tmp_path, self._step_record_json_path)
        except Exception as e:
            logger.debug("写入步骤 JSON 记录失败：%s", e)

    def _generate_step_record_summary(self) -> str:
        if not self._step_records:
            return ""
        last = self._step_records[-1]
        error_count = sum(1 for item in self._step_records if item.get("状态") == "error")
        return (
            f"已记录 {len(self._step_records)} 个步骤，"
            f"错误 {error_count} 个，"
            f"最新目标：{str(last.get('目标', ''))[:120]}"
        )

    def _write_step_to_jsonl(self, record: dict) -> None:
        """将步骤记录写入 JSONL 文件（使用清晰易读的格式）"""
        if not self._step_log_path:
            return

        try:
            with open(self._step_log_path, 'a', encoding='utf-8') as f:
                # 写入分割线
                f.write("=" * 80 + "\n")
                
                # 写入步骤序号
                f.write(f"步骤 {record.get('步骤序号', '?')}:\n")
                
                # 写入目标
                f.write(f"  目标：{record.get('目标', '')}\n")
                
                # 写入思考
                thinking = record.get('思考', '')
                if thinking:
                    f.write(f"  思考：{thinking}\n")
                
                # 写入步骤评估
                step_eval = record.get('步骤评估', '')
                if step_eval:
                    f.write(f"  评估：{step_eval}\n")
                error = record.get('错误', '')
                if error:
                    f.write(f"  错误：{error}\n")
                
                # 写入动作详情
                actions = record.get('动作', [])
                if actions:
                    f.write("  动作详情:\n")
                    for i, action in enumerate(actions, 1):
                        action_name = action.get('动作', 'unknown')
                        params = action.get('参数', {})
                        f.write(f"    {i}. {action_name}: {params}\n")
                
                # 写入总耗时
                timing = record.get('计时', {})
                step_total = timing.get('步骤总计', 0)
                f.write(f"  总耗时：{step_total:.3f}秒\n")

                # 写入耗时详情
                f.write("  耗时详情:\n")
                f.write(f"    截图：{timing.get('截图', 0):.3f}秒\n")
                f.write(f"    Brain 推理：{timing.get('Brain 推理', 0):.3f}秒\n")
                f.write(f"    Brain 其他：{timing.get('Brain 其他', 0):.3f}秒\n")
                f.write(f"    Actor 推理：{timing.get('Actor 推理', 0):.3f}秒\n")
                f.write(f"    动作执行：{timing.get('动作执行', 0):.3f}秒\n")
                
                # 系统开销（支持嵌套结构）
                system_overhead = timing.get('系统开销', 0)
                if isinstance(system_overhead, dict):
                    f.write("    系统开销:\n")
                    f.write(f"      内存更新：{system_overhead.get('内存更新', 0):.3f}秒\n")
                    f.write(f"      历史记录创建：{system_overhead.get('历史记录创建', 0):.3f}秒\n")
                    f.write(f"      记录保存：{system_overhead.get('记录保存', 0):.3f}秒\n")
                    f.write(f"      状态窗口更新：{system_overhead.get('状态窗口更新', 0):.3f}秒\n")
                    f.write(f"      会话日志记录：{system_overhead.get('会话日志记录', 0):.3f}秒\n")
                    f.write(f"      代码执行开销：{system_overhead.get('代码执行开销', 0):.3f}秒\n")
                else:
                    f.write(f"    系统开销：{system_overhead:.3f}秒\n")

                # 写入状态和时间戳
                f.write(f"  状态：{record.get('状态', '?')}\n")
                f.write(f"  时间：{record.get('时间戳', '')}\n")
                
                # 写入空行分隔
                f.write("\n")
                
            logger.debug(f"步骤 {record.get('步骤序号')} 已写入 {self._step_log_path}")
        except Exception as e:
            logger.debug(f"写入步骤日志失败：{e}")

    def _finalize_session(self, reason: str, total_run_time: float) -> None:
        """完成会话并保存最终日志"""
        if self._status_window:
            try:
                from src.utils.status_window import finalize_session
                finalize_session(reason)
                logger.info(f"Session finalized: {reason}, total time: {total_run_time:.2f}s")
            except Exception as e:
                logger.debug(f"Failed to finalize session: {e}")

    def initiate_messages(self):
        self.brain_message_manager = MessageManager(
            llm=self.brain_llm,
            task=self.task,
            action_descriptions=self.controller.registry.get_prompt_description(),
            system_prompt_class=BrainPrompt_kylin,
            max_input_tokens=self.max_input_tokens,
            include_attributes=self.include_attributes,
            max_error_length=self.max_error_length,
            max_actions_per_step=self.max_actions_per_step,
            give_task=True,
        )
        self.actor_message_manager = MessageManager(
            llm=self.actor_llm,
            task=self.task,
            action_descriptions=self.controller.registry.get_prompt_description(),
            system_prompt_class=ActorPrompt_kylin,
            max_input_tokens=self.max_input_tokens,
            include_attributes=self.include_attributes,
            max_error_length=self.max_error_length,
            max_actions_per_step=self.max_actions_per_step,
            give_task=False,
        )
        self.memory_message_manager = MessageManager(
            llm=self.memory_llm,
            task=self.task,
            action_descriptions=self.controller.registry.get_prompt_description(),
            system_prompt_class=MemoryPrompt,
            max_input_tokens=self.max_input_tokens,
            include_attributes=self.include_attributes,
            max_error_length=self.max_error_length,
            max_actions_per_step=self.max_actions_per_step,
            give_task=True,
        )
