import asyncio
import logging
import os
import shutil
import subprocess
from typing import Optional, Tuple

try:
    import pyautogui
except Exception as exc:
    pyautogui = None
    _PYAUTOGUI_IMPORT_ERROR = exc
else:
    _PYAUTOGUI_IMPORT_ERROR = None
import pyperclip

from src.linux.screen import capture_target_screenshot, get_target_screen_rect

logger = logging.getLogger(__name__)
ACTION_CMD_TIMEOUT = 3.0
TYPE_CMD_TIMEOUT = 15.0
WAYLAND_YDOTOOL_COORD_FACTOR = 2.4

_YDOTOOL_KEY_CODES = {
    "esc": 1,
    "escape": 1,
    "1": 2,
    "2": 3,
    "3": 4,
    "4": 5,
    "5": 6,
    "6": 7,
    "7": 8,
    "8": 9,
    "9": 10,
    "0": 11,
    "-": 12,
    "=": 13,
    "backspace": 14,
    "tab": 15,
    "q": 16,
    "w": 17,
    "e": 18,
    "r": 19,
    "t": 20,
    "y": 21,
    "u": 22,
    "i": 23,
    "o": 24,
    "p": 25,
    "[": 26,
    "]": 27,
    "enter": 28,
    "return": 28,
    "ctrl": 29,
    "control": 29,
    "leftctrl": 29,
    "a": 30,
    "s": 31,
    "d": 32,
    "f": 33,
    "g": 34,
    "h": 35,
    "j": 36,
    "k": 37,
    "l": 38,
    ";": 39,
    "'": 40,
    "`": 41,
    "shift": 42,
    "leftshift": 42,
    "\\": 43,
    "z": 44,
    "x": 45,
    "c": 46,
    "v": 47,
    "b": 48,
    "n": 49,
    "m": 50,
    ",": 51,
    ".": 52,
    "/": 53,
    "rightshift": 54,
    "alt": 56,
    "leftalt": 56,
    "space": 57,
    "capslock": 58,
    "f1": 59,
    "f2": 60,
    "f3": 61,
    "f4": 62,
    "f5": 63,
    "f6": 64,
    "f7": 65,
    "f8": 66,
    "f9": 67,
    "f10": 68,
    "home": 102,
    "up": 103,
    "pageup": 104,
    "pgup": 104,
    "left": 105,
    "right": 106,
    "end": 107,
    "down": 108,
    "pagedown": 109,
    "pgdn": 109,
    "insert": 110,
    "delete": 111,
    "del": 111,
    "mute": 113,
    "volumedown": 114,
    "volumeup": 115,
    "super": 125,
    "win": 125,
    "meta": 125,
    "cmd": 125,
    "rightctrl": 97,
    "rightalt": 100,
    "f11": 87,
    "f12": 88,
}


class LinuxActions:
    """Linux UI actions with X11/PyAutoGUI and Wayland/ydotool backends."""

    def __init__(self) -> None:
        self.session_type = self._detect_session_type()
        self._ydotool_path = shutil.which("ydotool")
        self._use_ydotool = self.session_type == "wayland"
        if self._use_ydotool and not self._ydotool_path:
            logger.warning("Wayland session detected but ydotool is not installed.")
        elif self._use_ydotool:
            logger.info("Wayland session detected; LinuxActions will use ydotool.")
            _, _, screen_w, screen_h = get_target_screen_rect()
            factor = self._wayland_ydotool_factor()
            logger.info(
                "Wayland ydotool coordinate mapping: logical_size=(%s, %s), factor=%.3f, "
                "max=(%.1f, %.1f), fine_scale=(%.3f, %.3f), offset=(%.1f, %.1f)",
                screen_w,
                screen_h,
                factor,
                screen_w / factor,
                screen_h / factor,
                self._env_float("KYLIN_WAYLAND_COORD_SCALE_X", 1.0),
                self._env_float("KYLIN_WAYLAND_COORD_SCALE_Y", 1.0),
                self._env_float("KYLIN_WAYLAND_COORD_OFFSET_X", 0.0),
                self._env_float("KYLIN_WAYLAND_COORD_OFFSET_Y", 0.0),
            )
        else:
            logger.info("LinuxActions will use PyAutoGUI for session type '%s'.", self.session_type)

    @staticmethod
    def _detect_session_type() -> str:
        session_type = (os.getenv("XDG_SESSION_TYPE") or "").strip().lower()
        if session_type in {"wayland", "x11"}:
            return session_type
        if os.getenv("WAYLAND_DISPLAY"):
            return "wayland"
        if os.getenv("DISPLAY"):
            return "x11"
        return "unknown"

    @property
    def _is_wayland(self) -> bool:
        return self._use_ydotool

    def _pyautogui(self):
        if pyautogui is None:
            raise RuntimeError(f"PyAutoGUI is unavailable: {_PYAUTOGUI_IMPORT_ERROR}")
        return pyautogui

    async def _run_ydotool(self, args: list[str]) -> bool:
        if not self._ydotool_path:
            logger.error("ydotool is required for Wayland actions but was not found in PATH.")
            return False
        try:
            proc = await asyncio.to_thread(
                subprocess.run,
                [self._ydotool_path, *args],
                capture_output=True,
                text=True,
                check=False,
                timeout=ACTION_CMD_TIMEOUT,
            )
            if proc.returncode == 0:
                return True
            logger.error("ydotool %s failed (code=%s): %s", " ".join(args), proc.returncode, proc.stderr.strip())
            return False
        except Exception as e:
            logger.error("ydotool %s error: %s", " ".join(args), e)
            return False

    async def _run_ydotool_with_input(self, args: list[str], input_text: str, timeout: float = TYPE_CMD_TIMEOUT) -> bool:
        if not self._ydotool_path:
            logger.error("ydotool is required for Wayland actions but was not found in PATH.")
            return False
        try:
            proc = await asyncio.to_thread(
                subprocess.run,
                [self._ydotool_path, *args],
                input=input_text,
                capture_output=True,
                text=True,
                check=False,
                timeout=timeout,
            )
            if proc.returncode == 0:
                return True
            logger.error("ydotool %s failed (code=%s): %s", " ".join(args), proc.returncode, proc.stderr.strip())
            return False
        except Exception as e:
            logger.error("ydotool %s error: %s", " ".join(args), e)
            return False

    @staticmethod
    def _ydotool_button(button: str) -> Optional[str]:
        button_map = {
            "left": "0xC0",
            "right": "0xC1",
            "middle": "0xC2",
        }
        return button_map.get(button)

    @staticmethod
    def _ydotool_key_code(key: str) -> Optional[int]:
        normalized = str(key).replace("Key.", "").strip("'\"").lower()
        return _YDOTOOL_KEY_CODES.get(normalized)

    async def _ydotool_key(self, *keys: str) -> bool:
        codes: list[int] = []
        for key in keys:
            code = self._ydotool_key_code(key)
            if code is None:
                logger.error("Unsupported ydotool key name: %s", key)
                return False
            codes.append(code)

        events = [f"{code}:1" for code in codes]
        events.extend(f"{code}:0" for code in reversed(codes))
        return await self._run_ydotool(["key", *events])

    async def _ydotool_type_text(self, text: str) -> bool:
        if not text:
            return True
        timeout = max(ACTION_CMD_TIMEOUT, min(TYPE_CMD_TIMEOUT, 1.0 + (len(text) * 0.08)))
        return await self._run_ydotool_with_input(["type", "-d", "20", "-f", "-"], text, timeout=timeout)

    async def _ydotool_move(self, x: float, y: float) -> bool:
        calibrated_x, calibrated_y = self._calibrate_wayland_point(x, y)
        logger.debug(
            "ydotool absolute move: raw=(%.2f, %.2f), calibrated=(%.2f, %.2f)",
            x,
            y,
            calibrated_x,
            calibrated_y,
        )
        return await self._run_ydotool(
            ["mousemove", "--absolute", str(int(round(calibrated_x))), str(int(round(calibrated_y)))]
        )

    def getscreen_size(self) -> Tuple[int, int]:
        try:
            _, _, screen_width, screen_height = get_target_screen_rect()
            return int(screen_width), int(screen_height)
        except Exception as e:
            logger.error(f"Error getting screen size: {e}")
            return 1920, 1080

    def _to_pixel(self, x: float, y: float) -> tuple[float, float]:
        offset_x, offset_y, screen_w, screen_h = get_target_screen_rect()
        if 0 <= x <= 1 and 0 <= y <= 1:
            pos = offset_x + (screen_w * x), offset_y + (screen_h * y)
        else:
            pos = offset_x + (screen_w * (x / 1000)), offset_y + (screen_h * (y / 1000))
        logger.debug(
            "coordinate conversion: input=(%s, %s), rect=(%s, %s, %s, %s), pixel=(%.2f, %.2f)",
            x,
            y,
            offset_x,
            offset_y,
            screen_w,
            screen_h,
            pos[0],
            pos[1],
        )
        return pos

    @staticmethod
    def _env_float(name: str, default: float) -> float:
        raw = os.getenv(name)
        if raw is None or raw == "":
            return default
        try:
            return float(raw)
        except ValueError:
            logger.warning("Ignoring invalid %s=%r; expected a number.", name, raw)
            return default

    def _wayland_ydotool_factor(self) -> float:
        factor = self._env_float("KYLIN_WAYLAND_YDOTOOL_FACTOR", WAYLAND_YDOTOOL_COORD_FACTOR)
        if factor <= 0:
            logger.warning(
                "Ignoring invalid KYLIN_WAYLAND_YDOTOOL_FACTOR=%s; expected a positive number.",
                factor,
            )
            return WAYLAND_YDOTOOL_COORD_FACTOR
        return factor

    def _calibrate_wayland_point(self, x: float, y: float) -> tuple[float, float]:
        if not self._is_wayland:
            return x, y
        factor = self._wayland_ydotool_factor()
        scale_x = self._env_float("KYLIN_WAYLAND_COORD_SCALE_X", 1.0)
        scale_y = self._env_float("KYLIN_WAYLAND_COORD_SCALE_Y", 1.0)
        offset_x = self._env_float("KYLIN_WAYLAND_COORD_OFFSET_X", 0.0)
        offset_y = self._env_float("KYLIN_WAYLAND_COORD_OFFSET_Y", 0.0)
        return ((x / factor) * scale_x) + offset_x, ((y / factor) * scale_y) + offset_y

    @staticmethod
    def _is_ascii_text(text: str) -> bool:
        try:
            text.encode("ascii")
            return True
        except UnicodeEncodeError:
            return False

    async def _type_with_xdotool(self, text: str) -> bool:
        """使用剪贴板 + 粘贴方式输入文本，避免输入法干扰。"""
        if not text:
            return True
        if self._is_wayland:
            return await self._send_paste_hotkey()
        if shutil.which("xdotool") is None:
            return False
        try:
            # 使用剪贴板粘贴方式，避免输入法将英文识别为拼音
            proc = await asyncio.to_thread(
                subprocess.run,
                ["xdotool", "key", "--clearmodifiers", "ctrl+v"],
                capture_output=True,
                text=True,
                check=False,
                timeout=ACTION_CMD_TIMEOUT,
            )
            if proc.returncode == 0:
                return True
            logger.warning("xdotool paste failed (code=%s): %s", proc.returncode, proc.stderr.strip())
            return False
        except Exception as e:
            logger.warning("xdotool paste error: %s", e)
            return False

    async def _send_paste_hotkey(self) -> bool:
        if self._is_wayland:
            return await self._ydotool_key("ctrl", "v")

        if shutil.which("xdotool") is not None:
            try:
                proc = await asyncio.to_thread(
                    subprocess.run,
                    ["xdotool", "key", "--clearmodifiers", "ctrl+v"],
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=ACTION_CMD_TIMEOUT,
                )
                if proc.returncode == 0:
                    return True
                logger.warning("xdotool paste failed (code=%s): %s", proc.returncode, proc.stderr.strip())
            except Exception as e:
                logger.warning("xdotool paste error: %s", e)

        try:
            await asyncio.to_thread(self._pyautogui().hotkey, "ctrl", "v")
            return True
        except Exception as e:
            logger.error("PyAutoGUI paste error: %s", e)
            return False

    async def _read_clipboard_text(self) -> Optional[str]:
        if self._is_wayland and shutil.which("wl-paste"):
            try:
                proc = await asyncio.to_thread(
                    subprocess.run,
                    ["wl-paste", "--no-newline"],
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=ACTION_CMD_TIMEOUT,
                )
                if proc.returncode == 0:
                    return proc.stdout
                logger.debug("wl-paste failed (code=%s): %s", proc.returncode, proc.stderr.strip())
            except Exception as e:
                logger.debug("wl-paste error: %s", e)

        try:
            return await asyncio.to_thread(pyperclip.paste)
        except Exception as e:
            logger.warning("Failed to read clipboard: %s", e)
            return None

    async def _write_clipboard_text(self, text: str) -> bool:
        if self._is_wayland and shutil.which("wl-copy"):
            try:
                proc = await asyncio.to_thread(
                    subprocess.run,
                    ["wl-copy", "--type", "text/plain;charset=utf-8"],
                    input=text,
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=ACTION_CMD_TIMEOUT,
                )
                if proc.returncode != 0:
                    logger.warning("wl-copy failed (code=%s): %s", proc.returncode, proc.stderr.strip())
                    return False
                if shutil.which("wl-paste"):
                    pasted = await self._read_clipboard_text()
                    if pasted != text:
                        logger.warning("Wayland clipboard verification failed.")
                        return False
                return True
            except Exception as e:
                logger.warning("wl-copy error: %s", e)
                return False

        try:
            await asyncio.to_thread(pyperclip.copy, text)
            await asyncio.sleep(0.05)
            if await asyncio.to_thread(pyperclip.paste) != text:
                raise ValueError("Clipboard verification failed")
            return True
        except Exception as e:
            logger.warning("Failed to set clipboard: %s", e)
            return False

    async def _restore_clipboard_text(self, text: Optional[str]) -> None:
        if text is None:
            return
        for attempt in range(5):
            if await self._write_clipboard_text(text):
                return
            await asyncio.sleep(0.1 * (attempt + 1))

    async def click(self, x: float, y: float, button: str = "left") -> bool:
        pos_x, pos_y = self._to_pixel(x, y)
        try:
            if self._is_wayland:
                if button == "double":
                    return (
                        await self._ydotool_move(pos_x, pos_y)
                        and await self._run_ydotool(["click", "-r", "2", "0xC0"])
                    )
                ydotool_button = self._ydotool_button(button)
                if ydotool_button is None:
                    logger.error("Unknown click button '%s'", button)
                    return False
                return await self._ydotool_move(pos_x, pos_y) and await self._run_ydotool(["click", ydotool_button])

            gui = self._pyautogui()
            if button == "left":
                gui.click(pos_x, pos_y, duration=0.05)
            elif button == "right":
                gui.rightClick(pos_x, pos_y, duration=0.05)
            elif button == "double":
                gui.doubleClick(pos_x, pos_y, duration=0.05)
            else:
                logger.error("Unknown click button '%s'", button)
                return False

            await asyncio.sleep(0.03)
            return True
        except Exception as e:
            logger.error(f"Error clicking at ({x}, {y}): {e}")
            return False

    async def drag(
        self,
        start_x: float,
        start_y: float,
        end_x: float,
        end_y: float,
        duration: float = 0.5,
    ) -> bool:
        pos_start_x, pos_start_y = self._to_pixel(start_x, start_y)
        pos_end_x, pos_end_y = self._to_pixel(end_x, end_y)
        try:
            if self._is_wayland:
                steps = max(4, int(duration * 20))
                if not await self._ydotool_move(pos_start_x, pos_start_y):
                    return False
                if not await self._run_ydotool(["click", "0x40"]):
                    return False
                for step in range(1, steps + 1):
                    ratio = step / steps
                    cur_x = pos_start_x + ((pos_end_x - pos_start_x) * ratio)
                    cur_y = pos_start_y + ((pos_end_y - pos_start_y) * ratio)
                    if not await self._ydotool_move(cur_x, cur_y):
                        await self._run_ydotool(["click", "0x80"])
                        return False
                    await asyncio.sleep(duration / steps)
                return await self._run_ydotool(["click", "0x80"])

            gui = self._pyautogui()
            gui.moveTo(pos_start_x, pos_start_y, duration=0.2)
            gui.dragTo(pos_end_x, pos_end_y, duration=duration, button="left")
            return True
        except Exception as e:
            logger.error(
                "Error dragging from (%s, %s) to (%s, %s): %s",
                start_x,
                start_y,
                end_x,
                end_y,
                e,
            )
            return False

    async def scroll(self, x: float, y: float, clicks: int) -> bool:
        pos_x, pos_y = self._to_pixel(x, y)
        try:
            if self._is_wayland:
                return (
                    await self._ydotool_move(pos_x, pos_y)
                    and await self._run_ydotool(["mousemove", "--wheel", "0", str(int(clicks))])
                )
            self._pyautogui().scroll(clicks, x=pos_x, y=pos_y)
            return True
        except Exception as e:
            logger.error(f"Error scrolling at ({x}, {y}): {e}")
            return False

    async def type_text(self, text: str) -> bool:
        """
        Type text using clipboard method to handle both English and Chinese characters.
        Before pasting, it selects all existing text (Ctrl+A) to replace the content.
        """
        original_clipboard = None
        try:
            if not text:
                return True

            original_clipboard = await self._read_clipboard_text()

            await asyncio.sleep(0.1)
            # 先全选所有文本 (Ctrl+A)，然后粘贴替换
            if self._is_wayland:
                if not await self.press_hotkey("ctrl", "a"):
                    return False
            else:
                self._pyautogui().hotkey('ctrl', 'a')
            await asyncio.sleep(0.1)

            if self._is_wayland and not shutil.which("wl-copy"):
                logger.warning(
                    "wl-copy is not available; falling back to ydotool type for Wayland text input."
                )
                return await self._ydotool_type_text(text)

            # 将文本复制到剪贴板
            for attempt in range(3):
                if await self._write_clipboard_text(text):
                    break
                logger.warning("Attempt %s: Failed to set clipboard.", attempt + 1)
                await asyncio.sleep(0.2 * (attempt + 1))
            else:
                if self._is_wayland:
                    return await self._ydotool_type_text(text)
                return False

            await asyncio.sleep(0.15)
            # 使用 xdotool 发送粘贴快捷键（已改为剪贴板方式，避免输入法干扰）
            if await self._type_with_xdotool(text):
                await asyncio.sleep(0.2)
                await self._restore_clipboard_text(original_clipboard)
                return True

            # xdotool 失败时回退到 pyautogui 发送粘贴快捷键
            if not await self._send_paste_hotkey():
                if self._is_wayland:
                    return await self._ydotool_type_text(text)
                return False
            await asyncio.sleep(0.2)

            await self._restore_clipboard_text(original_clipboard)
            return True
        except Exception as e:
            logger.error(f"Error typing text '{text}': {e}")
            await self._restore_clipboard_text(original_clipboard)
            return False

    async def press_key(self, key: str) -> bool:
        try:
            if self._is_wayland:
                return await self._ydotool_key(key)
            self._pyautogui().press(key)
            return True
        except Exception as e:
            logger.error(f"Error pressing key '{key}': {e}")
            return False

    async def press_hotkey(self, key1: str, key2: str, key3: Optional[str] = None) -> bool:
        try:
            if self._is_wayland:
                keys = (key1, key2, key3) if key3 is not None else (key1, key2)
                return await self._ydotool_key(*keys)

            gui = self._pyautogui()
            if key3 is not None:
                gui.keyDown(key1)
                await asyncio.sleep(0.05)
                gui.keyDown(key2)
                await asyncio.sleep(0.05)
                gui.keyDown(key3)
                await asyncio.sleep(0.05)
                gui.keyUp(key3)
                await asyncio.sleep(0.05)
                gui.keyUp(key2)
                await asyncio.sleep(0.05)
                gui.keyUp(key1)
                await asyncio.sleep(0.1)
            else:
                gui.keyDown(key1)
                await asyncio.sleep(0.05)
                gui.keyDown(key2)
                await asyncio.sleep(0.05)
                gui.keyUp(key2)
                await asyncio.sleep(0.05)
                gui.keyUp(key1)
                await asyncio.sleep(0.1)
            return True
        except Exception as e:
            logger.error(f"Error pressing hotkey {key1, key2, key3}: {e}")
            return False

    async def take_screenshot(self, save_path: Optional[str] = None) -> bool:
        try:
            screenshot = capture_target_screenshot()
            if save_path:
                screenshot.save(save_path)
            return True
        except Exception as e:
            logger.error(f"Error taking screenshot: {e}")
            return False

    async def get_mouse_position(self) -> Tuple[int, int]:
        try:
            if self._is_wayland:
                logger.warning("Getting mouse position is not supported by ydotool.")
                return (0, 0)
            return self._pyautogui().position()
        except Exception as e:
            logger.error(f"Error getting mouse position: {e}")
            return (0, 0)

    async def move_mouse(self, x: float, y: float, duration: float = 0.0) -> bool:
        pos_x, pos_y = self._to_pixel(x, y)
        try:
            if self._is_wayland:
                return await self._ydotool_move(pos_x, pos_y)
            self._pyautogui().moveTo(pos_x, pos_y, duration=duration)
            return True
        except Exception as e:
            logger.error(f"Error moving mouse to ({x}, {y}): {e}")
            return False
