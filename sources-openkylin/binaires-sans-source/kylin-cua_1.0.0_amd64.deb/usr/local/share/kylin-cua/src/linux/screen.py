import logging
import os
import re
import shutil
import subprocess
import tempfile
import time
from typing import Optional

from PIL import Image

logger = logging.getLogger(__name__)

_WAYLAND_SCREEN_RECT_CACHE: tuple[float, tuple[int, int, int, int]] | None = None
_WAYLAND_SCREEN_RECT_CACHE_TTL = 2.0


def _parse_target_screen(raw: Optional[str]) -> int:
    """Parse 1-based screen selector; defaults to 1."""
    if not raw:
        return 1
    value = raw.strip().lower()
    m = re.match(r"screen\s*(\d+)$", value)
    if m:
        return max(1, int(m.group(1)))
    if value.isdigit():
        return max(1, int(value))
    return 1


def list_screens() -> list[tuple[int, int, int, int]]:
    """
    Return monitor rectangles as (x, y, width, height), ordered by x then y.
    Linux implementation uses xrandr.
    """
    try:
        proc = subprocess.run(
            ["xrandr", "--query"],
            capture_output=True,
            text=True,
            check=False,
        )
        if proc.returncode != 0:
            return []

        screens: list[tuple[int, int, int, int]] = []
        pattern = re.compile(r" connected(?: primary)? (\d+)x(\d+)\+(-?\d+)\+(-?\d+)")
        for line in proc.stdout.splitlines():
            m = pattern.search(line)
            if not m:
                continue
            w, h, x, y = map(int, m.groups())
            if w > 0 and h > 0:
                screens.append((x, y, w, h))
        screens.sort(key=lambda s: (s[0], s[1]))
        return screens
    except Exception:
        return []


def _parse_kscreen_doctor_rects(stdout: str) -> list[tuple[int, int, int, int]]:
    rects: list[tuple[int, int, int, int]] = []
    current_enabled = True
    current_connected = True
    current_geometry: tuple[int, int, int, int] | None = None

    def flush_current() -> None:
        if current_geometry and current_enabled and current_connected:
            rects.append(current_geometry)

    for raw_line in stdout.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith("Output:"):
            flush_current()
            current_enabled = True
            current_connected = True
            current_geometry = None
            continue
        if line == "enabled":
            current_enabled = True
            continue
        if line == "disabled":
            current_enabled = False
            continue
        if line == "connected":
            current_connected = True
            continue
        if line == "disconnected":
            current_connected = False
            continue

        m = re.search(r"Geometry:\s*(-?\d+),(-?\d+)\s+(\d+)x(\d+)", line)
        if not m:
            continue
        x, y, w, h = map(int, m.groups())
        if w > 0 and h > 0:
            current_geometry = (x, y, w, h)

    flush_current()
    rects.sort(key=lambda s: (s[0], s[1]))
    return rects


def list_wayland_screens() -> list[tuple[int, int, int, int]]:
    """
    Return Wayland logical monitor rectangles when the compositor exposes them.
    kscreen-doctor reports logical geometry; LinuxActions converts these logical
    coordinates into ydotool's smaller absolute coordinate space before input.
    """
    kscreen_doctor = shutil.which("kscreen-doctor")
    if not kscreen_doctor:
        return []
    try:
        proc = subprocess.run(
            [kscreen_doctor, "-o"],
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
        )
        if proc.returncode != 0:
            logger.debug("kscreen-doctor failed (code=%s): %s", proc.returncode, proc.stderr.strip())
            return []
        return _parse_kscreen_doctor_rects(proc.stdout)
    except Exception as e:
        logger.debug("kscreen-doctor error: %s", e)
        return []


def get_primary_screen_rect() -> tuple[int, int, int, int]:
    """
    Return primary monitor rect as (x, y, width, height).
    Falls back to first detected monitor, then full-screen fallback.
    """
    try:
        proc = subprocess.run(
            ["xrandr", "--query"],
            capture_output=True,
            text=True,
            check=False,
        )
        if proc.returncode == 0:
            pattern = re.compile(r" connected primary (\d+)x(\d+)\+(-?\d+)\+(-?\d+)")
            for line in proc.stdout.splitlines():
                m = pattern.search(line)
                if not m:
                    continue
                w, h, x, y = map(int, m.groups())
                if w > 0 and h > 0:
                    return (x, y, w, h)
    except Exception:
        pass

    screens = list_screens()
    if screens:
        return screens[0]

    try:
        import pyautogui

        w, h = pyautogui.size()
        return (0, 0, int(w), int(h))
    except Exception:
        return (0, 0, 1920, 1080)


def get_target_screen_rect() -> tuple[int, int, int, int]:
    """
    Return target screen region as (x, y, width, height).
    Uses env KYLIN_TARGET_SCREEN as 1-based index: 1, 2, ... or screen1/screen2.
    """
    screens = list_wayland_screens() if is_wayland_session() else list_screens()
    if not screens:
        if is_wayland_session():
            return get_wayland_screen_rect()
        # Fallback to full screen region from X root geometry.
        try:
            import pyautogui

            w, h = pyautogui.size()
            return (0, 0, int(w), int(h))
        except Exception:
            return (0, 0, 1920, 1080)

    target_1_based = _parse_target_screen(os.getenv("KYLIN_TARGET_SCREEN"))
    idx = min(max(target_1_based - 1, 0), len(screens) - 1)
    return screens[idx]


def is_wayland_session() -> bool:
    session_type = (os.getenv("XDG_SESSION_TYPE") or "").strip().lower()
    if session_type == "wayland":
        return True
    if session_type == "x11":
        return False
    return bool(os.getenv("WAYLAND_DISPLAY"))


def _load_image(path: str) -> Image.Image:
    image = Image.open(path)
    image.load()
    return image.convert("RGB")


def _crop_region(image: Image.Image, region: Optional[tuple[int, int, int, int]]) -> Image.Image:
    if region is None:
        return image
    x, y, w, h = region
    if w <= 0 or h <= 0:
        return image
    return image.crop((x, y, x + w, y + h))


def _capture_with_grim(region: Optional[tuple[int, int, int, int]]) -> Optional[Image.Image]:
    grim = shutil.which("grim")
    if not grim:
        return None

    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
        tmp_path = tmp.name
    try:
        cmd = [grim]
        if region is not None:
            x, y, w, h = region
            cmd.extend(["-g", f"{int(x)},{int(y)} {int(w)}x{int(h)}"])
        cmd.append(tmp_path)
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False, timeout=10)
        if proc.returncode != 0:
            logger.warning("grim screenshot failed (code=%s): %s", proc.returncode, proc.stderr.strip())
            return None
        return _load_image(tmp_path)
    except Exception as e:
        logger.warning("grim screenshot error: %s", e)
        return None
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass


def _capture_with_gnome_screenshot(region: Optional[tuple[int, int, int, int]]) -> Optional[Image.Image]:
    gnome_screenshot = shutil.which("gnome-screenshot")
    if not gnome_screenshot:
        return None

    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
        tmp_path = tmp.name
    try:
        proc = subprocess.run(
            [gnome_screenshot, "-f", tmp_path],
            capture_output=True,
            text=True,
            check=False,
            timeout=10,
        )
        if proc.returncode != 0:
            logger.warning(
                "gnome-screenshot failed (code=%s): %s",
                proc.returncode,
                proc.stderr.strip(),
            )
            return None
        return _crop_region(_load_image(tmp_path), region)
    except Exception as e:
        logger.warning("gnome-screenshot error: %s", e)
        return None
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass


def get_wayland_screen_rect() -> tuple[int, int, int, int]:
    global _WAYLAND_SCREEN_RECT_CACHE

    now = time.monotonic()
    if _WAYLAND_SCREEN_RECT_CACHE is not None:
        cached_at, rect = _WAYLAND_SCREEN_RECT_CACHE
        if now - cached_at < _WAYLAND_SCREEN_RECT_CACHE_TTL:
            return rect

    screens = list_wayland_screens()
    if screens:
        target_1_based = _parse_target_screen(os.getenv("KYLIN_TARGET_SCREEN"))
        idx = min(max(target_1_based - 1, 0), len(screens) - 1)
        rect = screens[idx]
        _WAYLAND_SCREEN_RECT_CACHE = (now, rect)
        return rect

    image = _capture_with_grim(None)
    if image is None:
        image = _capture_with_gnome_screenshot(None)
    if image is not None:
        rect = (0, 0, int(image.width), int(image.height))
        _WAYLAND_SCREEN_RECT_CACHE = (now, rect)
        return rect

    logger.warning("Unable to detect Wayland screen size from screenshot tools; using 1920x1080 fallback.")
    return (0, 0, 1920, 1080)


def capture_screenshot(region: Optional[tuple[int, int, int, int]] = None) -> Image.Image:
    """
    Capture a screenshot using the backend appropriate for the Linux session.
    Wayland uses compositor screenshot tools because PyAutoGUI relies on X11.
    """
    if is_wayland_session():
        image = _capture_with_grim(region)
        if image is not None:
            return image
        image = _capture_with_gnome_screenshot(region)
        if image is not None:
            return image
        raise RuntimeError("Wayland screenshot failed: neither grim nor gnome-screenshot succeeded.")

    import pyautogui

    if region is not None:
        return pyautogui.screenshot(region=region)
    return pyautogui.screenshot()


def capture_target_screenshot() -> Image.Image:
    if is_wayland_session() and not list_screens():
        return capture_screenshot(region=get_wayland_screen_rect())
    return capture_screenshot(region=get_target_screen_rect())
