from typing import Literal, Optional

from typing import List
from pydantic import BaseModel, Field
from src.controller.registry.views import ActionModel
# mlx-use actions 


class DoneAction(BaseModel):
	text: str

class InputTextAction(BaseModel):
	text: str

class RecordAction(BaseModel):
	text: str = Field(..., description="information you need to record")
	file_name: str = Field(..., description="filename summary for the recorded info")

class OpenAppAction(BaseModel):
	app_name: str

class AppleScriptAction(BaseModel):
	script: str

class PressAction(BaseModel):
	key: str

class PressCombinedAction(BaseModel):
	key1: str
	key2: str
	key3: Optional[str] = None

class LeftClickPositionAction(BaseModel):
	index: int

class RightClickPositionAction(BaseModel):
	index: int

class MoveToAction(BaseModel):
	position: List[float] = Field(..., description="Coordinates (normalised) [x,y]")

class LeftClickPixel(BaseModel):
    # Provide item type (int). You can also enforce a 2-length list by min_items/max_items if desired.
    position: List[float] = Field(..., description="Coordinates (normalised) [x,y]")

class RightClickPixel(BaseModel):
    position: List[float] = Field(..., description="Coordinates (normalised) [x,y]")

class DoubleClickPixel(BaseModel):
    position: List[float] = Field(..., description="Coordinates (normalised) [x,y]")

class ScrollUpAction(BaseModel):
	position: List[float] = Field(..., description="Coordinates (normalised) [x,y] to execute scroll")
	dx: Optional[int] = Field(default=0, description="Amount to scroll horizontally. Default=0")
	dy: Optional[int] = Field(default=2, description="Amount to scroll up. Default=2, recommended range 1-2 for dropdowns and compact selectors")

class ScrollDownAction(BaseModel):
	position: List[float] = Field(..., description="Coordinates (normalised) [x,y] to execute scroll")
	dx: Optional[int] = Field(default=0, description="Amount to scroll horizontally. Default=0")
	dy: Optional[int] = Field(default=2, description="Amount to scroll down. Default=2, recommended range 1-2 for dropdowns and compact selectors")

class ExtractAction(BaseModel):
	position1: List[float] = Field(..., description="Coordinates (normalised) [x,y]")

class DragAction(BaseModel):
	position1: List[float] = Field(..., description="Starting Coordinates (normalised) [x,y]")
	position2: List[float] = Field(..., description="Ending Coordinates (normalised) [x,y]")

class NoParamsAction(ActionModel):
	"""
	Simple parameter model requiring no arguments.
	"""
	pass
