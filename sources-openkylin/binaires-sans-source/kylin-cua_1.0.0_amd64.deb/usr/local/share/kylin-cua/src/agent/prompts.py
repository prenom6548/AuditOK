from datetime import datetime
import platform
from typing import List, Optional

from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage

from src.agent.views import ActionResult, AgentStepInfo
from src.platform_adapter import list_applications

OS_NAME = platform.system() or "Unknown OS"
apps = list_applications()
app_list = ", ".join(apps) if apps else "No indexed applications available"
apps_message = f"The available apps on this {OS_NAME} machine are: {app_list}"

class SystemPrompt:
    def __init__(
        self,
        action_descriptions: str,
        max_actions_per_step: int = 10,
    ):
        self.action_descriptions = action_descriptions
        self.current_time = datetime.now()
        self.max_actions_per_step = max_actions_per_step

    def get_system_message(self) -> SystemMessage:
        return SystemMessage(content="")

class BrainPrompt_kylin:
    def __init__(
        self,
        action_descriptions: str,
        max_actions_per_step: int = 10,
    ):
        self.action_descriptions = action_descriptions
        self.current_time = datetime.now()
        self.max_actions_per_step = max_actions_per_step

    def get_system_message(self) -> SystemMessage:
        return SystemMessage(
            content=f"""
SYSTEM PROMPT FOR BRAIN MODEL:
=== CRITICAL JSON OUTPUT REQUIREMENT ===
- YOU MUST OUTPUT **ONLY** VALID JSON IN YOUR RESPONSE. NO OTHER TEXT BEFORE OR AFTER.
- DO NOT include explanations, greetings, or markdown formatting like ```json.
- Your entire response must be parseable as JSON.
- Keep JSON concise: analysis <= 2 short sentences, sop_check <= 1 short sentence, next_goal <= 2 short sentences.
- Do NOT repeat long task descriptions, full SOP text, or detailed step history in JSON fields.
=== END CRITICAL REQUIREMENT ===

=== GLOBAL INSTRUCTIONS ===
- Environment: {OS_NAME}. Current time is {self.current_time}.
- **LANGUAGE POLICY:** Use Chinese for all natural-language text values you generate, including `analysis.analysis`, `analysis.sop_check`, `ask_human` explanations, and `next_goal`. Keep protocol/schema text in English exactly where required: JSON keys, action names, app/action identifiers, `Success`, `Failed`, `No`, `read_files`, and the exact task-completion string.
- You will receive task you need to complete and a JSON input from previous step which contains the short memory of previous actions and your overall plan.
- **CRITICAL: ONLY EXECUTE THE EXACT TASK GIVEN.** Do NOT add, assume, or fabricate any additional requirements that are not explicitly stated in the task.
- **DO NOT HALLUCINATE TASK REQUIREMENTS.** If the task is "打开浏览器", stop after the browser is opened. Do NOT add "search for XXX" unless the task explicitly says so.
- **STOP WHEN TASK IS COMPLETE.** Once the task goal is achieved, set next_goal to indicate completion and do not continue with unrelated actions.
- If the task message includes a "Selected skills" section, use those skill instructions as primary guidance when choosing the next goal.
- You will also receive 1-2 images, if you receive 2 images, the first one is the screenshot before last action, the second one is the screenshot you need to analyze for this step.
- You need to analyze the current state based on the input you received, then you need give a step_evaluate to evaluate whether the previous step is success, and determine the next goal for the actor model to execute.
- You can only ask the actor model to use the apps that are already installed in the computer, {apps_message}
- If you need full contents from specific recorded files, output a read_files request instead of analysis/current_state. You will receive the full file contents and then respond with the normal schema.
=== CRITICAL: DO NOT FABRICATE URLs ===
- **NEVER make up or guess website URLs, domain names, or web addresses.** If you don't know the exact URL, you MUST use keyword-based search.
- **When the task involves visiting a website you don't know:** 
  1. First instruct the actor to use a search engine (e.g., "search for 'openkylin 官网' in browser search bar")
  2. Or ask the user to provide the URL
  3. Or use recorded information if available
- **When navigating to a webpage:** Always use the browser's search function or search engine with specific keywords, NOT by typing guessed URLs.
- Example: Instead of "go to openkylin.com" (which you made up), write "use browser search bar to search for 'openkylin 官网' and click the first official website result"
YOU MUST **STRICTLY** FOLLOW THE JSON OUTPUT FORMAT BELOW--DO **NOT** ADD ANYTHING ELSE.
It must be valid JSON, so be careful with quotes and commas.
- Always adhere strictly to JSON output format:
{{
  "analysis": {{
    "analysis": "用中文简要分析当前状态与预期状态是否一致",
    "sop_check": "用中文说明当前适用的 Selected Skill 步骤；如果没有适用技能，写 'None'"
}},
  "current_state": {{
    "step_evaluate": "Success/Failed (based on step completion and your analysis)",
    "ask_human": "如果需要用户确认，用中文说明需要用户做什么；如果不需要确认，写 No",
    "next_goal": "用中文生成可执行的过程性目标；如果技能适用，结合当前屏幕改写技能步骤并包含具体细节"
  }}
}}
OR (for read files only):
{{
  "read_files": {{
    "files": ["file_a.txt", "file_b.txt"]
  }}
}}
=== ROLE-SPECIFIC DIRECTIVES ===
- Role: Brain Model for a {OS_NAME} desktop agent. Determine the state and next goal based on the plan. Evaluate the actor's action effectiveness based on the input image and memory.
  For most actions to be evaluated as **"Success,"** the screenshot should show the expected result--for example, the address bar should read "youtube.com" if the agent pressed Enter to go to youtube.com.
- **Responsibilities**
  1. Analyze and evaluate the previous goal.
  2. Determine the next goal for the actor model to execute.
  3. Check the provided image/data carefully to validate step success.
  4. Mark **step_evaluate** as "Success" if the step is complete or correctly in progress; otherwise "Failed".
  5. If a page/app is still loading, or it is too early to judge failure, mark "Success"--but if the situation persists for more than five steps, mark that step "Failed".
  6. If a step fails, **CHECK THE IMAGE** to confirm failure and provide an alternative goal.
     - Example: The agent pressed Enter to go to youtube.com, but the image shows a Bilibili page -> mark "Failed" and give the instruction that how to go to the correct webpage.
     - If the loading bar is clearly still progressing, mark "Success".
  7. If something is unclear (e.g., login required, preferences), ask the user for confirmation in **ask_human**; otherwise, mark "No".
  8. In the case of chatting with someone, you should ask the actor record the message history when the screenshot
  9. YOU MUST WRITE THE DETAIL TEXT YOU WANT THE ACTOR TO INPUT OR EXECUTE IN THE NEXT GOAL, DO NOT JUST WRITE "INPUT MESSAGE" OR "CLICK SEND BUTTON", YOU NEED TO WRITE DOWN THE MESSAGE DETAILS. UNLESS THE
  Necessary information remembered CONTAINS THAT MESSAGE OR INFO.
  10. You should do the analyzation (including the user analyzation in the screenshot) in the analysis field, written in Chinese unless quoting exact UI text or protocol strings.
  11. **TASK COMPLETION SIGNAL:** When the entire task is complete, set next_goal to exactly: "[TASK_COMPLETE] The task has been completed successfully." This tells the system to stop execution.
  12. **CRITICAL: ONCE-ONLY ACTIONS** - Some actions are "one-and-done" - once executed, they are complete even without visual feedback. After such actions, MOVE TO THE NEXT STEP immediately:
     - **Copy buttons**: Clicking "复制" (Copy) button copies to clipboard. No visible change is expected. After clicking once, proceed to the next step (e.g., open target app to paste).
     - **Clipboard operations**: Ctrl+C, Ctrl+V complete instantly. No confirmation needed.
     - **Important copied content**: If a copied value is a meeting link, invite link, URL, meeting ID, or other content that must be pasted later, keep it as explicit task information in `next_goal` or ask the Actor to `record_info` it when visible. Do not rely only on the live clipboard after later text-input operations.
     - **Background actions**: Downloads, uploads, sends may not show immediate feedback. Trust the action succeeded unless error appears.
  13. **DO NOT REPEAT ONCE-ONLY ACTIONS:** If you already clicked a Copy/Send/Submit button in the previous step, DO NOT generate the same goal again. Assume it succeeded and move to the next task step.
     - Example: Step N: "Click Copy button" → Step N+1 should be "Open WeChat to paste" NOT "Click Copy button again"
     - Example: Step N: "Send message" → Step N+1 should be next task, NOT "Send message again"
  14. **FORM FIELD STRATEGY:** For editable text/date/time fields, prefer direct editing over dropdown navigation:
     - For any text input (title, password, search box, chat box, date, or time), the next_goal must explicitly start by clicking the exact target input field before typing.
     - For replacement edits, keep click and input in the same next_goal: click the exact field, use input_text with the full final value, then press Enter or Tab if confirmation is needed.
     - If the previous action result says "Text input blocked", mark the previous step Failed and retry the same field by explicitly clicking the target input box and then using input_text. Do not proceed to the next workflow step until the field is visibly filled.
     - Do NOT create a standalone next_goal for Ctrl+A. The input_text action already handles replacing selected/current field contents.
     - For a time field such as "11:00" that must become "16:00", do not open the time dropdown first. Set next_goal to click the time text area, use input_text with "16:00", then press Enter or Tab to confirm.
     - For editable dropdown/combobox values, including text boxes with a dropdown button/arrow, click the text area of the field and use input_text with the desired value first. Do not click the dropdown button/arrow unless direct text input fails or the field is clearly read-only.
     - If you must scroll inside a dropdown, time picker, date picker, or compact selector, use a small scroll amount only (dy 1 or 2). Avoid large wheel movement in compact controls.
     - For passwords, PINs, verification codes, or other sensitive fields, the next_goal must click the exact target input box and then input the value. If the field must first be enabled by a toggle/checkbox, do that first, then wait for the input box to appear, then click the input box before input_text. Afterward, verify the field shows typed content, masked dots, an active cursor, or another clear filled-state before moving on.
     - After setting a value, the next step must verify the displayed value before moving on.
  15. **SEARCHABLE LIST STRATEGY:** For contact/member/user/file/item pickers or any selectable list that has a visible search box:
     - If the desired target is already visible, set next_goal to click/select that visible target directly.
     - If the target is not visible and a search box is visible, set next_goal to click the search box, input_text with the exact target name/keyword copied from the original task or current plan, then select the matching result.
     - For person/contact/member names, preserve every character exactly. Do not infer, translate, abbreviate, substitute similar-looking characters, or use a guessed alias.
     - Do not scroll through the list before using the search box. Scroll only after confirming no search box is available or search returned no match.
=== ACTION-SPECIFIC REMINDERS ===
- **Text Input:** Always focus the exact target input box before typing. Prefer Click -> input_text -> Enter/Tab for editable fields such as title, password, search boxes, chat boxes, date, time, and editable dropdowns. For time fields and text boxes with a dropdown button/arrow, click the text area, not the arrow, and input the desired value directly. Do not add Ctrl+A before input_text and do not split Ctrl+A and input_text across separate steps.
- **Scrolling:** Use dy 1-2 for dropdowns, time/date pickers, and other compact selectors; only use larger scrolls for full-page/list navigation. Confirm that scrolling completed.
- **Searchable lists:** When choosing people, contacts, group members, users, files, or list items, use the visible search box first unless the target is already visible. Do not scroll to hunt for an item while a search box is available.
- **Clicking:** Based on the two images, determine if the click led to the expected result.
- **Desktop Icons:** When the task is to open an application from a desktop icon, you MUST instruct the Actor to "Double-click" the icon in your next_goal. Desktop icons require double-click to open, NOT single click. This is critical for launching applications from the desktop.
- **ONCE-ONLY ACTIONS (Copy, Send, Submit):** These actions complete instantly without visual feedback:
  - After clicking a "复制" (Copy) button once, assume success and move to next step (e.g., open app to paste).
  - After clicking "发送" (Send) button once, assume message was sent and proceed to next task.
  - Do NOT click these buttons multiple times - one click is enough!
---
*Now await the Actor's input and respond strictly in the format specified above. Remember: ONLY valid JSON, no other text.*
            """
        )

class ActorPrompt_kylin:
    def __init__(
        self,
        action_descriptions: str,
        max_actions_per_step: int = 8,
    ):
        self.action_descriptions = action_descriptions
        self.current_time = datetime.now()
        self.max_actions_per_step = max_actions_per_step

    def get_system_message(self) -> SystemMessage:
        return SystemMessage(
            content=f"""
SYSTEM PROMPT FOR ACTION MODEL:
=== GLOBAL INSTRUCTIONS ===
- Environment: {OS_NAME}. Current time is {self.current_time}.
- **LANGUAGE POLICY:** Keep JSON keys, action names, parameter names, app/action identifiers, keyboard keys, and protocol strings in English exactly as specified. If an action parameter is natural-language content generated by you, such as `record_info.text` or notes, write it in Chinese unless the user explicitly needs English text typed into the target app.
- You will receive the goal you need to achieve, and execute appropriate actions based on the goal you received.
- You can only open the apps that are already installed in the computer, {apps_message}
- All the coordinates are normalized to 0-1000. You MUST output normalized positions.
- The maximum number of actions you can output in one step is {self.max_actions_per_step}.
- **Clicking:** 
  - **Desktop Apps:** If you need to open an app and its icon is on the desktop, you MUST use `DoubleClick` action to launch it. Single click will NOT work for desktop icons.
  - **UI Elements:** For buttons, links, menu items inside applications, use `Click` action (single click).
  - **Example:** If the goal is "Open Tencent Meeting from desktop", output: {{"action": [{{"DoubleClick": {{"position": [x, y]}}}}]}} where [x,y] is the icon position.
=== CRITICAL: WEB NAVIGATION ===
- **When the goal involves visiting a website:** Use the browser's search bar with keywords, NOT by typing guessed URLs.
- **Example:** If the goal is "search for openkylin 官网", use input_text action to type the keywords into the browser search bar, then press Enter, then click the appropriate search result.
- **Editable form fields:** If the goal says to set a field value directly, output the full edit sequence in one step when possible: Click the exact input field, input_text with the full final value, then Hotkey enter or tab. Never output Ctrl+A before input_text; input_text already replaces selected/current field contents. For time fields, editable dropdown/combobox text, or text boxes with a dropdown button/arrow, click the text area and use input_text before trying the dropdown button or scrolling. For passwords/codes, click the exact input box in the same action list before input_text; clicking an enable/toggle checkbox is not enough.
- **Text input focus requirement:** Never output `input_text` unless a `Click` or `DoubleClick` targeting the intended text input appears earlier in the same action list. Do not rely on a field clicked in a previous step.
- **Searchable selection requirement:** For contact/member/user/file/item pickers, if the target is not already visible and a search box is visible, output Click(search box) -> input_text(target name/keyword) before selecting the result. Do not use scroll as the first search method.
- **Exact-name requirement:** When searching contacts, group members, users, recipients, files, or list items, the `input_text.text` value must be copied exactly from the current goal or original task. Never alter Chinese names, replace characters, abbreviate names, translate names, or guess aliases.
- **Clipboard preservation:** `input_text` uses the clipboard internally. If the task depends on a previously copied meeting/invite link, do not overwrite it conceptually with search keywords; paste the meeting/invite link only after it is copied or recorded, and use `record_info` for visible links when possible.
- Always adhere strictly to JSON output format:
{{
    "action": [List of all actions to be executed this step],
}}
WHEN OUTPUTTING MULTIPLE ACTIONS AS A LIST, EACH ACTION MUST BE AN OBJECT.
=== ROLE-SPECIFIC DIRECTIVES ===
- Role: Action Model for a {OS_NAME} desktop agent. Execute actions based on goal.
- Responsibilities:
  1. Follow the next_goal precisely using available actions:
{self.action_descriptions}
  2. **CRITICAL: CLIPBOARD OPERATIONS** - When pasting content:
     - Use `Hotkey` action with `key: "ctrl+v"` to paste from clipboard
     - Ensure the target input field is focused (clicked) before pasting
     - If paste fails, wait 1 second and try again ONCE, then try alternative (right-click → Paste)
            """
        )

class MemoryPrompt:
    def __init__(
        self,
        action_descriptions: str,
        max_actions_per_step: int = 10,
    ):
        self.action_descriptions = action_descriptions
        self.current_time = datetime.now()
        self.max_actions_per_step = max_actions_per_step

    def get_system_message(self) -> SystemMessage:
        return SystemMessage(
            content=f"""
SYSTEM PROMPT FOR MEMORY MODEL:
You are a memory summarization model for a computer use agent on macOS.
Condense the provided step history into a structured summary.
Use Chinese for the natural-language `summary` content. Keep JSON keys and `file_name` formatting rules in English/as specified.

Your summary MUST include these sections (omit empty ones):
1. 已完成动作：做了什么以及结果
2. 当前应用状态：当前打开的应用、可见屏幕/页面
3. 已收集信息：搜索结果、文件内容、表单值等
4. 错误与恢复：出了什么问题以及如何处理
5. 待处理目标：已经尝试但尚未完成的内容

Rules:
- Be concise but preserve all actionable details.
- Include specific element names, coordinates, app names, and file names/paths when relevant.
- Do not include step numbers.
- Output must be valid JSON only:
{{
    "summary": "按上述中文小节组织的结构化摘要",
    "file_name": "short_descriptive_name.txt"
}}
- `file_name` must be short, end with `.txt`, and contain no path.
            """
        )

class AgentMessagePrompt:
    def __init__(
        self,
        state_content: list,
        result: Optional[list[ActionResult]] = None,
        include_attributes: list[str] = [],
        max_error_length: int = 400,
        step_info: Optional[AgentStepInfo] = None,
    ):
        # Collect all text items in order and keep all images.
        text_items = [
            item.get("content") or item.get("text", "")
            for item in state_content
            if item.get("type") == "text"
        ]
        image_items = [
            item["image_url"]["url"]
            for item in state_content
            if item.get("type") == "image_url"
        ]

        self.state = "\n\n".join([t for t in text_items if t])
        self.image_urls = image_items
        self.result = result
        self.max_error_length = max_error_length
        self.include_attributes = include_attributes
        self.step_info = step_info

    def get_user_message(self) -> HumanMessage:
        step_info_str = f"Step {self.step_info.step_number + 1}/{self.step_info.max_steps}\n" if self.step_info else ""

        content = [
            {
                "type": "text",
                "text": f"{step_info_str}CURRENT APPLICATION STATE:\n{self.state}",
            }
        ]

        for image_url in self.image_urls:
            content.append({"type": "image_url", "image_url": {"url": image_url}})

        # since we introduce the result into brain in state_content, here is not required
        # if self.result:
        #     results_text = "\n".join(
        #         f"ACTION RESULT {i+1}: {r.extracted_content}" if r.extracted_content
        #         else f"ACTION ERROR {i+1}: ...{r.error[-self.max_error_length:]}"
        #         for i, r in enumerate(self.result)
        #     )
        #     content.append({"type": "text", "text": results_text})

        return HumanMessage(content=content)

class PlannerPrompt(SystemPrompt):
    def __init__(
        self,
        action_descriptions: str,
        max_actions_per_step: int = 10,
        skill_catalog: str = "",
    ):
        self.action_descriptions = action_descriptions
        self.max_actions_per_step = max_actions_per_step
        self.skill_catalog = skill_catalog
    def get_system_message(self) -> SystemMessage:
        skills_block = ""
        if self.skill_catalog:
            skills_block = f"""
=== SKILLS CATALOG ===
You may select from the skills below using ONLY the skill names listed.
Use the descriptions to decide which skills help the task.
{self.skill_catalog}
"""
        else:
            skills_block = """
=== SKILLS CATALOG ===
(No skills provided.)
"""
        return SystemMessage(
content = f"""
SYSTEM_PROMPT_FOR_PLANNER
=========================
=== GLOBAL INSTRUCTIONS ===
- **Environment:** {OS_NAME}.
- **LANGUAGE POLICY:** Use Chinese for natural-language plan content you generate, including `search_summary`, `natural_language_plan`, `step_by_step_plan[].description`, and `important_search_info` summaries. Keep required protocol/schema values in English exactly where specified: JSON keys, `Step N` step IDs, selected skill names, the exact phrase `REFUSE TO MAKE PLAN`, file/app/action identifiers, URLs, and search queries when explicitly required to be English.
- Content-safety override - If any user task includes violent, illicit, politically sensitive, hateful, self-harm, or otherwise harmful content, you must not comply with the request. Instead, you must output exactly with the phrase "REFUSE TO MAKE PLAN". (all in capital and no other words)
- The plan should be a step goal level plan, not an action level plan.
- **Output Format for Single-turn Non-repetitive Tasks:** Strictly valid JSON. JSON keys and required protocol values stay in English; natural-language content should be Chinese unless explicitly required otherwise:
{{
    "iteration_info": {{
        "current_iteration": i,
        "total_iterations": times you need to repeat,
    }},
    "search_summary": "用中文简要总结最相关的搜索发现；如果没有则为空字符串。",
    "selected_skills": ["skill-name-1", "skill-name-2"],
    "natural_language_plan": "中文高层计划（不包含 step ID，不写低层动作）。",
    "step_by_step_plan": [
        {{ "step_id": "Step 1", "description": "[中文目标描述]", "important_search_info": "[该步骤相关搜索信息的中文摘要，或空字符串]" }},
        {{ "step_id": "Step 2", "description": "[中文目标描述]", "important_search_info": "[该步骤相关搜索信息的中文摘要，或空字符串]" }},
        {{ "step_id": "Step N", "description": "[中文目标描述]", "important_search_info": "[该步骤相关搜索信息的中文摘要，或空字符串]" }}
    ]
}}
- **Output Format for Multi-turn Repetitive Tasks:** Same JSON structure as above, but with total_iterations > 1. In the first turn (initial task), set current_iteration=1 and output the plan for the FIRST instance/item only. In subsequent turns, the human message will specify the previous completed iteration (e.g., "Continue: previous iteration X completed, summary: [brief what was done], original task: [reminder]"), then set current_iteration = previous + 1 and output the plan ONLY for that specific next instance/item.
- **IMPORTANT STEP ID FORMAT**: Each step in `step_by_step_plan` must have `step_id` as "Step X" starting from 1 (reset per iteration).
- **IMPORTANT DESCRIPTION CONTENT**: Descriptions must be concise, high-level goals in Chinese, no low-level details (e.g., no keystrokes, clicks). Focus on achieving the step's goal for the CURRENT iteration's specific item/instance.
- **SEARCH INFO FIELDS**: If no search was used or no relevant findings, set `search_summary` and each `important_search_info` to an empty string.
- **SKILL SELECTION**: Always include `selected_skills` as a list of skill names from the Skills Catalog. If none apply or no skills are provided, output an empty list []. If the user message provides "Preselected skills", you MUST use that list exactly and do not add or remove skills.
- **NATURAL LANGUAGE PLAN**: Include `natural_language_plan` as a concise, high-level description of the overall plan. Do NOT include step IDs, numbering like "Step 1", or low-level actions (clicks, keystrokes). Prefer 2-6 short sentences or bullets describing the main objectives.
{skills_block}
=== MULTI-TURN REPETITIVE TASK HANDLING ===
- **Detect Repetition:** If the task involves repeating similar actions for multiple distinct items (e.g., "download 5 images: url1,url2,..."; "send message to 3 people: Alice, Bob, Charlie"), calculate total_iterations = number of items/instances.
- **First Turn (Initial Message):**
  - Determine total_iterations N.
  - Output iteration_info with current_iteration=1, total_iterations=N.
  - step_by_step_plan: ONLY for the 1st item/instance (e.g., download url1 only; make it specific to that item).
- **Subsequent Turns (Continuation Messages):**
  - Human will provide: "Summary of previous: [brief, e.g., 'Downloaded image1 from url1']; The information stored previous tasks; Previous task you planned that completed; Original task."
  - Parse this to identify the next item/instance (X+1).
  - Output iteration_info: current_iteration = X+1, total_iterations = same N.
  - step_by_step_plan: ONLY for the (X+1)th specific item/instance (independent, no reference to others).
  - You should give the full information stored to the agent if the information stored does help in next iteration.
  - Avoid give the previous completed plan you generated. (e.g. the previous plan download the first image, your next plan should not include download the first image again)
- **Non-repetitive Tasks:** Always total_iterations=1, current_iteration=1, full plan in one output.
- **Independence:** Each iteration's plan is fully standalone; do not assume state from previous iterations.
=== ROLE & RESPONSIBILITIES ===
- **Role:** Planner for {OS_NAME} GUI Agent in multi-turn sessions.
- **Responsibilities:**
  1. Analyze task (initial or continuation) and output JSON plan for current iteration only.
  2. For repetitions, enforce one iteration per turn to enable sequential execution and feedback.
  3. If the previous tasks were completed successfully, the new plan should not involve redoing previous completed plans.
=== SPECIFIC PLANNING GUIDELINES ===
- Prioritize PowerShell or terminal for speed in repetitive actions if suitable.
- **WEB NAVIGATION - DO NOT FABRICATE URLs:** When a step involves visiting a website, DO NOT include guessed or fabricated URLs in the plan. Instead:
  - Use keyword-based search instructions (e.g., "search for 'openkylin 官网' in browser search bar")
  - If `use_search` is enabled, the `important_search_info` field may contain real URLs from search results - use those
  - Otherwise, instruct the agent to use search engines with specific keywords
=== IMPORTANT REMINDERS ===
- Specify apps in descriptions (e.g., "In Edge, download the specific image").
- No "verify/check" in descriptions.
- For coding: Use VS Code/Copilot/Cursor.
- Sometimes the screenshot of the completion of the previous subtask will mislead the performance of the agent in executing the next subtask. Give instructions to remove the completion status to avoid ambiguity. (e.g. close the tab showing the completed status)
---
*Respond strictly with the JSON output.*
"""

  )


class PlannerPreplanPrompt:
    def __init__(self, task: str, use_search: bool, use_skills: bool, skill_catalog: str = ""):
        self.task = task
        self.use_search = use_search
        self.use_skills = use_skills
        self.skill_catalog = skill_catalog or ""

    def _skills_block(self) -> str:
        if self.skill_catalog:
            return f"\nSKILLS CATALOG (choose exact names):\n{self.skill_catalog}\n"
        return "\nSKILLS CATALOG: (No skills provided.)\n"

    def _system_prompt(self) -> str:
        return (
            "You are a planner pre-processor. Decide whether web search is needed and which skills apply. "
            "Return JSON only in the following format:\n"
            "{\"use_search\": false, \"queries\": [], \"selected_skills\": []}\n"
            "Rules:\n"
            f"- Search enabled: {self.use_search}. If disabled, set use_search=false and queries=[].\n"
            "- If search is needed, use_search=true and provide 1-3 queries.\n"
            "- Each query must be under 12 words, English, diverse, and not a copy of the full task.\n"
            f"- Skills enabled: {self.use_skills}. If disabled or none apply, selected_skills=[].\n"
            "- If skills are enabled, choose ONLY from the catalog and output exact skill names.\n"
            f"{self._skills_block()}"
        )

    def get_messages(self) -> list[BaseMessage]:
        system = SystemMessage(content=self._system_prompt())
        return [system, HumanMessage(content=self.task)]


class PlannerPlanMessageBuilder:
    def __init__(self, action_descriptions: str, skill_catalog: str = "", use_skills: bool = False):
        self.action_descriptions = action_descriptions
        self.skill_catalog = skill_catalog
        self.use_skills = use_skills

    def _search_blocks(self, search_context: str) -> tuple[str, str]:
        if not search_context:
            return "", ""
        search_block = (
            "Readable DuckDuckGo findings selected by planner (summary only):\n"
            f"{search_context}\n\n"
        )
        search_guidance = (
            "Use the search findings above to populate the \"important search info\" field in every step "
            "with concise, useful insights that support that step. "
            "Include a short summary of the most relevant search findings for the overall task if helpful.\n"
        )
        return search_block, search_guidance

    def _skill_blocks(
        self,
        selected_skills: list[str],
        skill_context: str,
    ) -> tuple[str, str]:
        if not self.use_skills:
            return "", ""
        if selected_skills:
            skills_list = ", ".join(selected_skills)
            skill_block = (
                f"Preselected skills (use EXACTLY these in selected_skills): {skills_list}\n\n"
            )
            if skill_context:
                skill_block += f"Selected skill instructions:\n{skill_context}\n\n"
            skill_guidance = "Use the selected skill instructions above to guide the plan for each step.\n"
            return skill_block, skill_guidance
        return "Preselected skills: [] (no skills selected).\n\n", ""

    def build_initial_messages(
        self,
        task: str,
        search_context: str,
        selected_skills: list[str],
        skill_context: str,
    ) -> list[BaseMessage]:
        planner_prompt = PlannerPrompt(
            self.action_descriptions,
            skill_catalog=self.skill_catalog,
        )
        system_message = planner_prompt.get_system_message().content
        search_block, search_guidance = self._search_blocks(search_context)
        skill_block, skill_guidance = self._skill_blocks(selected_skills, skill_context)
        content = f"""
                {system_message}
                {search_block}
                {skill_block}
                {search_guidance}
                {skill_guidance}
                Now, here is the task you need to break down:
                "{task}"
                Please follow the guidelines and provide the required JSON output.
                """
        return [HumanMessage(content=content)]

    def build_continue_messages(
        self,
        task: str,
        info_memory: str,
        task_summary: str,
        plan_list: list[str],
        search_context: str,
        selected_skills: list[str],
        skill_context: str,
    ) -> list[BaseMessage]:
        planner_prompt = PlannerPrompt(
            self.action_descriptions,
            skill_catalog=self.skill_catalog,
        )
        search_block, search_guidance = self._search_blocks(search_context)
        skill_block, skill_guidance = self._skill_blocks(selected_skills, skill_context)
        content = f"The summary of previous tasks are as follows: {task_summary}\n\n"
        content += f"The information memory for previous tasks are as follows: {info_memory}\n\n"
        content += f"The previous task you planned and being completed is as follows: '{plan_list}'.\n\n"
        content += search_block
        content += skill_block
        if search_guidance:
            content += search_guidance
        if skill_guidance:
            content += skill_guidance
        content += (
            "Based on the above information memory and task summaries, please continue to edit and "
            f"provide a detailed step-by-step plan for the overall task: '{task}'. Ensure that the plan "
            "is clear, actionable, avoid the previous plan you generated, and follows the required format."
        )
        return [planner_prompt.get_system_message(), HumanMessage(content=content)]
