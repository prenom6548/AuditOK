#!/bin/bash

# 检查是否传递了进程名参数
if [ -z "$1" ]; then
    echo "Usage: $0 <process_name>"
    exit 1
fi

PROCESS_NAME=$1

# 获取所有已登录的桌面用户
users=$(who | awk '$2 ~ /^tty[0-9]+$/ && $5 ~ /^\(:[0-9]+\)$/ {print $1$5}')

# 检查是否有用户登录
if [ -z "$users" ]; then
    echo "No desktop users logged in. Do not terminate the process \"$PROCESS_NAME\" without user confirmation."
    exit 1
fi

# 创建数组来存储每个用户的进程ID
declare -A pids

# 为每个用户显示确认对话框
for user_display in $users; do
    user=$(echo "$user_display" | awk -F'[()]' '{print $1}')
    display=$(echo "$user_display" | awk -F'[()]' '{print $2}')
    
    # 使用 sudo -u 切换到相应用户并显示 zenity 对话框
    # TODO: 应该提前将待处理的pids展示给用户
    sudo -u "$user" DISPLAY="$display" bash -c "zenity --question --title='Terminate Process' --text='Do you want to terminate the <b>potentially malicious</b> process: \"$PROCESS_NAME\"?' --no-wrap --ok-label='Terminate' --cancel-label='Ignore'" &
    
    # 获取进程ID
    pids[$user_display]=$!
done

echo "zenity executed"
# 等待任意一个后台进程完成
wait -n
status=$?

# 如果有用户确认终止，终止进程
if [ $status -eq 0 ]; then
    echo "User confirmed to terminate the process. Terminating \"$PROCESS_NAME\"."
    # 兼容脚本、编译型程序名，同时避免其他字段中的同名误配
    pkill -f "^\S+ $PROCESS_NAME[$ ]|^$PROCESS_NAME[$ ]"
else
    echo "User chose not to terminate the process. \"$PROCESS_NAME\" will not be terminated."
fi

for pid in "${pids[@]}"; do
    child=$(pgrep -P $pid)
    kill $child $pid 2>/dev/null
done

exit 0
