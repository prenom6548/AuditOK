#!/bin/bash

set -eu

if [ $# -ne 1 ]; then
	exit 2;
fi

# 检查nft是否存在，不存在则退出
command -v nft >/dev/null 2>&1 || exit 2

source /etc/kguard/interventions/base_funcs.sh

# numerical
protocol=$(echo "$1" | cut -d'_' -f1)
dport=$(echo "$1" | cut -d'_' -f3)

timeout_value=$(getTimeout)
TIMEOUT=
if [ $timeout_value -ne -1 ]; then
    TIMEOUT="timeout ${timeout_value}s"
fi

nft add table inet filter
nft add set inet filter kguard_rate_limit { type inet_service\; flags timeout\; }
nft add element inet filter kguard_rate_limit { $dport $TIMEOUT }
nft add chain inet filter input { type filter hook input priority 0\; }

if [ "$protocol" -eq 6 ]; then
    nft_output=$(nft list chain inet filter input)
    limit_line=$(echo "$nft_output" | grep -n "tcp dport @kguard_rate_limit ct state new limit rate" | cut -d: -f1)
    drop_line=$(echo "$nft_output"  | grep -n "tcp dport @kguard_rate_limit ct state new drop" | cut -d: -f1)
    if [ -z "$limit_line" ] || [ -z "$drop_line" ] || [ "$limit_line" -ge "$drop_line" ]; then
        nft insert rule inet filter input meta l4proto $protocol th dport @kguard_rate_limit ct state new drop
        nft insert rule inet filter input meta l4proto $protocol th dport @kguard_rate_limit ct state new limit rate 100/second burst 1000 packets accept # will be 1st
    fi
fi

if [ "$protocol" -eq 17 ]; then
    nft_output=$(nft list chain inet filter input)
    limit_line=$(echo "$nft_output" | grep -n "udp dport @kguard_rate_limit ct state new limit rate" | cut -d: -f1)
    drop_line=$(echo "$nft_output"  | grep -n "udp dport @kguard_rate_limit ct state new drop" | cut -d: -f1)
    if [ -z "$limit_line" ] || [ -z "$drop_line" ] || [ "$limit_line" -ge "$drop_line" ]; then
        nft insert rule inet filter input meta l4proto $protocol th dport @kguard_rate_limit ct state new drop
        nft insert rule inet filter input meta l4proto $protocol th dport @kguard_rate_limit ct state new limit rate 100/second burst 1000 packets accept
    fi
fi
