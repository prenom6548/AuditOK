#!/bin/bash

function getTimeout()
{
    file="/etc/kguard/interventions/.block_time"
    line=$(grep '^TIMEOUT=' "$file")

    if [ -n "$line" ]; then
        timeout_value=$(echo "$line" | sed -E 's/.*timeout ([0-9]+)s.*/\1/')
        # 如果未提取到值，则设置为 -1
        if [ -z "$timeout_value" ]; then
            timeout_value=-1
        fi
        # 非数字
        if ! [[ $timeout_value =~ ^[0-9]+$ ]]; then
            timeout_value=-1
        fi
    else
        # 未找到TIMEOUT= 行，设置为-1
        timeout_value=-1
    fi

    echo "$timeout_value"
}
