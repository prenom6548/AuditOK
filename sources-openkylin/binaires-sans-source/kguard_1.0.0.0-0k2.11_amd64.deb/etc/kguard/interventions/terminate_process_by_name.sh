#!/bin/bash

nohup /etc/kguard/interventions/terminate_process_by_name_wait_confirm.sh $1 >/dev/null 2>&1 &

exit 0
