#!/bin/env /bin/bash

set -eu
export PATH=$PATH:/opt/appdata/kguard/bin

if [ $# -ne 1 ]; then
	exit 2;
fi

source /etc/kguard/interventions/base_funcs.sh

timeout_value=$(getTimeout)

TIMEOUT=
if [ $timeout_value -ne -1 ]; then
    TIMEOUT="timeout ${timeout_value}s"
fi

NFT_CMD="nft"
if ! command -v nft >/dev/null 2>&1; then
    NFT_CMD="kguard-nft"
fi

$NFT_CMD add table ip kguard_filter
$NFT_CMD add set ip kguard_filter kguard_blacklists { type ipv4_addr \; flags timeout \; }
$NFT_CMD add element ip kguard_filter kguard_blacklists { $1 $TIMEOUT }
$NFT_CMD add chain ip kguard_filter kguard_input { type filter hook input priority 0\; }

if ! $NFT_CMD list table ip kguard_filter | grep -q 'ip saddr @kguard_blacklists drop'; then
    $NFT_CMD add rule ip kguard_filter kguard_input ip saddr @kguard_blacklists drop
fi
