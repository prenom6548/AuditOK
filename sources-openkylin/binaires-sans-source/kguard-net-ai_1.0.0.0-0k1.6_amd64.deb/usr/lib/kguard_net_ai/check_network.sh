#!/bin/bash

# 定义最大等待时间（比如 60s，最多等待 20 次，每次等待 3 秒）
max_wait_time=60
wait_interval=3
elapsed_time=0

# 循环等待网卡出现
while [ $elapsed_time -lt $max_wait_time ]; do
  # 获取当前默认网卡名称
  interface=$(ip route show default | awk '{print $5}')

  # 判断是否有网卡
  if [ -n "$interface" ]; then
    echo "当前默认网卡: $interface"
    exit 0  # 如果找到网卡，则成功退出
  else
    echo "没有找到默认网卡，等待 $wait_interval 秒后重试..."
    sleep $wait_interval  # 等待 3 秒钟后重新检测
    elapsed_time=$((elapsed_time + wait_interval))  # 增加已等待的时间
  fi
done

# 如果超过最大等待时间仍然没有网卡
echo "超过最大等待时间，未能找到默认网卡，退出..."
exit 1  # 如果超过最大等待时间，返回失败
