import sqlite3

def get_detection_count():
    # 连接到SQLite数据库
    conn = sqlite3.connect('detection_results.db')
    cursor = conn.cursor()

    try:
        # 执行查询获取count列的值
        cursor.execute('SELECT count FROM detection_counts WHERE id = 1')
        result = cursor.fetchone()

        if result:
            count_value = result[0]  # 获取count列的值
            return count_value
        else:
            return None
    except sqlite3.Error as e:
        return None
    finally:
        # 关闭连接
        conn.close()

# 调用接口获取count的值
count = get_detection_count()
if count is not None:
    print(count)
else:
    print(0)
