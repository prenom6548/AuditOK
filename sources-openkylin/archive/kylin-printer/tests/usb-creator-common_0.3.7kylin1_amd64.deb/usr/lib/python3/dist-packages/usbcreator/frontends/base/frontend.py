class Frontend:
    pass
