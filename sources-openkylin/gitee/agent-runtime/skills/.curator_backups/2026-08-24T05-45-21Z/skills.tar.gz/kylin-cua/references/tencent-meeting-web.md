# Tencent Meeting Web Portal

## Overview
URL: https://meeting.tencent.com/

## Navigation for Scheduling a Meeting
1. Navigate to https://meeting.tencent.com/
2. Click "登录" (Login) — located in top-right nav bar
3. Complete authentication (phone+password, WeChat scan, etc.)
4. After login, click "发起会议" or "预约会议" in top nav
5. Fill in:
   - 会议名称 (Meeting Name)
   - 会议密码 (Meeting Password)
   - 时长/时间 (Duration/Time)
6. Submit

## Pitfalls
- Login is always required for scheduling — cannot be bypassed
- Agent cannot handle authentication credentials; must ask user to log in manually
- Browser tool runs without residential proxies — aggressive bot detection possible
- Chinese UI requires navigating Chinese labels; use snapshot text to identify elements
