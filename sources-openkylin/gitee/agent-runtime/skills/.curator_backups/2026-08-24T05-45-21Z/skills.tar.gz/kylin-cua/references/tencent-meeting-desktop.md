# Tencent Meeting Desktop App Workflow

## When to use
Prefer the desktop Kylin-CUA path for Tencent Meeting tasks. The browser fallback is unreliable (login redirect to English version).

## Typical Steps (observed 2026-07-04 session)
1. Open Tencent Meeting app (click icon on desktop or launch via Kylin-CUA)
2. Click "预定会议" (Schedule Meeting) — the third button on the main interface
3. In the scheduling form:
   - 主题 (Topic/Name): type meeting name, press Enter
   - 时长 (Duration): click dropdown, type/select duration (e.g., "1小时" for 1 hour), press Enter
   - 入会密码 (Meeting Password): check the password checkbox, then type the password
4. Submit the form

## Scheduling with date and time (observed 2026-07-24 session)
1. Open Tencent Meeting app
2. Click "预定会议" button on the main interface
3. In the scheduling form:
   - Click the date input field → calendar picker appears → click the target date
   - Click the time input field → type the desired time (e.g., "15:00")
   - Fill in other fields as needed (topic, duration, password)
   - Click the blue "预定" button at the bottom
4. If a prompt dialog appears (e.g., "我知道了"), click to dismiss it first
5. After submission, a success dialog appears with meeting details and a "复制会议号和链接" button — click it to copy the meeting info to clipboard
6. After Kylin-CUA completes, read the clipboard content with `xclip -selection clipboard -o` to get the meeting link and meeting ID

## Getting meeting link after scheduling
When Kylin-CUA schedules a meeting, it can click "复制会议号和链接" which copies the full invitation text (meeting topic, time, link, meeting ID) to the system clipboard. Use this terminal command to retrieve it:
```bash
xclip -selection clipboard -o
```
The output includes the meeting link (https://meeting.tencent.com/dm/...) and meeting ID (#腾讯会议：XXX-XXX-XXX).

## Key UI Elements (positions from recorded sessions)
- Main interface buttons: 加入会议, 快速会议, 预定会议, 共享屏幕 (left to right)
- Duration dropdown: click then select from list
- Password checkbox: toggle then fill input
- Date input field: click to open calendar picker
- Time input field: click then type time directly (e.g., "15:00")
- "预定" button: blue button at bottom of form
- "复制会议号和链接" button: on success dialog after scheduling

## Source Sessions
- Date: 2026-07-04 (first run)
- Task: Schedule meeting "系统智能体项目评审会议", 1 hour, password "123123"
- Result: completed successfully in 7 steps, ~58 seconds
- Date: 2026-07-04 (second run)
- Task: Same parameters as above
- Result: completed successfully in 9 steps, ~67 seconds — workflow confirmed repeatable
- Date: 2026-07-24
- Task: Schedule meeting for tomorrow (2026/07/25) at 15:00, copy meeting link, send via WeChat to 黄江杰
- Result: completed successfully in 13 steps, ~138 seconds — date/time picker workflow confirmed, clipboard copy + xclip retrieval pattern validated
