# WeChat Desktop App Workflow

## When to use
Use the desktop Kylin-CUA path for WeChat tasks: sending messages, sharing files, finding contacts.

## Typical Steps (observed 2026-07-04 session)
1. Open WeChat app (click green icon on bottom taskbar)
2. Click "进入微信" (Enter WeChat) button to enter main interface
3. Wait for "正在进入" loading indicator to disappear — main interface shows chat list
4. Click the search box at the top of the WeChat window
5. Type contact name (e.g., "张梦琳") — dropdown shows matching contacts
6. Click the contact to open the chat window
7. In the chat window:
   - Click the input box at the bottom
   - Type the message text
   - Click the send button (or press Enter) to send
8. To send a file:
   - Click the file/attachment button in the bottom toolbar
   - File picker opens — navigate to the file location (e.g., "桌面" / Desktop)
   - Click the target file to select it
   - Click "打开" (Open) to confirm selection
   - Click "发送(S)" (Send) button to send the file

## Key UI Elements (positions from recorded session)
- WeChat icon on taskbar: green double-person icon (~93, 974)
- "进入微信" button: center of login screen (~497, 567)
- Search box: top of main window (~208, 302)
- Message input box: bottom of chat window (~579, 837)
- Send button: right side of input area (~770, 867)
- File attachment button: bottom toolbar (~337, 783)
- "发送(S)" button in file picker: confirms file send

## Notes
- File paths with Chinese characters in the task string work fine when passed through a `.sh` script (see kylin-cua SKILL.md Launch Rule pitfall about non-ASCII security scanner)
- If the contact is already visible in the chat list, you can click directly instead of searching
- The file picker starts in `/home/ok/文档` by default — navigate to "桌面" (Desktop) or other directories as needed

## Source Session
- Date: 2026-07-04
- Task: Send meeting info and manual file to 张梦琳
- Result: completed successfully in 17 steps, ~123 seconds
- Date: 2026-07-24
- Task: Send Tencent Meeting invitation (meeting link, time, meeting ID) to 黄江杰
- Result: completed successfully in 9 steps, ~96 seconds — contact found directly in chat list, no search needed; long message text (full meeting invitation with URL) pasted and sent successfully
